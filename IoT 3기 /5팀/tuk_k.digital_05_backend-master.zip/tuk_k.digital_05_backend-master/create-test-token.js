const jwt = require('jsonwebtoken');

// 테스트용 JWT 토큰 생성
function createTestToken() {
    const payload = {
        userId: 1,
        email: 'test@example.com',
        name: 'Test User'
    };

    const secret = 'your_jwt_secret'; // authService.js와 동일한 시크릿 사용
    const token = jwt.sign(payload, secret, { expiresIn: '24h' });

    console.log('🔑 테스트용 JWT 토큰 생성 완료:');
    console.log(token);
    console.log('\n📋 사용법:');
    console.log(`curl -X POST http://localhost:3000/api/robot/control \\`);
    console.log(`  -H "Content-Type: application/json" \\`);
    console.log(`  -H "Authorization: Bearer ${token}" \\`);
    console.log(`  -d '{"robot_id": "tibo-001", "command": "MOVE_FORWARD"}'`);
}

createTestToken(); 