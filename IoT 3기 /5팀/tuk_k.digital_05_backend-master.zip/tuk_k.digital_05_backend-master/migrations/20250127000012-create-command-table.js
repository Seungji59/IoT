'use strict';

module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('Command', {
            id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                primaryKey: true,
            },
            user_id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'User',
                    key: 'id'
                },
                onUpdate: 'CASCADE',
                onDelete: 'CASCADE'
            },
            robot_id: {
                type: Sequelize.STRING(50),
                allowNull: false,
            },
            command: {
                type: Sequelize.ENUM('MOVE_FORWARD', 'MOVE_BACKWARD', 'TURN_LEFT', 'TURN_RIGHT', 'STOP', 'HOME'),
                allowNull: false,
            },
            status: {
                type: Sequelize.ENUM('pending', 'executing', 'completed', 'failed'),
                defaultValue: 'pending',
            },
            parameters: {
                type: Sequelize.JSON,
                allowNull: true,
            },
            executed_at: {
                type: Sequelize.DATE,
                allowNull: true,
            },
            created_at: {
                type: Sequelize.DATE,
                defaultValue: Sequelize.NOW,
            },
        });

        // 인덱스 추가
        await queryInterface.addIndex('Command', ['user_id']);
        await queryInterface.addIndex('Command', ['robot_id']);
        await queryInterface.addIndex('Command', ['created_at']);
    },

    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('Command');
    }
}; 