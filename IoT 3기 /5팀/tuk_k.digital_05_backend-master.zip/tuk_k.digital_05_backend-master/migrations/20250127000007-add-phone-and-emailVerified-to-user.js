'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    // phone 컬럼은 이미 User 테이블 생성 시 추가되었으므로 건너뜀
    console.log('ℹ️ phone 컬럼은 이미 존재함');

    // emailVerified 컬럼은 이미 User 테이블 생성 시 추가되었으므로 건너뜀
    console.log('ℹ️ emailVerified 컬럼은 이미 존재함');
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.removeColumn('User', 'phone');
    await queryInterface.removeColumn('User', 'emailVerified');
  }
};
