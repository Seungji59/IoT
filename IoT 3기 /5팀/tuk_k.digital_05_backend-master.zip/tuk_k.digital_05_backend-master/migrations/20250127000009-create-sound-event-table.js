'use strict';

module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('SoundEvent', {
            id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                primaryKey: true,
            },
            camera_id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'Camera',
                    key: 'id'
                },
                onUpdate: 'CASCADE',
                onDelete: 'CASCADE'
            },
            sound_type: {
                type: Sequelize.ENUM('glass_break', 'door_bell', 'alarm', 'voice', 'unknown'),
                allowNull: false,
            },
            decibel_level: {
                type: Sequelize.FLOAT,
                comment: '소리 강도 (dB)'
            },
            duration: {
                type: Sequelize.FLOAT,
                comment: '소리 지속 시간 (초)'
            },
            confidence: {
                type: Sequelize.FLOAT,
                comment: 'AI 모델의 신뢰도 (0-1)'
            },
            audio_file_url: {
                type: Sequelize.STRING(255),
                comment: '녹음된 오디오 파일 URL'
            },
            spectrogram_url: {
                type: Sequelize.STRING(255),
                comment: '스펙트로그램 이미지 URL'
            },
            location: {
                type: Sequelize.STRING(100),
                comment: '소리 발생 위치'
            },
            is_processed: {
                type: Sequelize.BOOLEAN,
                defaultValue: false,
                comment: '알림 처리 여부'
            },
            created_at: {
                type: Sequelize.DATE,
                defaultValue: Sequelize.NOW,
            },
            detected_at: {
                type: Sequelize.DATE,
                allowNull: false,
                comment: '소리 감지 시간'
            }
        });

        // 인덱스 생성
        await queryInterface.addIndex('SoundEvent', ['camera_id']);
        await queryInterface.addIndex('SoundEvent', ['sound_type']);
        await queryInterface.addIndex('SoundEvent', ['detected_at']);
        await queryInterface.addIndex('SoundEvent', ['is_processed']);
    },

    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('SoundEvent');
    }
}; 