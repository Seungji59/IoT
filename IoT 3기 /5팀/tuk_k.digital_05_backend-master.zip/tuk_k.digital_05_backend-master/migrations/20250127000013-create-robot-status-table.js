'use strict';

module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('RobotStatus', {
            id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                primaryKey: true,
            },
            robot_id: {
                type: Sequelize.STRING(50),
                allowNull: false,
            },
            status: {
                type: Sequelize.ENUM('idle', 'moving', 'stopped', 'error', 'charging'),
                defaultValue: 'idle',
            },
            battery_level: {
                type: Sequelize.INTEGER,
                allowNull: true,
            },
            position: {
                type: Sequelize.JSON,
                allowNull: true,
            },
            obstacle_detected: {
                type: Sequelize.BOOLEAN,
                defaultValue: false,
            },
            obstacle_distance: {
                type: Sequelize.FLOAT,
                allowNull: true,
            },
            last_command: {
                type: Sequelize.STRING(50),
                allowNull: true,
            },
            error_message: {
                type: Sequelize.TEXT,
                allowNull: true,
            },
            updated_at: {
                type: Sequelize.DATE,
                defaultValue: Sequelize.NOW,
            },
            created_at: {
                type: Sequelize.DATE,
                defaultValue: Sequelize.NOW,
            },
        });

        // 인덱스 추가
        await queryInterface.addIndex('RobotStatus', ['robot_id']);
        await queryInterface.addIndex('RobotStatus', ['status']);
        await queryInterface.addIndex('RobotStatus', ['updated_at']);
    },

    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('RobotStatus');
    }
}; 