'use strict';

module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('SoundAlert', {
            id: {
                type: Sequelize.INTEGER,
                autoIncrement: true,
                primaryKey: true,
            },
            sound_event_id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'SoundEvent',
                    key: 'id'
                },
                onUpdate: 'CASCADE',
                onDelete: 'CASCADE'
            },
            user_id: {
                type: Sequelize.INTEGER,
                allowNull: false,
                references: {
                    model: 'User',
                    key: 'id'
                },
                onUpdate: 'CASCADE',
                onDelete: 'CASCADE'
            },
            alert_type: {
                type: Sequelize.ENUM('push', 'email', 'sms', 'in_app'),
                allowNull: false,
            },
            title: {
                type: Sequelize.STRING(100),
                allowNull: false,
            },
            message: {
                type: Sequelize.TEXT,
                allowNull: false,
            },
            priority: {
                type: Sequelize.ENUM('low', 'medium', 'high', 'critical'),
                defaultValue: 'medium',
            },
            is_sent: {
                type: Sequelize.BOOLEAN,
                defaultValue: false,
            },
            sent_at: {
                type: Sequelize.DATE,
            },
            is_read: {
                type: Sequelize.BOOLEAN,
                defaultValue: false,
            },
            read_at: {
                type: Sequelize.DATE,
            },
            created_at: {
                type: Sequelize.DATE,
                defaultValue: Sequelize.NOW,
            }
        });

        // 인덱스 생성
        await queryInterface.addIndex('SoundAlert', ['sound_event_id']);
        await queryInterface.addIndex('SoundAlert', ['user_id']);
        await queryInterface.addIndex('SoundAlert', ['alert_type']);
        await queryInterface.addIndex('SoundAlert', ['is_sent']);
        await queryInterface.addIndex('SoundAlert', ['is_read']);
        await queryInterface.addIndex('SoundAlert', ['created_at']);
    },

    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('SoundAlert');
    }
}; 