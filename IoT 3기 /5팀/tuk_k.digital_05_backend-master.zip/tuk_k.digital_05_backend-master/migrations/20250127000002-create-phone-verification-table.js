'use strict';

module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.createTable('PhoneVerification', {
            id: {
                allowNull: false,
                autoIncrement: true,
                primaryKey: true,
                type: Sequelize.INTEGER
            },
            phone: {
                type: Sequelize.STRING(20),
                allowNull: false,
                comment: '휴대폰 번호'
            },
            code: {
                type: Sequelize.STRING(6),
                allowNull: false,
                comment: '인증번호'
            },
            isVerified: {
                type: Sequelize.BOOLEAN,
                allowNull: false,
                defaultValue: false,
                comment: '인증 완료 여부'
            },
            verifiedAt: {
                type: Sequelize.DATE,
                allowNull: true,
                comment: '인증 완료 시각'
            },
            expiresAt: {
                type: Sequelize.DATE,
                allowNull: false,
                comment: '만료 시각'
            },
            userId: {
                type: Sequelize.INTEGER,
                allowNull: true,
                references: {
                    model: 'User',
                    key: 'id'
                },
                onUpdate: 'CASCADE',
                onDelete: 'CASCADE',
                comment: '연결된 사용자 ID'
            },
            createdAt: {
                allowNull: false,
                type: Sequelize.DATE,
                defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
            },
            updatedAt: {
                allowNull: false,
                type: Sequelize.DATE,
                defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')
            }
        });

        // 인덱스 추가 (조건부로 추가)
        try {
            await queryInterface.addIndex('PhoneVerification', ['phone']);
            await queryInterface.addIndex('PhoneVerification', ['code']);
            await queryInterface.addIndex('PhoneVerification', ['isVerified']);
            await queryInterface.addIndex('PhoneVerification', ['userId']);
            await queryInterface.addIndex('PhoneVerification', ['phone', 'isVerified']);
        } catch (error) {
            if (error.message.includes('Duplicate key name')) {
                console.log('ℹ️ 인덱스가 이미 존재함');
            } else {
                throw error;
            }
        }
    },

    down: async (queryInterface, Sequelize) => {
        await queryInterface.dropTable('PhoneVerification');
    }
}; 