'use strict';

module.exports = {
    async up(queryInterface, Sequelize) {
        // PhoneVerification 테이블에 새로운 필드들 추가 (조건부)
        try {
            await queryInterface.addColumn('PhoneVerification', 'userId', {
                type: Sequelize.INTEGER,
                allowNull: true,
                references: {
                    model: 'User',
                    key: 'id'
                },
                onUpdate: 'CASCADE',
                onDelete: 'SET NULL',
                comment: '사용자 ID (회원가입 전에는 null)'
            });
            console.log('✅ userId 컬럼 추가 완료');
        } catch (error) {
            if (error.message.includes('Duplicate column name')) {
                console.log('ℹ️ userId 컬럼이 이미 존재함');
            } else {
                throw error;
            }
        }

        try {
            await queryInterface.addColumn('PhoneVerification', 'isVerified', {
                type: Sequelize.BOOLEAN,
                allowNull: false,
                defaultValue: false,
                comment: '인증 완료 여부'
            });
            console.log('✅ isVerified 컬럼 추가 완료');
        } catch (error) {
            if (error.message.includes('Duplicate column name')) {
                console.log('ℹ️ isVerified 컬럼이 이미 존재함');
            } else {
                throw error;
            }
        }

        try {
            await queryInterface.addColumn('PhoneVerification', 'verifiedAt', {
                type: Sequelize.DATE,
                allowNull: true,
                comment: '인증 완료 일시'
            });
            console.log('✅ verifiedAt 컬럼 추가 완료');
        } catch (error) {
            if (error.message.includes('Duplicate column name')) {
                console.log('ℹ️ verifiedAt 컬럼이 이미 존재함');
            } else {
                throw error;
            }
        }

        // 인덱스 추가 (조건부)
        try {
            await queryInterface.addIndex('PhoneVerification', ['userId']);
            console.log('✅ userId 인덱스 추가 완료');
        } catch (error) {
            if (error.message.includes('Duplicate key name')) {
                console.log('ℹ️ userId 인덱스가 이미 존재함');
            } else {
                throw error;
            }
        }

        try {
            await queryInterface.addIndex('PhoneVerification', ['phone', 'isVerified']);
            console.log('✅ phone_isVerified 인덱스 추가 완료');
        } catch (error) {
            if (error.message.includes('Duplicate key name')) {
                console.log('ℹ️ phone_isVerified 인덱스가 이미 존재함');
            } else {
                throw error;
            }
        }
    },

    async down(queryInterface, Sequelize) {
        // 추가된 컬럼들 제거
        await queryInterface.removeColumn('PhoneVerification', 'userId');
        await queryInterface.removeColumn('PhoneVerification', 'isVerified');
        await queryInterface.removeColumn('PhoneVerification', 'verifiedAt');
    }
}; 