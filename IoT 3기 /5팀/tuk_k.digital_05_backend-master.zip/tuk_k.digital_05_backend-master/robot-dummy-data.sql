-- 로봇 기반 단일 카메라 구조 더미 데이터
USE kdt05__db;

-- 1. 테스트 사용자 생성
INSERT INTO User (email, password_hash, name, nickname, phone, phoneVerified, emailVerified, provider) VALUES
('test@example.com', 'dummy_hash', 'Test User', '테스터', '010-1234-5678', true, true, 'local');

-- 2. 로봇 생성
INSERT INTO Robot (user_id, robot_id, name, status, battery_level, wifi_strength, danger_level, danger_description) VALUES
(1, 'tibo-001', 'TIBO 로봇', 'online', 85, 90, 'none', '정상 상태');

-- 3. 이벤트 더미 데이터 (로봇 기반)
INSERT INTO Event (user_id, robot_id, event_type, confidence, description, image_url, location, metadata) VALUES
(1, 'tibo-001', 'baby_tracking', 0.95, '아기 추적 중 - 거리: 300mm, 명령: CENTER', 'http://192.168.0.8:8000/tracking/baby.jpg', '거실', '{"bbox": [100, 100, 50, 100], "distance_mm": 300, "command": "CENTER"}'),
(1, 'tibo-001', 'object_detection', 0.95, '사람 감지됨 - 위치: 거실, 객체 수: 2', 'http://192.168.0.8:8000/detection/person.jpg', '거실', '{"bbox": [150, 120, 60, 120], "object_type": "person", "object_count": 2}'),
(1, 'tibo-001', 'motion', 0.85, '거실에서 움직임 감지됨', 'http://192.168.0.8:8000/motion/motion1.jpg', '거실', '{"region": {"x": 0.12, "y": 0.18, "width": 0.15, "height": 0.22}}');

-- 4. 소리 이벤트 더미 데이터 (로봇 기반)
INSERT INTO SoundEvent (user_id, robot_id, sound_type, decibel_level, duration, confidence, audio_file_url, spectrogram_url, location, is_processed, detected_at) VALUES
(1, 'tibo-001', 'glass_break', 85.5, 2.3, 0.92, 'http://192.168.0.8:8000/audio/glass_break_001.wav', 'http://192.168.0.8:8000/spectrogram/glass_break_001.png', '거실', false, NOW()),
(1, 'tibo-001', 'voice', 75.2, 5.1, 0.88, 'http://192.168.0.8:8000/audio/voice_001.wav', 'http://192.168.0.8:8000/spectrogram/voice_001.png', '거실', false, NOW()),
(1, 'tibo-001', 'alarm', 90.1, 1.8, 0.95, 'http://192.168.0.8:8000/audio/alarm_001.wav', 'http://192.168.0.8:8000/spectrogram/alarm_001.png', '침실', true, NOW());

-- 5. 녹화 더미 데이터 (로봇 기반)
INSERT INTO Recording (user_id, robot_id, file_name, file_path, file_url, duration, size_bytes, recording_type) VALUES
(1, 'tibo-001', 'recording_001.mp4', '/recordings/recording_001.mp4', 'http://192.168.0.8:8000/recordings/recording_001.mp4', 120, 1024000, 'motion'),
(1, 'tibo-001', 'recording_002.mp4', '/recordings/recording_002.mp4', 'http://192.168.0.8:8000/recordings/recording_002.mp4', 180, 1536000, 'sound');

-- 6. 캡처 더미 데이터 (로봇 기반)
INSERT INTO Capture (user_id, robot_id, file_name, file_path, file_url, size_bytes, capture_type, captured_at) VALUES
(1, 'tibo-001', 'capture_001.jpg', '/captures/capture_001.jpg', 'http://192.168.0.8:8000/captures/capture_001.jpg', 2048576, 'motion', NOW()),
(1, 'tibo-001', 'capture_002.jpg', '/captures/capture_002.jpg', 'http://192.168.0.8:8000/captures/capture_002.jpg', 1536000, 'sound', NOW());

-- 7. 로봇 제어 명령 더미 데이터
INSERT INTO Command (user_id, robot_id, command_type, parameters, status, executed_at) VALUES
(1, 'tibo-001', 'MOVE_FORWARD', '{"speed": 50, "duration": 2000}', 'completed', NOW()),
(1, 'tibo-001', 'TURN_LEFT', '{"angle": 90}', 'completed', NOW()),
(1, 'tibo-001', 'STOP', '{}', 'pending', NULL);

-- 8. 알림 더미 데이터 (로봇 기반)
INSERT INTO Notification (user_id, robot_id, title, message, type, priority, is_read, metadata) VALUES
(1, 'tibo-001', '아기 추적 알림', '아기가 거실에서 감지되었습니다. (거리: 300mm)', 'baby_tracking', 'high', false, '{"event_id": 1, "distance_mm": 300}'),
(1, 'tibo-001', '객체 감지 알림', '거실에서 사람이 감지되었습니다.', 'object_detection', 'medium', false, '{"event_id": 2, "object_count": 2}'),
(1, 'tibo-001', '움직임 감지 알림', '거실에서 움직임이 감지되었습니다.', 'motion', 'medium', true, '{"event_id": 3}'),
(1, 'tibo-001', '소리 감지 알림', '거실에서 유리 깨짐 소리가 감지되었습니다.', 'sound', 'high', false, '{"sound_event_id": 1, "decibel_level": 85.5}');

-- 9. 설정 더미 데이터
INSERT INTO Settings (user_id, notification_enabled, email_notification, sms_notification, push_notification, quiet_time_start, quiet_time_end, robot_auto_follow, motion_sensitivity, sound_sensitivity) VALUES
(1, true, true, false, true, '22:00:00', '08:00:00', true, 70, 60);

SELECT '로봇 기반 단일 카메라 더미 데이터 생성 완료!' as result; 