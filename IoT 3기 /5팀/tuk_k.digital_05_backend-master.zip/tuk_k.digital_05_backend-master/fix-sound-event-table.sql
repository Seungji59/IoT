-- SoundEvent 테이블을 MQTT 문서와 일치하도록 수정
USE kdt05__db;

-- 기존 테이블 백업
CREATE TABLE SoundEvent_backup AS SELECT * FROM SoundEvent;

-- 기존 테이블 삭제
DROP TABLE SoundEvent;

-- 새로운 SoundEvent 테이블 생성 (MQTT 문서와 일치)
CREATE TABLE SoundEvent (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    camera_id INTEGER UNSIGNED NOT NULL,
    sound_type ENUM('glass_break', 'door_bell', 'alarm', 'voice', 'unknown') NOT NULL,
    decibel_level FLOAT COMMENT '소리 강도 (dB)',
    duration FLOAT COMMENT '소리 지속 시간 (초)',
    confidence FLOAT COMMENT 'AI 모델의 신뢰도 (0-1)',
    audio_file_url VARCHAR(255) COMMENT '녹음된 오디오 파일 URL',
    spectrogram_url VARCHAR(255) COMMENT '스펙트로그램 이미지 URL',
    location VARCHAR(100) COMMENT '소리 발생 위치',
    is_processed BOOLEAN DEFAULT false COMMENT '알림 처리 여부',
    detected_at DATETIME NOT NULL COMMENT '소리 감지 시간',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_camera_id (camera_id),
    INDEX idx_sound_type (sound_type),
    INDEX idx_detected_at (detected_at),
    INDEX idx_is_processed (is_processed)
) ENGINE=InnoDB;

-- 기존 데이터를 새로운 구조로 변환하여 삽입
INSERT INTO SoundEvent (camera_id, sound_type, decibel_level, duration, confidence, audio_file_url, location, is_processed, detected_at, created_at, updated_at)
SELECT 
    camera_id,
    CASE 
        WHEN event_type = 'crying' THEN 'voice'
        WHEN event_type = 'laughing' THEN 'voice'
        WHEN event_type = 'babbling' THEN 'voice'
        WHEN event_type = 'screaming' THEN 'voice'
        ELSE 'unknown'
    END as sound_type,
    NULL as decibel_level,
    duration as duration,
    confidence as confidence,
    audio_url as audio_file_url,
    '알 수 없는 위치' as location,
    false as is_processed,
    COALESCE(created_at, NOW()) as detected_at,
    created_at,
    updated_at
FROM SoundEvent_backup;

-- 백업 테이블 삭제
DROP TABLE SoundEvent_backup;

SELECT 'SoundEvent 테이블 수정 완료!' as result; 