#!/usr/bin/env node

/**
 * EMQX MQTT 클라이언트 시작 스크립트
 * 외부 EMQX 브로커에 연결하여 메시지를 중계합니다.
 */

const { emqxClient } = require('./emqx-client');

console.log('🚀 TIBO EMQX MQTT 클라이언트 시작 중...');
console.log('📡 EMQX 브로커 연결 설정:');
console.log(`   - 호스트: ${process.env.EMQX_HOST || 'localhost'}`);
console.log(`   - 포트: ${process.env.EMQX_PORT || 1883}`);
console.log(`   - 사용자명: ${process.env.EMQX_USERNAME || 'tibo'}`);
console.log('');

// EMQX 클라이언트 시작
const { emqxClient } = require('./emqx-client');

async function startEmqxClient() {
    try {
        console.log('🚀 EMQX 클라이언트 시작 중...');

        // EMQX 브로커에 연결
        await emqxClient.connect();

        // 카메라 상태 및 이벤트 구독
        emqxClient.subscribe('tibo/camera/+/status', (data) => {
            console.log('📊 카메라 상태:', data.camera_id, data.status);
        });

        emqxClient.subscribe('tibo/camera/+/motion', (data) => {
            console.log('🏃 모션 감지:', data.camera_id, data.event_type);
        });

        emqxClient.subscribe('tibo/camera/+/sound', (data) => {
            console.log('🔊 소리 감지:', data.camera_id, data.sound_type);
        });

        // 카메라 제어 결과 구독
        emqxClient.subscribe('tibo/camera/+/capture/result', (data) => {
            console.log('📸 캡처 결과:', data.camera_id, data.file_path);
        });

        emqxClient.subscribe('tibo/camera/+/recording/status', (data) => {
            console.log('📹 녹화 상태:', data.camera_id, data.status);
        });

        emqxClient.subscribe('tibo/camera/+/ptz/status', (data) => {
            console.log('🎮 PTZ 상태:', data.camera_id, data.position);
        });

        // 로봇 제어 관련 구독
        emqxClient.subscribe('robot/+/status', (data) => {
            console.log('🤖 로봇 상태:', data.robot_id, data.status);
        });

        emqxClient.subscribe('robot/+/obstacle', (data) => {
            console.log('⚠️ 장애물 감지:', data.robot_id, data.distance);
        });

        console.log('✅ EMQX 클라이언트가 성공적으로 시작되었습니다!');

    } catch (error) {
        console.error('❌ EMQX 클라이언트 시작 실패:', error);
    }
}

// 클라이언트 시작
startEmqxClient();

// 프로세스 종료 처리
process.on('SIGINT', () => {
    console.log('\n🛑 EMQX 클라이언트 종료 중...');
    emqxClient.disconnect();
    console.log('✅ EMQX 클라이언트가 안전하게 종료되었습니다.');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 EMQX 클라이언트 종료 중...');
    emqxClient.disconnect();
    console.log('✅ EMQX 클라이언트가 안전하게 종료되었습니다.');
    process.exit(0);
});

// 예상치 못한 오류 처리
process.on('uncaughtException', (error) => {
    console.error('❌ 예상치 못한 오류:', error);
    emqxClient.disconnect();
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ 처리되지 않은 Promise 거부:', reason);
    emqxClient.disconnect();
    process.exit(1);
}); 