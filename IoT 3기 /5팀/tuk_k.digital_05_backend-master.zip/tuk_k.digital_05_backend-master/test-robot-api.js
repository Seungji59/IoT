const axios = require('axios');

const BASE_URL = 'http://localhost:3000';

// 테스트용 사용자 토큰 (실제로는 로그인 후 받아야 함)
const TEST_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImlhdCI6MTcwNjM0NzgwMCwiZXhwIjoxNzA2NDM0MjAwfQ.test';

async function testRobotAPI() {
    console.log('🤖 로봇 API 테스트 시작\n');

    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${TEST_TOKEN}`
    };

    try {
        // 1. 로봇 제어 명령 전송
        console.log('1️⃣ 로봇 제어 명령 전송...');
        const commandResponse = await axios.post(`${BASE_URL}/api/robot/control`, {
            robot_id: 'tibo-001',
            command: 'MOVE_FORWARD',
            parameters: { speed: 0.5 }
        }, { headers });

        console.log('✅ 명령 전송 성공:', commandResponse.data);
        const commandId = commandResponse.data.command_id;

        // 2. 로봇 상태 조회
        console.log('\n2️⃣ 로봇 상태 조회...');
        const statusResponse = await axios.get(`${BASE_URL}/api/robot/tibo-001/status`, { headers });
        console.log('✅ 상태 조회 성공:', statusResponse.data);

        // 3. 명령 히스토리 조회
        console.log('\n3️⃣ 명령 히스토리 조회...');
        const historyResponse = await axios.get(`${BASE_URL}/api/robot/tibo-001/commands`, { headers });
        console.log('✅ 히스토리 조회 성공:', historyResponse.data);

        // 4. 다른 명령들 테스트
        console.log('\n4️⃣ 다양한 명령 테스트...');

        const commands = [
            { command: 'TURN_LEFT', parameters: { angle: 90 } },
            { command: 'TURN_RIGHT', parameters: { angle: 90 } },
            { command: 'STOP', parameters: {} },
            { command: 'HOME', parameters: {} }
        ];

        for (const cmd of commands) {
            console.log(`   - ${cmd.command} 명령 전송...`);
            const response = await axios.post(`${BASE_URL}/api/robot/control`, {
                robot_id: 'tibo-001',
                command: cmd.command,
                parameters: cmd.parameters
            }, { headers });
            console.log(`   ✅ ${cmd.command} 성공:`, response.data.message);
            await new Promise(resolve => setTimeout(resolve, 1000)); // 1초 대기
        }

        console.log('\n🎉 모든 테스트 완료!');

    } catch (error) {
        console.error('❌ 테스트 실패:', error.response?.data || error.message);
    }
}

// 테스트 실행
testRobotAPI(); 