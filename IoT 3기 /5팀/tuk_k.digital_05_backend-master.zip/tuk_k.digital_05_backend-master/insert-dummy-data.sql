-- MQTT 프로젝트 구조에 맞는 더미 데이터 삽입 스크립트
USE kdt05__db;

-- 카메라 더미 데이터 (MQTT 토픽에서 사용할 camera_id=1)
INSERT INTO Camera (user_id, name, ip_address, port, username, password, rtsp_url, status) VALUES
(1, '거실 카메라', '192.168.1.100', 554, 'admin', 'password123', 'rtsp://192.168.1.100:554/stream1', 'online'),
(1, '침실 카메라', '192.168.1.101', 554, 'admin', 'password123', 'rtsp://192.168.1.101:554/stream1', 'online');

-- Baby Tracking 이벤트 더미 데이터 (MQTT 토픽: tibo/camera/1/baby-tracking)
INSERT INTO Event (camera_id, user_id, event_type, confidence, description, image_url) VALUES
(1, 1, 'baby_tracking', 0.95, '아기 추적 중 - 거리: 300mm, 명령: CENTER', 'http://192.168.0.8:8000/tracking/baby.jpg'),
(1, 1, 'baby_tracking', 0.88, '아기 추적 중 - 거리: 450mm, 명령: LEFT', 'http://192.168.0.8:8000/tracking/baby.jpg'),
(2, 1, 'baby_tracking', 0.92, '아기 추적 중 - 거리: 200mm, 명령: STOP', 'http://192.168.0.8:8000/tracking/baby.jpg');

-- Object Detection 이벤트 더미 데이터 (MQTT 토픽: tibo/camera/1/object-detection)
INSERT INTO Event (camera_id, user_id, event_type, confidence, description, image_url) VALUES
(1, 1, 'object_detection', 0.95, '사람 감지됨 - 위치: 거실, 객체 수: 2', 'http://192.168.0.8:8000/detection/person.jpg'),
(1, 1, 'object_detection', 0.87, '아기 감지됨 - 위치: 거실, 객체 수: 1', 'http://192.168.0.8:8000/detection/baby.jpg'),
(2, 1, 'object_detection', 0.78, '사람 감지됨 - 위치: 침실, 객체 수: 1', 'http://192.168.0.8:8000/detection/person.jpg');

-- Motion Detection 이벤트 더미 데이터
INSERT INTO Event (camera_id, user_id, event_type, confidence, description, image_url) VALUES
(1, 1, 'motion', 0.85, '거실에서 움직임 감지됨', 'http://192.168.0.8:8000/motion/motion1.jpg'),
(2, 1, 'motion', 0.92, '침실에서 움직임 감지됨', 'http://192.168.0.8:8000/motion/motion2.jpg');

-- Sound Detection 이벤트 더미 데이터
INSERT INTO Event (camera_id, user_id, event_type, confidence, description, image_url) VALUES
(1, 1, 'sound', 0.88, '거실에서 울음소리 감지됨', 'http://192.168.0.8:8000/sound/crying.jpg'),
(2, 1, 'sound', 0.75, '침실에서 웃음소리 감지됨', 'http://192.168.0.8:8000/sound/laughing.jpg');

-- 녹화 더미 데이터
INSERT INTO Recording (user_id, camera_id, file_name, file_path, file_url, duration, size_bytes) VALUES
(1, 1, 'recording_001.mp4', '/recordings/recording_001.mp4', 'http://192.168.0.8:8000/recordings/recording_001.mp4', 120, 1024000),
(1, 2, 'recording_002.mp4', '/recordings/recording_002.mp4', 'http://192.168.0.8:8000/recordings/recording_002.mp4', 180, 1536000);

-- 설정 더미 데이터
INSERT INTO Settings (user_id, notification_enabled, email_notification, sms_notification, push_notification, quiet_time_start, quiet_time_end) VALUES
(1, 1, 1, 0, 1, '22:00:00', '08:00:00');

-- 알림 더미 데이터 (MQTT 이벤트에 따른 알림)
INSERT INTO Notification (user_id, title, message, type, is_read) VALUES
(1, '아기 추적 알림', '아기가 거실에서 감지되었습니다. (거리: 300mm)', 'baby_tracking', 0),
(1, '객체 감지 알림', '거실에서 사람이 감지되었습니다.', 'object_detection', 0),
(1, '움직임 감지 알림', '거실에서 움직임이 감지되었습니다.', 'motion', 1),
(1, '소리 감지 알림', '거실에서 울음소리가 감지되었습니다.', 'sound', 0);

-- 소리 이벤트 더미 데이터
INSERT INTO SoundEvent (camera_id, event_type, confidence, duration, audio_url) VALUES
(1, 'crying', 0.88, 30, 'http://192.168.0.8:8000/audio/crying1.wav'),
(2, 'laughing', 0.75, 45, 'http://192.168.0.8:8000/audio/laughing1.wav');

-- 소리 알림 더미 데이터
INSERT INTO SoundAlert (sound_event_id, user_id, alert_type, severity, is_acknowledged) VALUES
(1, 1, 'crying', 'high', 0),
(2, 1, 'unusual_sound', 'medium', 1);

-- 로봇 상태 더미 데이터
INSERT INTO RobotStatus (user_id, robot_id, status, battery_level, wifi_strength, danger_level, danger_description) VALUES
(1, 'tibo-001', 'online', 85, 90, 'none', '정상 상태'),
(1, 'tibo-002', 'online', 72, 75, 'low', '배터리 부족');

-- 로봇 제어 명령 더미 데이터
INSERT INTO Command (user_id, robot_id, command_type, parameters, status, executed_at) VALUES
(1, 'tibo-001', 'MOVE_FORWARD', '{"speed": 50, "duration": 2000}', 'completed', NOW()),
(1, 'tibo-001', 'TURN_LEFT', '{"angle": 90}', 'completed', NOW()),
(1, 'tibo-001', 'STOP', '{}', 'pending', NULL);

SELECT 'MQTT 프로젝트 구조에 맞는 더미 데이터 삽입 완료!' as result; 