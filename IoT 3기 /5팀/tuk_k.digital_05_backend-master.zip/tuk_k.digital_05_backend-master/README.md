# TIBO Smart Home Robot Camera - Backend

[![Node.js](https://img.shields.io/badge/Node.js-18+-green.svg)](https://nodejs.org/)
[![Express](https://img.shields.io/badge/Express-5.1.0-blue.svg)](https://expressjs.com/)
[![MySQL](https://img.shields.io/badge/MySQL-8.0+-orange.svg)](https://www.mysql.com/)
[![Sequelize](https://img.shields.io/badge/Sequelize-6.37.7-blue.svg)](https://sequelize.org/)
[![License](https://img.shields.io/badge/License-ISC-blue.svg)](LICENSE)

TIBO 스마트 홈 로봇 카메라의 백엔드 API 서버입니다. 실시간 카메라 스트리밍, 소리 감지, 이벤트 녹화, 사용자 인증, 알림 서비스 등을 제공합니다.

## 📋 Table of Contents

- [🚀 기술 스택](#-기술-스택)
- [📁 프로젝트 구조](#-프로젝트-구조)
- [🔧 주요 기능](#-주요-기능)
- [🛠 설치 및 실행](#-설치-및-실행)
- [📊 API 엔드포인트](#-api-엔드포인트)
- [🔒 보안 기능](#-보안-기능)
- [🧪 테스트](#-테스트)
- [📝 변경 이력](#-변경-이력)
- [❓ FAQ & Troubleshooting](#-faq--troubleshooting)
- [🤝 Contributing](#-contributing)
- [📄 라이선스](#-라이선스)

## 🚀 기술 스택

### **Core Framework**
- **Node.js** (v18+) - JavaScript 런타임
- **Express.js** (v5.1.0) - 웹 애플리케이션 프레임워크
- **Sequelize** (v6.37.7) - ORM (Object-Relational Mapping)

### **Database**
- **MySQL** (v8.0+) - 메인 데이터베이스
- **Sequelize CLI** - 데이터베이스 마이그레이션 및 시드 관리

### **Authentication & Security**
- **JWT** (jsonwebtoken v9.0.2) - 토큰 기반 인증
- **bcrypt** (v6.0.0) - 비밀번호 해싱
- **Joi** (v17.13.3) - 요청 데이터 검증
- **CORS** (v2.8.5) - Cross-Origin Resource Sharing

### **External Services**
- **Twilio** (v5.8.0) - SMS 인증 서비스
- **AWS S3** - 파일 스토리지 (녹화 파일)
- **Nodemailer** (v7.0.5) - 이메일 서비스
- **Passport** (v0.7.0) - Google OAuth 인증

### **Development Tools**
- **dotenv** (v17.2.1) - 환경 변수 관리
- **body-parser** (v2.2.0) - 요청 본문 파싱
- **axios** (v1.11.0) - HTTP 클라이언트

## 📁 프로젝트 구조

```
backend/
├── app.js                 # 애플리케이션 진입점
├── config/               # 설정 파일
│   ├── config.json      # 데이터베이스 설정
│   └── db.js           # Sequelize 설정
├── controllers/         # 컨트롤러 (API 엔드포인트)
│   ├── Auth.js         # 인증 관련 API (1352 lines)
│   ├── CameraController.js
│   ├── EventController.js
│   ├── NotificationController.js
│   ├── Profile.js
│   ├── RecordingController.js
│   ├── SettingsController.js
│   └── s3.js           # S3 파일 업로드
├── middlewares/         # 미들웨어
│   ├── authMiddleware.js
│   └── validateSignup.js
├── migrations/          # 데이터베이스 마이그레이션
│   ├── 20250127000000-create-user-table.js
│   ├── 20250127000002-create-phone-verification-table.js
│   ├── 20250127000003-create-terms-agreement-table.js
│   ├── 20250127000009-create-sound-event-table.js
│   └── 20250127000010-create-sound-alert-table.js
├── models/             # Sequelize 모델
│   ├── Camera.js
│   ├── Event.js
│   ├── Notification.js
│   ├── PhoneVerification.js
│   ├── Recording.js
│   ├── RefreshToken.js
│   ├── Settings.js
│   ├── SoundAlert.js
│   ├── SoundEvent.js
│   ├── TermsAgreement.js
│   └── User.js
├── routes/             # 라우터
│   ├── authRouter.js
│   ├── cameraRouter.js
│   ├── eventRouter.js
│   ├── notificationRouter.js
│   ├── profileRouter.js
│   ├── recordingRouter.js
│   ├── settingsRouter.js
│   └── soundDetectionRouter.js
├── service/            # 비즈니스 로직
│   ├── authService.js (1565 lines)
│   ├── CameraService.js
│   ├── emailService.js (187 lines)
│   ├── EventService.js
│   ├── googleStrategy.js
│   ├── NotificationService.js
│   ├── ProfileService.js
│   ├── RecordingService.js
│   ├── s3.js
│   ├── SettingsService.js
│   ├── smsService.js (97 lines)
│   └── SoundDetectionService.js (344 lines)
├── run-migrations.js   # 마이그레이션 실행 스크립트
├── test-server.js      # 테스트 서버
├── test-sms.js         # SMS 테스트
└── sync.js            # 데이터베이스 동기화
```

## 🔧 주요 기능

### **1. 사용자 인증 시스템**
- **회원가입**: 이메일, 휴대폰 번호, 약관 동의 (TermsAgreement 테이블)
- **휴대폰 인증**: Twilio SMS를 통한 인증번호 발송/확인
- **로그인**: JWT 토큰 기반 인증 (Access Token 1시간, Refresh Token 7일)
- **토큰 갱신**: Refresh Token을 통한 자동 갱신
- **소셜 로그인**: Google OAuth 지원 (Passport.js)
- **비밀번호 관리**: 찾기, 재설정, 변경 기능

### **2. 소리 감지 시스템** ⭐ **신규 기능**
- **실시간 소리 감지**: 라즈베리파이에서 소리 이벤트 전송
- **AI 기반 분류**: 유리 깨짐, 초인종, 알람, 목소리, 알 수 없는 소리
- **우선순위 알림**: 소리 타입별 우선순위 설정 (high/medium/low)
- **오디오 파일 저장**: AWS S3에 오디오 파일 및 스펙트로그램 저장
- **알림 발송**: 앱 내 알림, 푸시 알림, 이메일, SMS

### **3. 카메라 관리**
- **카메라 등록/해제**: 사용자별 카메라 관리
- **실시간 스트리밍**: WebRTC 지원
- **카메라 상태 모니터링**: 온라인/오프라인 상태

### **4. 이벤트 감지 및 녹화**
- **모션 감지**: 실시간 모션 이벤트 감지
- **이벤트 분류**: 위험, 경계, 움직임, 수면, 활동 등
- **자동 녹화**: 이벤트 발생 시 자동 녹화
- **클라우드 저장**: AWS S3에 녹화 파일 저장

### **5. 알림 시스템**
- **실시간 알림**: WebSocket을 통한 실시간 알림
- **푸시 알림**: 푸시 알림 서비스
- **이메일 알림**: 중요 이벤트 시 이메일 발송
- **SMS 알림**: 긴급 상황 시 SMS 발송

### **6. 설정 관리**
- **사용자 설정**: 개인화된 설정 저장
- **카메라 설정**: 해상도, 품질, 녹화 설정
- **알림 설정**: 알림 유형별 설정
- **보안 설정**: 접근 권한, 암호화 설정

## 🛠 설치 및 실행

### **1. 의존성 설치**
```bash
npm install
```

### **2. 환경 변수 설정**
```bash
# .env 파일 생성
touch .env
```

필요한 환경 변수:
```env
# Database
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=5010
DB_NAME=KDT05__db

# JWT
JWT_SECRET=your_jwt_secret
JWT_REFRESH_SECRET=your_refresh_secret

# Twilio
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=your_phone_number

# AWS S3
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=ap-northeast-2
AWS_S3_BUCKET=your_bucket_name

# Email
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password

# SMS
ENABLE_SMS=true

# Server
PORT=3000
NODE_ENV=development
```

### **3. 데이터베이스 설정**
```bash
# 마이그레이션 실행
node run-migrations.js
```

### **4. 서버 실행**
```bash
# 개발 모드
npm start

# 또는 직접 실행
node app.js
```

## 📊 API 엔드포인트

### **인증 API**
- `POST /api/auth/signup` - 회원가입 (새로운 구조)
- `POST /api/auth/login` - 로그인
- `POST /api/auth/phone/send` - 인증번호 발송
- `POST /api/auth/phone/verify` - 인증번호 확인
- `POST /api/auth/refresh` - 토큰 갱신
- `POST /api/auth/logout` - 로그아웃
- `POST /api/auth/find-id` - 아이디 찾기
- `POST /api/auth/find-password` - 비밀번호 찾기
- `POST /api/auth/change-password` - 비밀번호 변경

### **소리 감지 API** ⭐ **신규**
- `POST /api/sound-detection/event` - 소리 이벤트 전송 (라즈베리파이)
- `GET /api/sound-detection/alerts` - 소리 알림 목록 조회
- `PUT /api/sound-detection/alerts/:id/read` - 알림 읽음 처리
- `GET /api/sound-detection/stats` - 소리 감지 통계

### **카메라 API**
- `GET /api/cameras` - 카메라 목록 조회
- `POST /api/cameras` - 카메라 등록
- `PUT /api/cameras/:id` - 카메라 정보 수정
- `DELETE /api/cameras/:id` - 카메라 삭제

### **이벤트 API**
- `GET /api/events` - 이벤트 목록 조회
- `POST /api/events` - 이벤트 생성
- `GET /api/events/:id` - 이벤트 상세 조회

### **녹화 API**
- `GET /api/recordings` - 녹화 목록 조회
- `GET /api/recordings/:id` - 녹화 상세 조회
- `POST /api/recordings` - 녹화 시작
- `PUT /api/recordings/:id` - 녹화 중지

### **설정 API**
- `GET /api/settings` - 설정 조회
- `PUT /api/settings` - 설정 수정

### **프로필 API**
- `GET /api/profile` - 프로필 조회
- `PUT /api/profile` - 프로필 수정

## 🔒 보안 기능

### **1. 인증 및 권한**
- JWT 토큰 기반 인증 (Access Token 1시간, Refresh Token 7일)
- Refresh Token을 통한 자동 갱신
- 역할 기반 접근 제어 (RBAC)

### **2. 데이터 검증**
- Joi를 통한 요청 데이터 검증
- SQL Injection 방지 (Sequelize ORM)
- XSS 방지를 위한 입력 데이터 정제

### **3. 보안 헤더**
- CORS 설정으로 허용된 도메인만 접근
- Rate Limiting으로 DDoS 방지

### **4. 비밀번호 보안**
- bcrypt를 사용한 안전한 비밀번호 해싱 (SALT_ROUNDS = 10)
- 비밀번호 정책 강제

## 🧪 테스트

### **단위 테스트**
```bash
# 현재 테스트 스크립트 없음
# 향후 Jest 도입 예정
```

### **API 테스트**
```bash
# SMS 테스트
node test-sms.js

# 서버 테스트
node test-server.js
```

### **소리 감지 API 테스트**
```bash
# 소리 이벤트 전송 테스트
curl -X POST http://localhost:3000/api/sound-detection/event \
  -H "Content-Type: application/json" \
  -d '{
    "camera_id": 1,
    "sound_type": "glass_break",
    "decibel_level": 85.5,
    "duration": 2.3,
    "confidence": 0.92,
    "location": "거실"
  }'
```

## 📝 변경 이력

### **v1.0.0 (2025-01-27)**
- ✅ 기본 인증 시스템 구현
- ✅ 휴대폰 인증 시스템 구현
- ✅ Google OAuth 로그인 지원
- ✅ 소리 감지 시스템 신규 구현 ⭐
- ✅ SoundEvent, SoundAlert 테이블 추가
- ✅ 실시간 알림 시스템 구현
- ✅ AWS S3 파일 업로드 구현
- ✅ 이메일/SMS 서비스 구현

### **주요 개선사항**
1. **소리 감지 시스템**: 라즈베리파이 연동, AI 기반 소리 분류
2. **인증 시스템**: 휴대폰 인증, 약관 동의, 소셜 로그인
3. **알림 시스템**: 다중 채널 알림 (앱, 푸시, 이메일, SMS)
4. **데이터베이스**: 마이그레이션 시스템, 관계 설정

## ❓ FAQ & Troubleshooting

### **Q: 휴대폰 인증이 실패합니다**
A: 다음을 확인해주세요:
- Twilio 계정 설정이 올바른지 확인
- 휴대폰 번호 형식이 올바른지 확인 (+8210-1234-5678)
- 인증번호 만료 시간 확인 (5분)

### **Q: 소리 감지 API가 작동하지 않습니다**
A: 다음을 확인해주세요:
- 카메라 ID가 올바른지 확인
- 소리 타입이 유효한지 확인 (glass_break, door_bell, alarm, voice, unknown)
- 라즈베리파이에서 서버로의 네트워크 연결 확인

### **Q: 데이터베이스 연결 오류**
A: 다음을 확인해주세요:
- MySQL 서버가 실행 중인지 확인
- config/config.json의 데이터베이스 설정 확인
- 마이그레이션 실행: `node run-migrations.js`

### **Q: JWT 토큰 오류**
A: 다음을 확인해주세요:
- JWT_SECRET 환경 변수 설정 확인
- 토큰 만료 시간 확인 (Access Token: 1시간)
- Refresh Token으로 갱신 시도

## 🤝 Contributing

### **개발 환경 설정**
1. 프로젝트 클론
2. 의존성 설치: `npm install`
3. 환경 변수 설정
4. 데이터베이스 마이그레이션: `node run-migrations.js`
5. 개발 서버 실행: `npm start`

### **코드 스타일**
- ES6+ 문법 사용
- async/await 패턴 사용
- 에러 핸들링 필수
- JSDoc 주석 작성

### **커밋 메시지 규칙**
- `FEAT`: 새로운 기능 추가
- `FIX`: 버그 수정
- `REFACTOR`: 코드 리팩토링
- `DOCS`: 문서 수정
- `TEST`: 테스트 코드 추가

## 📄 라이선스

이 프로젝트는 [ISC 라이선스](LICENSE) 하에 배포됩니다.

---

**TIBO Smart Home Robot Camera Backend** - 안전하고 스마트한 홈 모니터링을 위한 강력한 백엔드 시스템 🏠📹🔊 

## Demo Flow (School Presentation)

1) Start backend (NMS + API)
```bash
npm start
```

2) Start synthetic RTSP source (option A: direct RTMP push to NMS)
```bash
ffmpeg -re -f lavfi -i testsrc=size=1280x720:rate=30 -f lavfi -i sine=frequency=1000 \
  -c:v libx264 -preset veryfast -tune zerolatency -c:a aac -b:a 128k -ar 48000 \
  -f flv rtmp://127.0.0.1:1935/live/1
```

3) Or use relay API with RTSP source (option B)
```bash
# DEMO_MODE=true allows no token
curl -X POST http://127.0.0.1:3000/api/cameras/1/relay/start
curl -s http://127.0.0.1:3000/api/cameras/1/relay/status
```

4) Verify HLS is ready
```bash
curl -I http://127.0.0.1:8000/live/1/index.m3u8
```

5) Open the app (Live screen) to play the HLS stream. 