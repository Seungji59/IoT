# 소리 감지 API 문서

라즈베리파이에서 소리 감지 시 서버로 데이터를 전송하는 API입니다.

## 기본 정보

- **Base URL**: `http://your-server-domain:4000`
- **Content-Type**: `application/json`

## API 엔드포인트

### 1. 소리 이벤트 전송

라즈베리파이에서 소리를 감지했을 때 호출하는 API입니다.

**POST** `/api/sound-detection/event`

#### 요청 예시

```bash
curl -X POST http://your-server-domain:4000/api/sound-detection/event \
  -H "Content-Type: application/json" \
  -d '{
    "camera_id": 1,
    "sound_type": "glass_break",
    "decibel_level": 85.5,
    "duration": 2.3,
    "confidence": 0.92,
    "audio_file_url": "https://your-s3-bucket.com/audio/event_123.wav",
    "spectrogram_url": "https://your-s3-bucket.com/spectrograms/event_123.png",
    "location": "거실"
  }'
```

#### 요청 파라미터

| 필드 | 타입 | 필수 | 설명 |
|------|------|------|------|
| `camera_id` | integer | ✅ | 카메라 ID |
| `sound_type` | string | ✅ | 소리 타입 (`glass_break`, `door_bell`, `alarm`, `voice`, `unknown`) |
| `decibel_level` | float | ❌ | 소리 강도 (dB) |
| `duration` | float | ❌ | 소리 지속 시간 (초) |
| `confidence` | float | ❌ | AI 모델의 신뢰도 (0-1, 기본값: 0.5) |
| `audio_file_url` | string | ❌ | 녹음된 오디오 파일 URL |
| `spectrogram_url` | string | ❌ | 스펙트로그램 이미지 URL |
| `location` | string | ❌ | 소리 발생 위치 |

#### 응답 예시

**성공 (201 Created)**
```json
{
  "success": true,
  "soundEvent": {
    "id": 123,
    "camera_id": 1,
    "sound_type": "glass_break",
    "decibel_level": 85.5,
    "duration": 2.3,
    "confidence": 0.92,
    "audio_file_url": "https://your-s3-bucket.com/audio/event_123.wav",
    "spectrogram_url": "https://your-s3-bucket.com/spectrograms/event_123.png",
    "location": "거실",
    "is_processed": true,
    "created_at": "2024-01-27T10:30:00.000Z",
    "detected_at": "2024-01-27T10:30:00.000Z"
  },
  "message": "소리 이벤트가 성공적으로 처리되었습니다."
}
```

**오류 (400 Bad Request)**
```json
{
  "success": false,
  "message": "카메라 ID와 소리 타입은 필수입니다."
}
```

## 소리 타입 설명

| 타입 | 설명 | 우선순위 |
|------|------|----------|
| `glass_break` | 유리 깨짐 소리 | 높음 |
| `alarm` | 알람 소리 | 높음 |
| `voice` | 인간의 목소리 | 중간 |
| `door_bell` | 초인종 소리 | 낮음 |
| `unknown` | 알 수 없는 소리 | 중간 |

## 라즈베리파이 구현 예시

### Python 예시

```python
import requests
import json
import time

def send_sound_event(camera_id, sound_type, decibel_level=None, duration=None, 
                    confidence=0.5, audio_file_url=None, spectrogram_url=None, location=None):
    """
    소리 감지 이벤트를 서버로 전송합니다.
    """
    url = "http://your-server-domain:4000/api/sound-detection/event"
    
    data = {
        "camera_id": camera_id,
        "sound_type": sound_type,
        "confidence": confidence
    }
    
    if decibel_level is not None:
        data["decibel_level"] = decibel_level
    
    if duration is not None:
        data["duration"] = duration
    
    if audio_file_url is not None:
        data["audio_file_url"] = audio_file_url
    
    if spectrogram_url is not None:
        data["spectrogram_url"] = spectrogram_url
    
    if location is not None:
        data["location"] = location
    
    try:
        response = requests.post(url, json=data, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"소리 이벤트 전송 실패: {e}")
        return None

# 사용 예시
if __name__ == "__main__":
    # 유리 깨짐 소리 감지 시
    result = send_sound_event(
        camera_id=1,
        sound_type="glass_break",
        decibel_level=85.5,
        duration=2.3,
        confidence=0.92,
        location="거실"
    )
    
    if result and result.get("success"):
        print("소리 이벤트가 성공적으로 전송되었습니다.")
    else:
        print("소리 이벤트 전송에 실패했습니다.")
```

### Node.js 예시

```javascript
const axios = require('axios');

async function sendSoundEvent(soundData) {
    try {
        const response = await axios.post(
            'http://your-server-domain:4000/api/sound-detection/event',
            soundData,
            {
                headers: {
                    'Content-Type': 'application/json'
                },
                timeout: 10000
            }
        );
        
        return response.data;
    } catch (error) {
        console.error('소리 이벤트 전송 실패:', error.message);
        return null;
    }
}

// 사용 예시
const soundData = {
    camera_id: 1,
    sound_type: 'glass_break',
    decibel_level: 85.5,
    duration: 2.3,
    confidence: 0.92,
    location: '거실'
};

sendSoundEvent(soundData).then(result => {
    if (result && result.success) {
        console.log('소리 이벤트가 성공적으로 전송되었습니다.');
    } else {
        console.log('소리 이벤트 전송에 실패했습니다.');
    }
});
```

## 오류 처리

### 일반적인 오류 코드

| 상태 코드 | 설명 | 해결 방법 |
|-----------|------|-----------|
| 400 | 잘못된 요청 데이터 | 필수 필드 확인, 데이터 타입 검증 |
| 404 | 카메라를 찾을 수 없음 | 카메라 ID 확인 |
| 500 | 서버 내부 오류 | 잠시 후 재시도 |

### 재시도 로직 예시

```python
import time

def send_sound_event_with_retry(sound_data, max_retries=3):
    """
    재시도 로직이 포함된 소리 이벤트 전송
    """
    for attempt in range(max_retries):
        try:
            result = send_sound_event(**sound_data)
            if result and result.get("success"):
                return result
        except Exception as e:
            print(f"시도 {attempt + 1} 실패: {e}")
            
        if attempt < max_retries - 1:
            time.sleep(2 ** attempt)  # 지수 백오프
    
    return None
```

## 보안 고려사항

1. **HTTPS 사용**: 프로덕션 환경에서는 반드시 HTTPS를 사용하세요.
2. **API 키 인증**: 필요시 API 키를 추가하여 인증을 구현하세요.
3. **요청 제한**: 과도한 요청을 방지하기 위해 rate limiting을 고려하세요.

## 모니터링

서버 로그에서 다음 정보를 확인할 수 있습니다:

- 소리 이벤트 수신 시간
- 처리된 알림 수
- 오류 발생 횟수
- 응답 시간

## 연락처

API 관련 문의사항이 있으시면 개발팀에 연락해주세요. 