const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const SoundAlert = sequelize.define('SoundAlert', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    sound_event_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        references: {
            model: 'SoundEvent',
            key: 'id'
        }
    },
    user_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        references: {
            model: 'User',
            key: 'id'
        }
    },
    alert_type: {
        type: DataTypes.ENUM('push', 'email', 'sms', 'in_app'),
        allowNull: false,
    },
    title: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    message: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    priority: {
        type: DataTypes.ENUM('low', 'medium', 'high', 'critical'),
        defaultValue: 'medium',
    },
    is_sent: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
    sent_at: {
        type: DataTypes.DATE,
    },
    is_read: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
    read_at: {
        type: DataTypes.DATE,
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    }
}, {
    tableName: 'SoundAlert',
    timestamps: false,
    indexes: [
        {
            fields: ['sound_event_id']
        },
        {
            fields: ['user_id']
        },
        {
            fields: ['alert_type']
        },
        {
            fields: ['is_sent']
        },
        {
            fields: ['is_read']
        },
        {
            fields: ['created_at']
        }
    ]
});

module.exports = SoundAlert;
