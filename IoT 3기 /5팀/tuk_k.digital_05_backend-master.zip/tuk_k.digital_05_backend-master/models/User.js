const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    email: {
        type: DataTypes.STRING(100),
        allowNull: false,
        unique: true,
    },
    password_hash: {
        type: DataTypes.STRING(255),
        allowNull: true, // 구글 로그인을 위해 true로 변경
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    nickname: {
        type: DataTypes.STRING(50),
        allowNull: true,
        comment: '사용자 닉네임',
    },
    bio: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: '사용자 소개글',
    },
    phone: {
        type: DataTypes.STRING(20),
        allowNull: true, // 구글 로그인을 위해 true로 변경
        unique: true,
    },
    birth: {
        type: DataTypes.DATE,
        allowNull: true,
        comment: '생년월일 (YYYY-MM-DD)',
    },
    phoneVerified: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        comment: '휴대폰 인증 완료 여부',
    },
    emailVerified: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
    },
    googleId: {
        type: DataTypes.STRING(100),
        allowNull: true,
        unique: true,
        comment: 'Google 사용자 ID',
    },
    picture: {
        type: DataTypes.TEXT,
        allowNull: true,
        comment: '프로필 사진 URL',
    },
    provider: {
        type: DataTypes.STRING(20),
        allowNull: false,
        defaultValue: 'local',
        comment: '로그인 제공자 (local, google, kakao)',
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'User',
    timestamps: false,
});

module.exports = User;
