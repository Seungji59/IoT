const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const RobotStatus = sequelize.define('RobotStatus', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    robot_id: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM('idle', 'moving', 'stopped', 'error', 'charging'),
        defaultValue: 'idle',
    },
    battery_level: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    position: {
        type: DataTypes.JSON,
        allowNull: true,
    },
    obstacle_detected: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
    },
    obstacle_distance: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    last_command: {
        type: DataTypes.STRING(50),
        allowNull: true,
    },
    error_message: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'RobotStatus',
    timestamps: false,
});

module.exports = RobotStatus; 