const sequelize = require('../config/db');
const User = require('./User');
const Camera = require('./Camera');
const Event = require('./Event');
const Recording = require('./Recording');
const Settings = require('./Settings');
const Notification = require('./Notification');
const SoundEvent = require('./SoundEvent');
const SoundAlert = require('./SoundAlert');
const RefreshToken = require('./RefreshToken');
const PhoneVerification = require('./PhoneVerification');
const TermsAgreement = require('./TermsAgreement');
const Command = require('./Command');
const RobotStatus = require('./RobotStatus');
const Capture = require('./Capture');

// User - Camera (1:N)
User.hasMany(Camera, { foreignKey: 'user_id', as: 'cameras' });
Camera.belongsTo(User, { foreignKey: 'user_id', as: 'user' });


// User - Recording (1:N)
User.hasMany(Recording, { foreignKey: 'user_id', as: 'recordings' });
Recording.belongsTo(User, { foreignKey: 'user_id', as: 'user' });


// User - Settings (1:N)
User.hasMany(Settings, { foreignKey: 'user_id', as: 'settings' });
Settings.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User - Notification (1:N)
User.hasMany(Notification, { foreignKey: 'user_id', as: 'notifications' });
Notification.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User - RefreshToken (1:N)
User.hasMany(RefreshToken, { foreignKey: 'userId', as: 'refreshTokens' });
RefreshToken.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// User - TermsAgreement (1:1)
User.hasOne(TermsAgreement, { foreignKey: 'userId', as: 'termsAgreement' });
TermsAgreement.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// User - PhoneVerification (1:N)
User.hasMany(PhoneVerification, { foreignKey: 'userId', as: 'phoneVerifications' });
PhoneVerification.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Camera - SoundEvent (1:N)

// SoundEvent - SoundAlert (1:N)
SoundEvent.hasMany(SoundAlert, { foreignKey: 'sound_event_id', as: 'soundAlerts' });
SoundAlert.belongsTo(SoundEvent, { foreignKey: 'sound_event_id', as: 'soundEvent' });

// User - SoundAlert (1:N)
User.hasMany(SoundAlert, { foreignKey: 'user_id', as: 'soundAlerts' });
SoundAlert.belongsTo(User, { foreignKey: 'user_id', as: 'user' });


// User - Command (1:N)
User.hasMany(Command, { foreignKey: 'user_id', as: 'commands' });
Command.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User - RobotStatus (1:N)
User.hasMany(RobotStatus, { foreignKey: 'user_id', as: 'robotStatuses' });
RobotStatus.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// User - Capture (1:N)
User.hasMany(Capture, { foreignKey: 'user_id', as: 'captures' });
Capture.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// Camera - Capture (1:N)
Camera.hasMany(Capture, { foreignKey: 'camera_id', as: 'captures' });
Capture.belongsTo(Camera, { foreignKey: 'camera_id', as: 'camera' });


// 데이터베이스와 모델 동기화
async function syncDatabase() {
    try {
        await sequelize.authenticate();
        console.log('✅ 데이터베이스 연결 성공.');
        await sequelize.sync({ force: false });
        console.log('✅ 모든 모델이 성공적으로 동기화되었습니다.');
    } catch (error) {
        console.error('❌ 데이터베이스 연결 또는 동기화 실패:', error);
    }
}

module.exports = {
    sequelize,
    User,
    Camera,
    Event,
    Recording,
    Settings,
    Notification,
    SoundEvent,
    SoundAlert,
    RefreshToken,
    PhoneVerification,
    TermsAgreement,
    Command,
    RobotStatus,
    Capture,
    syncDatabase,
};