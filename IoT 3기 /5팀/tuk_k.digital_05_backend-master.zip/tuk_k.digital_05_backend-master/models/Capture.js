// models/Capture.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Capture = sequelize.define('Capture', {
  id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
  user_id: { type: DataTypes.INTEGER, allowNull: true },
  camera_id: { type: DataTypes.INTEGER, allowNull: false },
  file_name: { type: DataTypes.STRING(255), allowNull: false },
  file_path: { type: DataTypes.STRING(500), allowNull: false },
  file_url:  { type: DataTypes.STRING(1000), allowNull: false },
  size_bytes:{ type: DataTypes.BIGINT.UNSIGNED, allowNull: true },
  captured_at: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
}, {
  tableName: 'captures',
  underscored: true,
  timestamps: true,          // created_at/updated_at
});

module.exports = Capture;
