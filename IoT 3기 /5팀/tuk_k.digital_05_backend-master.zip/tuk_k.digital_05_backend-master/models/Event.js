const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Event = sequelize.define('Event', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
    },
    robot_id: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    event_type: {
        type: DataTypes.ENUM('motion', 'sound', 'object_detection', 'baby_tracking'),
        allowNull: false,
    },
    confidence: {
        type: DataTypes.DECIMAL(5, 2),
    },
    description: {
        type: DataTypes.TEXT,
    },
    image_url: {
        type: DataTypes.TEXT,
    },
    location: {
        type: DataTypes.STRING(100),
    },
    metadata: {
        type: DataTypes.JSON,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
}, {
    tableName: 'Event',
    timestamps: false,
});

module.exports = Event;
