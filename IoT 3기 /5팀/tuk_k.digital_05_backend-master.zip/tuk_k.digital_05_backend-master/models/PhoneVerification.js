const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const PhoneVerification = sequelize.define('PhoneVerification', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'User',
            key: 'id'
        },
        comment: '사용자 ID (회원가입 전에는 null)',
    },
    phone: {
        type: DataTypes.STRING(20),
        allowNull: false,
    },
    code: {
        type: DataTypes.STRING(10),
        allowNull: false,
    },
    expiresAt: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    isVerified: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
        comment: '인증 완료 여부',
    },
    verifiedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        comment: '인증 완료 일시',
    },
    createdAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'PhoneVerification',
    timestamps: false,
});

module.exports = PhoneVerification; 