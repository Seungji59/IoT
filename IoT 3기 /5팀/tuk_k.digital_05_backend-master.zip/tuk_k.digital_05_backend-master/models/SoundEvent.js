const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const SoundEvent = sequelize.define('SoundEvent', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
        references: {
            model: 'User',
            key: 'id'
        }
    },
    robot_id: {
        type: DataTypes.STRING(100),
        allowNull: false,
        comment: '로봇 식별자'
    },
    sound_type: {
        type: DataTypes.ENUM('glass_break', 'door_bell', 'alarm', 'voice', 'unknown'),
        allowNull: false,
    },
    decibel_level: {
        type: DataTypes.FLOAT,
        comment: '소리 강도 (dB)'
    },
    duration: {
        type: DataTypes.FLOAT,
        comment: '소리 지속 시간 (초)'
    },
    confidence: {
        type: DataTypes.FLOAT,
        comment: 'AI 모델의 신뢰도 (0-1)'
    },
    audio_file_url: {
        type: DataTypes.STRING(255),
        comment: '녹음된 오디오 파일 URL'
    },
    spectrogram_url: {
        type: DataTypes.STRING(255),
        comment: '스펙트로그램 이미지 URL'
    },
    location: {
        type: DataTypes.STRING(100),
        comment: '소리 발생 위치'
    },
    is_processed: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        comment: '알림 처리 여부'
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
    detected_at: {
        type: DataTypes.DATE,
        allowNull: false,
        comment: '소리 감지 시간'
    }
}, {
    tableName: 'SoundEvent',
    timestamps: false,
    indexes: [
        {
            fields: ['user_id']
        },
        {
            fields: ['robot_id']
        },
        {
            fields: ['sound_type']
        },
        {
            fields: ['detected_at']
        },
        {
            fields: ['is_processed']
        }
    ]
});

module.exports = SoundEvent;
