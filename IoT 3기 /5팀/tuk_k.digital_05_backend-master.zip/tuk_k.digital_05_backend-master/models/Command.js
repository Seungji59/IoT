const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Command = sequelize.define('Command', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    robot_id: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    command: {
        type: DataTypes.ENUM('MOVE_FORWARD', 'MOVE_BACKWARD', 'TURN_LEFT', 'TURN_RIGHT', 'STOP', 'HOME'),
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM('pending', 'executing', 'completed', 'failed'),
        defaultValue: 'pending',
    },
    parameters: {
        type: DataTypes.JSON,
        allowNull: true,
    },
    executed_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    tableName: 'Command',
    timestamps: false,
});

module.exports = Command; 