const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Camera = sequelize.define('Camera', {
    id: {
        type: DataTypes.INTEGER.UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER.UNSIGNED,
        allowNull: false,
    },
    device_id: {
        type: DataTypes.STRING(50),
        unique: true,
        allowNull: false,
    },
    location: {
        type: DataTypes.STRING(100),
    },
    status: {
        type: DataTypes.ENUM('online', 'offline'),
        defaultValue: 'offline',
    },

    firmware: {
        type: DataTypes.STRING(50),
    },
    last_active: {
        type: DataTypes.DATE,
       allowNull:true,
    },
    rtsp_url: { 
        type: DataTypes.STRING, 
        allowNull: true
     },

},
 {
    tableName: 'Camera',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
});

module.exports = Camera;
