#!/bin/bash

# 백엔드 기본 기능 및 비인증 API 테스트
# TUK K-Digital IoT Robot Monitoring System

BASE_URL="http://localhost:3000"
API_BASE="$BASE_URL/api"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}   백엔드 기본 기능 테스트 (비인증 API)   ${NC}"
echo -e "${CYAN}============================================${NC}"
echo ""

log_test() {
    local test_name="$1"
    echo -e "${YELLOW}[TEST] $test_name${NC}"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_success() {
    local message="$1"
    echo -e "${GREEN}✅ SUCCESS: $message${NC}"
    PASSED_TESTS=$((PASSED_TESTS + 1))
    echo ""
}

log_error() {
    local message="$1"
    echo -e "${RED}❌ ERROR: $message${NC}"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    echo ""
}

log_info() {
    local message="$1"
    echo -e "${BLUE}ℹ️  INFO: $message${NC}"
}

# 간단한 API 호출 함수
test_api() {
    local method="$1"
    local url="$2"
    local data="$3"
    local test_name="$4"
    
    log_test "$test_name"
    
    local cmd="curl -s -w 'HTTPSTATUS:%{http_code}' -X $method '$url'"
    
    if [[ -n "$data" ]]; then
        cmd="$cmd -H 'Content-Type: application/json' -d '$data'"
    fi
    
    local response=$(eval $cmd)
    local http_code=$(echo "$response" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2)
    local body=$(echo "$response" | sed 's/HTTPSTATUS:[0-9]*$//')
    
    if [[ "$http_code" -lt 400 ]]; then
        if [[ -n "$body" ]]; then
            log_success "$test_name: HTTP $http_code - Response received (${#body} chars)"
        else
            log_success "$test_name: HTTP $http_code - OK"
        fi
    else
        log_error "$test_name: HTTP $http_code"
        if [[ -n "$body" && ${#body} -lt 200 ]]; then
            echo "Response: $body"
        fi
    fi
}

# ===========================================
# 1. 기본 서버 상태 테스트
# ===========================================
echo -e "${PURPLE}=== 1. 기본 서버 상태 테스트 ===${NC}"

test_api "GET" "$BASE_URL/" "" "서버 루트 엔드포인트"
test_api "GET" "$BASE_URL/healthz" "" "헬스체크 엔드포인트"
test_api "GET" "$BASE_URL/emqx/health" "" "EMQX 헬스체크"

# ===========================================
# 2. 비인증 API 테스트
# ===========================================
echo -e "${PURPLE}=== 2. 비인증 API 테스트 ===${NC}"

# 이메일 중복 확인
test_api "GET" "$API_BASE/auth/email-duplication?email=test@example.com" "" "이메일 중복 확인 (기존)"
test_api "GET" "$API_BASE/auth/email-duplication?email=newuser@example.com" "" "이메일 중복 확인 (신규)"

# 휴대폰 인증 (SMS 발송)
test_api "POST" "$API_BASE/auth/phone/send" '{"phone":"01012345678"}' "휴대폰 인증번호 발송"

# 비밀번호 재설정
test_api "POST" "$API_BASE/auth/find-password/send-code" '{"email":"test@example.com"}' "비밀번호 재설정 코드 발송"

# 웹소켓 정보 (비인증)
test_api "GET" "$API_BASE/websocket/info" "" "웹소켓 정보 조회"

# ===========================================
# 3. 회원가입 테스트 (데이터베이스 스키마 확인용)
# ===========================================
echo -e "${PURPLE}=== 3. 회원가입 테스트 ===${NC}"

# 새로운 사용자로 회원가입 시도
SIGNUP_DATA='{
    "email": "testuser'$(date +%s)'@example.com",
    "password": "TestPassword123!",
    "name": "테스트사용자",
    "nickname": "테스터",
    "phone": "01087654321",
    "birth": "1990-01-01",
    "code": "123456",
    "agreeTerms": true,
    "agreePrivacy": true,
    "agreeMicrophone": true,
    "agreeLocation": true,
    "agreeMarketing": false
}'

test_api "POST" "$API_BASE/auth/signup" "$SIGNUP_DATA" "새 사용자 회원가입"

# ===========================================
# 4. 로그인 테스트 (다양한 비밀번호 시도)
# ===========================================
echo -e "${PURPLE}=== 4. 로그인 테스트 ===${NC}"

# 다양한 비밀번호로 로그인 시도
test_api "POST" "$API_BASE/auth/login" '{"email":"test@example.com","password":"test123"}' "로그인 시도 (test123)"
test_api "POST" "$API_BASE/auth/login" '{"email":"test@example.com","password":"password123"}' "로그인 시도 (password123)"
test_api "POST" "$API_BASE/auth/login" '{"email":"test@example.com","password":"admin123"}' "로그인 시도 (admin123)"

# ===========================================
# 5. 에러 처리 테스트
# ===========================================
echo -e "${PURPLE}=== 5. 에러 처리 테스트 ===${NC}"

# 잘못된 요청들
test_api "GET" "$API_BASE/nonexistent" "" "존재하지 않는 엔드포인트"
test_api "POST" "$API_BASE/auth/login" '{"email":"invalid"}' "잘못된 로그인 데이터"
test_api "POST" "$API_BASE/auth/signup" '{"email":"test"}' "불완전한 회원가입 데이터"

# ===========================================
# 6. CORS 및 HTTP 메서드 테스트
# ===========================================
echo -e "${PURPLE}=== 6. HTTP 메서드 테스트 ===${NC}"

test_api "OPTIONS" "$API_BASE/auth/login" "" "OPTIONS 메서드 (CORS)"
test_api "HEAD" "$BASE_URL/" "" "HEAD 메서드"

# ===========================================
# 7. 대용량 데이터 처리 테스트
# ===========================================
echo -e "${PURPLE}=== 7. 데이터 처리 테스트 ===${NC}"

# 큰 JSON 데이터
LARGE_DATA='{"email":"test@example.com","password":"test123","data":"'$(python3 -c "print('x' * 1000)")'}'
test_api "POST" "$API_BASE/auth/login" "$LARGE_DATA" "대용량 데이터 처리"

# 빈 요청
test_api "POST" "$API_BASE/auth/login" '{}' "빈 JSON 요청"

# ===========================================
# 8. 특수 문자 처리 테스트
# ===========================================
echo -e "${PURPLE}=== 8. 특수 문자 처리 테스트 ===${NC}"

test_api "GET" "$API_BASE/auth/email-duplication?email=test%40example.com" "" "URL 인코딩된 이메일"
test_api "POST" "$API_BASE/auth/login" '{"email":"test@example.com","password":"한글비밀번호123!@#"}' "특수문자 비밀번호"

# ===========================================
# 9. API 응답 시간 테스트
# ===========================================
echo -e "${PURPLE}=== 9. 응답 시간 테스트 ===${NC}"

log_test "API 응답 시간 측정"
start_time=$(date +%s%N)
response=$(curl -s "$BASE_URL/healthz")
end_time=$(date +%s%N)
duration=$(( (end_time - start_time) / 1000000 ))

if [[ $duration -lt 1000 ]]; then
    log_success "API 응답 시간: ${duration}ms (1초 미만)"
else
    log_error "API 응답 시간: ${duration}ms (1초 이상)"
fi

# ===========================================
# 10. 동시 요청 테스트
# ===========================================
echo -e "${PURPLE}=== 10. 동시 요청 테스트 ===${NC}"

log_test "동시 요청 처리 능력"

# 5개의 동시 요청
for i in {1..5}; do
    curl -s "$BASE_URL/healthz" > /dev/null &
done
wait

log_success "동시 요청 처리 완료"

# ===========================================
# 결과 요약
# ===========================================
echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}          테스트 결과 요약                   ${NC}"
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}✅ 성공: $PASSED_TESTS${NC}"
echo -e "${RED}❌ 실패: $FAILED_TESTS${NC}"
echo -e "${BLUE}📊 전체: $TOTAL_TESTS${NC}"

if [ $TOTAL_TESTS -gt 0 ]; then
    success_rate=$(( (PASSED_TESTS * 100) / TOTAL_TESTS ))
    echo -e "${BLUE}📈 성공률: $success_rate%${NC}"
fi

echo ""
echo -e "${CYAN}🎯 테스트 완료된 기본 기능:${NC}"
echo -e "${BLUE}   ✓ 서버 상태 확인${NC}"
echo -e "${BLUE}   ✓ 헬스체크 엔드포인트${NC}"
echo -e "${BLUE}   ✓ 비인증 API 호출${NC}"
echo -e "${BLUE}   ✓ 회원가입 프로세스${NC}"
echo -e "${BLUE}   ✓ 로그인 시도${NC}"
echo -e "${BLUE}   ✓ 에러 처리${NC}"
echo -e "${BLUE}   ✓ HTTP 메서드 지원${NC}"
echo -e "${BLUE}   ✓ 데이터 처리${NC}"
echo -e "${BLUE}   ✓ 특수 문자 처리${NC}"
echo -e "${BLUE}   ✓ 응답 시간 성능${NC}"
echo -e "${BLUE}   ✓ 동시 요청 처리${NC}"

echo ""
if [ $FAILED_TESTS -eq 0 ]; then
    echo -e "${GREEN}🎉 기본 기능 테스트가 성공적으로 완료되었습니다!${NC}"
    echo -e "${GREEN}🚀 백엔드 서버가 정상적으로 작동하고 있습니다.${NC}"
    echo ""
    echo -e "${BLUE}💡 다음 단계:${NC}"
    echo -e "${BLUE}   1. 데이터베이스 스키마 문제 해결${NC}"
    echo -e "${BLUE}   2. 유효한 사용자 계정으로 로그인 테스트${NC}"
    echo -e "${BLUE}   3. 인증이 필요한 API 테스트${NC}"
    exit 0
else
    echo -e "${YELLOW}⚠️  일부 기본 기능에서 문제가 발견되었습니다.${NC}"
    echo -e "${BLUE}💡 실패한 테스트들을 확인하여 문제를 해결해주세요.${NC}"
    exit 1
fi 