const mqtt = require('mqtt');

/**
 * EMQX MQTT 브로커 클라이언트
 * 외부 EMQX 브로커에 연결하여 메시지를 중계합니다.
 */

class EMQXClient {
    constructor() {
        this.client = null;
        this.isConnected = false;
        this.messageHandlers = new Map();
        this.connectionListeners = new Set();

        // EMQX 브로커 설정
        this.config = {
            host: process.env.EMQX_HOST || 'localhost',
            port: process.env.EMQX_PORT || 1883,
            username: process.env.EMQX_USERNAME || 'tibo',
            password: process.env.EMQX_PASSWORD || '1q2w3e4r',
            clientId: `tibo-server-${Date.now()}`,
            clean: true,
            reconnectPeriod: 5000,
            connectTimeout: 30000
        };
    }

    /**
     * EMQX 브로커에 연결
     */
    async connect() {
        try {
            const brokerUrl = `mqtt://${this.config.host}:${this.config.port}`;

            console.log(`🔗 EMQX 브로커에 연결 중: ${brokerUrl}`);

            this.client = mqtt.connect(brokerUrl, {
                clientId: this.config.clientId,
                username: this.config.username,
                password: this.config.password,
                clean: this.config.clean,
                reconnectPeriod: this.config.reconnectPeriod,
                connectTimeout: this.config.connectTimeout
            });

            this.setupEventHandlers();

            return new Promise((resolve, reject) => {
                const timeout = setTimeout(() => {
                    reject(new Error('EMQX 연결 타임아웃'));
                }, this.config.connectTimeout);

                this.client.once('connect', () => {
                    clearTimeout(timeout);
                    this.isConnected = true;
                    console.log('✅ EMQX 브로커에 연결되었습니다!');
                    this.notifyConnectionListeners(true);
                    resolve(true);
                });

                this.client.once('error', (error) => {
                    clearTimeout(timeout);
                    console.error('❌ EMQX 연결 오류:', error);
                    reject(error);
                });
            });

        } catch (error) {
            console.error('❌ EMQX 연결 실패:', error);
            throw error;
        }
    }

    /**
     * 이벤트 핸들러 설정
     */
    setupEventHandlers() {
        this.client.on('connect', () => {
            console.log('✅ EMQX 브로커에 연결됨');
            this.isConnected = true;
            this.notifyConnectionListeners(true);
        });

        this.client.on('message', (topic, message) => {
            try {
                const text = message.toString();
                let data;
                try { data = JSON.parse(text); } catch (_) { data = text; }
                console.log(`📨 메시지 수신: ${topic}`, data);
                this.handleMessage(topic, data);
            } catch (error) {
                console.error('❌ 메시지 처리 오류:', error);
            }
        });

        this.client.on('error', (error) => {
            console.error('❌ EMQX 클라이언트 오류:', error);
            this.isConnected = false;
            this.notifyConnectionListeners(false);
        });

        this.client.on('close', () => {
            console.log('🔌 EMQX 브로커 연결 종료');
            this.isConnected = false;
            this.notifyConnectionListeners(false);
        });

        this.client.on('reconnect', () => {
            console.log('🔄 EMQX 브로커 재연결 시도...');
        });
    }

    /**
     * MQTT 와일드카드 매칭 체크
     */
    matchesPattern(pattern, topic) {
        if (pattern === topic) return true;
        if (pattern === '*') return true;

        const patternLevels = pattern.split('/');
        const topicLevels = topic.split('/');

        for (let i = 0; i < patternLevels.length; i++) {
            const p = patternLevels[i];
            const t = topicLevels[i];

            if (p === '#') {
                return true;
            }
            if (p === '+') {
                if (t === undefined) return false;
                continue;
            }
            if (t === undefined) return false;
            if (p !== t) return false;
        }
        return patternLevels.length === topicLevels.length;
    }

    /**
     * 메시지 핸들링
     */
    handleMessage(topic, data) {
        if (this.messageHandlers.has(topic)) {
            this.messageHandlers.get(topic).forEach(handler => {
                try { handler(data); } catch (error) {
                    console.error(`❌ 토픽 핸들러 오류 (${topic}):`, error);
                }
            });
        }
        for (const [pattern, handlers] of this.messageHandlers.entries()) {
            if (pattern === topic) continue;
            if (this.matchesPattern(pattern, topic)) {
                handlers.forEach(handler => {
                    try { handler(data); } catch (error) {
                        console.error(`❌ 토픽 핸들러 오류 (${pattern}):`, error);
                    }
                });
            }
        }
        if (this.messageHandlers.has('*')) {
            this.messageHandlers.get('*').forEach(handler => {
                try { handler({ topic, data }); } catch (error) {
                    console.error('❌ 와일드카드 핸들러 오류:', error);
                }
            });
        }
    }

    /**
     * 토픽 구독
     */
    subscribe(topic, handler) {
        if (!this.isConnected || !this.client) {
            console.error('❌ EMQX에 연결되지 않았습니다. 구독 불가');
            return false;
        }

        if (!this.messageHandlers.has(topic)) {
            this.messageHandlers.set(topic, new Set());
        }
        this.messageHandlers.get(topic).add(handler);

        this.client.subscribe(topic, (err) => {
            if (err) {
                console.error(`❌ 토픽 구독 실패: ${topic}`, err);
            } else {
                console.log(`✅ 토픽 구독 성공: ${topic}`);
            }
        });

        return true;
    }

    /**
     * 토픽 구독 해제
     */
    unsubscribe(topic, handler) {
        if (this.messageHandlers.has(topic)) {
            this.messageHandlers.get(topic).delete(handler);
        }
    }

    /**
     * 메시지 발행 (retry with backoff)
     */
    async publishAsync(topic, message, options = {}) {
        if (!this.isConnected || !this.client) {
            console.error('❌ EMQX에 연결되지 않았습니다. 발행 불가');
            return false;
        }

        const payload = typeof message === 'string' ? message : JSON.stringify(message);
        const maxRetries = options.maxRetries ?? 3;
        for (let attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                await new Promise((resolve, reject) => {
                    this.client.publish(topic, payload, options, (err) => {
                        if (err) reject(err); else resolve(true);
                    });
                });
                console.log(`✅ 메시지 발행 성공: ${topic}`);
                return true;
            } catch (err) {
                const delay = Math.min(1000 * (attempt + 1), 5000);
                console.warn(`⚠️ 발행 실패(${attempt + 1}/${maxRetries + 1}): ${topic}. ${delay}ms 후 재시도`);
                await new Promise(r => setTimeout(r, delay));
            }
        }
        console.error(`❌ 메시지 발행 최종 실패: ${topic}`);
        return false;
    }

    /**
     * 연결 상태 구독
     */
    onConnectionChange(handler) {
        this.connectionListeners.add(handler);
    }

    /**
     * 연결 상태 구독 해제
     */
    offConnectionChange(handler) {
        this.connectionListeners.delete(handler);
    }

    /**
     * 연결 상태 리스너들에게 알림
     */
    notifyConnectionListeners(connected) {
        this.connectionListeners.forEach(handler => {
            try {
                handler(connected);
            } catch (error) {
                console.error('❌ 연결 상태 리스너 오류:', error);
            }
        });
    }

    /**
     * 연결 해제
     */
    disconnect() {
        if (this.client) {
            this.client.end();
            this.client = null;
            this.isConnected = false;
            this.messageHandlers.clear();
            this.connectionListeners.clear();
            console.log('🔌 EMQX 연결 해제됨');
        }
    }

    /**
     * 연결 상태 확인
     */
    getConnectionStatus() {
        return this.isConnected;
    }

    /**
     * 현재 구독 중인 토픽 목록
     */
    getSubscribedTopics() {
        return Array.from(this.messageHandlers.keys());
    }

    /**
     * 헬스체크 정보
     */
    getHealthInfo() {
        return {
            status: this.isConnected ? 'connected' : 'disconnected',
            timestamp: new Date().toISOString(),
            broker: `${this.config.host}:${this.config.port}`,
            clientId: this.config.clientId,
            topics: this.getSubscribedTopics()
        };
    }
}

// 싱글톤 인스턴스 생성
const emqxClient = new EMQXClient();

module.exports = {
    EMQXClient,
    emqxClient
}; 