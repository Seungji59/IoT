// media/ffmpegRelay.js
// 스트림 변환
const { spawn } = require('child_process');
require('dotenv').config();

const FFMPEG = process.env.FFMPEG_PATH || 'ffmpeg';
const RTMP_HOST = process.env.NMS_RTMP_HOST || '127.0.0.1';
const RTMP_PORT = Number(process.env.NMS_RTMP_PORT || 1935);
const APP_NAME  = process.env.NMS_APP_NAME || 'live';

const relays = new Map();

/**
 * RTSP -> RTMP 릴레이 시작
 * @param {Object} params
 * @param {string} params.cameraId   - 카메라 ID
 * @param {string} params.rtspUrl    - RTSP URL
 * @param {('copy'|'h264')} [params.videoCodec='copy'] - 비디오 파이프라인
 * @param {('aac'|'copy'|'none')} [params.audioCodec='aac'] - 오디오 파이프라인
 * @param {number} [params.gop=60]   - GOP(키프레임) 간격(30fps 기준 60 권장)
 * @param {number} [params.audioBitrateK=128] - AAC 비트레이트 kbps
 * @param {number} [params.audioSampleRate=48000] - AAC 샘플레이트
 */

function startRelay({
  cameraId,
  rtspUrl,
  videoCodec = 'copy',
  audioCodec = 'aac',
  gop = 60,
  audioBitrateK = 128,
  audioSampleRate = 48000,
} = {}) {
  if (!cameraId || !rtspUrl) {
    throw new Error('cameraId와 rtspUrl은 필수입니다.');
  }
  if (relays.has(cameraId)) {
    return { ok: true, message: 'already running' };
  }

  const rtmpUrl = `rtmp://${RTMP_HOST}:${RTMP_PORT}/${APP_NAME}/${cameraId}`;

  // 입력 안정화 옵션
  const inArgs = [
    '-rtsp_transport', 'tcp',
    '-i', rtspUrl,
    // 네트워크 버퍼 지연 최소화
    '-fflags', 'nobuffer',
    '-flags', 'low_delay',
    '-max_delay', '0',
  ];

  // 비디오 파이프라인
  let vArgs;
  if (videoCodec === 'h264') {
    vArgs = [
      '-c:v', 'libx264',
      '-preset', 'veryfast',
      '-tune', 'zerolatency',
      '-g', String(gop),
      // 필요 시 프로파일/레벨 지정 가능:
      // '-profile:v', 'baseline', '-level', '3.1',
    ];
  } else {
    vArgs = ['-c:v', 'copy'];
  }

  // 오디오 파이프라인
  let aArgs = [];
  if (audioCodec === 'none') aArgs = ['-an']; // 오디오 제거
  else if (audioCodec === 'copy') aArgs = ['-map', '0:v:0','-map', '0:a:0?','-c:a', 'copy',];
  else aArgs = ['-map', '0:v:0','-map', '0:a:0?','-c:a', 'aac', '-b:a', `${audioBitrateK}k`,'-ar', String(audioSampleRate),'-ac', '2',];
  
  const outArgs = ['-f', 'flv', rtmpUrl];
  const args = [...inArgs, ...vArgs, ...aArgs, ...outArgs];

  console.log(`[Relay] starting ${cameraId}`);
  console.log(`[Relay] ${rtspUrl} -> ${rtmpUrl}`);
  console.log(`[Relay] args: ${args.join(' ')}`);

  const proc = spawn(FFMPEG, args, { stdio: ['ignore', 'pipe', 'pipe'] });

  proc.stdout.on('data', (d) => {
    console.log(`[Relay:${cameraId}:stdout] ${d.toString()}`);
  });
  proc.stderr.on('data', (d) => {
    console.log(`[Relay:${cameraId}:stderr] ${d.toString()}`);
  });
  proc.on('close', (code) => {
    console.log(`[Relay] stopped ${cameraId} (code=${code})`);
    relays.delete(cameraId);
  });

  relays.set(cameraId, { proc, args, startedAt: Date.now() });

  return { ok: true, rtmpUrl };
}

/**
 * 릴레이 중지
 */
function stopRelay(cameraId) {
  const r = relays.get(cameraId);
  if (!r) return { ok: true, message: 'not running' };
  try {
    r.proc.kill('SIGTERM');
  } catch (_) {}
  relays.delete(cameraId);
  return { ok: true };
}

/**
 * 릴레이 실행 여부
 */
function isRunning(cameraId) {
  return relays.has(cameraId);
}

/**
 * 전체 상태 확인 (디버그용)
 */
function listRelays() {
  return Array.from(relays.keys());
}

module.exports = {
  startRelay,
  stopRelay,
  isRunning,
  listRelays,
};
