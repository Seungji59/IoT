//mediaServer.js
//미디어 엔진
const path = require('path');
const NodeMediaServer = require('node-media-server');
require('dotenv').config();

//기본 경로/포트 설정
const MEDIA_ROOT = process.env.NMS_MEDIA_ROOT || path.join(__dirname, 'media');
const RTMP_PORT = Number(process.env.NMS_RTMP_PORT || 1935);
const HTTP_PORT = Number(process.env.NMS_HTTP_PORT || 8000);
const FFMPEG_PATH = process.env.FFMPEG_PATH || 'ffmpeg';
const APP_NAME = process.env.NMS_APP_NAME || 'live';

// 외부 노출용 HLS 베이스 URL
const HLS_BASE_URL = process.env.HLS_BASE_URL || `http://localhost:${HTTP_PORT}`;

const config = {
  rtmp: {
    port: RTMP_PORT,
    chunk_size: 60000,
    gop_cache: true,
    ping: 30,
    ping_timeout: 60
  },
  http: {
    port: HTTP_PORT,
    mediaroot: MEDIA_ROOT,
    allow_origin: '*'
  },
  trans: {
    ffmpeg: FFMPEG_PATH, // ffmpeg 경로
    tasks: [
      {
        app: APP_NAME,
        hls: true,
        hlsFlags: '[hls_time=2:hls_list_size=3:hls_flags=delete_segments]',
        hlsKeep: false,
        dash: false,
        dashKeep: false
      }
    ]
  }
};

const nms = new NodeMediaServer(config);

//퍼블리시 시작 시각을 streamPath 기준으로 추적
const publishStartAt = new Map();

nms.on('prePublish', (id, streamPath) => {
  try {
    publishStartAt.set(streamPath, Date.now());
    console.log(`[NMS] prePublish id=${id} streamPath=${streamPath}`);
  } catch (e) {
    console.error('[NMS] prePublish error:', e);
  }
});

// 퍼블리시 종료-> DB기록+접근 URL 반환
nms.on('donePublish', async (id, streamPath) => {
  try {
    const startedAt = publishStartAt.get(streamPath) || Date.now();
    publishStartAt.delete(streamPath);

    // streamPath 
    const [appName, cameraId] = (streamPath || '').split('/').filter(Boolean);
    if (!appName || !cameraId) {
      console.warn('[NMS] donePublish: invalid streamPath ->', streamPath);
      return;
    }

    //NMS HLS 인덱스 경로/URL
    const hlsRel = `/${appName}/${cameraId}/index.m3u8`; // 서버 상대경로
    const fileUrl = `${HLS_BASE_URL}${hlsRel}`;          // 클라이언트 재생 URL
    const duration = Math.max(0, Math.floor((Date.now() - startedAt) / 1000));

    //모델 동적 로드
    let Recording, Camera;
    try {
      ({ Recording, Camera } = require('../models'));
    } catch (_) {
      console.warn('[NMS] models not available at runtime; skipping DB write');
    }

    let userId = null;
    if (Camera) {
      try {
        const camera = await Camera.findOne({ where: { id: cameraId } });
        userId = camera ? camera.user_id : null;
      } catch (e) {
        console.warn('[NMS] Camera lookup failed:', e?.message || e);
      }
    }

    // Recording 테이블에 기록
    if (Recording) {
      try {
        await Recording.create({
          user_id: userId,
          camera_id: cameraId,
          file_name: 'index.m3u8',
          file_url: fileUrl,
          started_at: new Date(startedAt),
          ended_at: new Date(),
          duration
        });
        console.log(`[NMS] Recording created for camera ${cameraId}: ${fileUrl}`);
      } catch (e) {
        console.error('[NMS] Failed to write Recording:', e?.message || e);
      }
    }

    try {
      const { notificationService } = require('../service/NotificationService');
      if (notificationService?.sendRealTimeNotification) {
        await notificationService.sendRealTimeNotification(userId || 1, {
          type: 'recording_completed',
          title: '녹화 완료',
          message: `카메라 ${cameraId} 녹화가 완료되었습니다.`,
          data: { camera_id: cameraId, file_url: fileUrl, duration }
        });
      }
    } catch (_) {
      // 알림 서비스 구현 예정
    }
  } catch (err) {
    console.error('[NMS] donePublish error:', err?.message || err);
  }
});

nms.run();

module.exports = { nms, config };

