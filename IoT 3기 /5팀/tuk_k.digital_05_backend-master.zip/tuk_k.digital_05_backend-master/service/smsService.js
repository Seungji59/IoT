const twilio = require('twilio');
require('dotenv').config();

// Twilio 클라이언트 초기화
const twilioClient = twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
);

// Twilio SMS 발송 함수
const sendTwilioSMS = async (to, message) => {
    try {
        console.log('📱 [TWILIO] SMS 발송 시도');
        console.log('  📦 요청 데이터:', { to, message });

        // E.164 형식으로 번호 정리 (공백 제거)
        let formattedTo;

        // 모든 공백과 특수문자 제거
        const cleanNumber = to.replace(/[\s\-\(\)]/g, '');

        console.log('📱 [TWILIO] 번호 정리 과정:');
        console.log(`  📱 원본 번호: ${to}`);
        console.log(`  🧹 정리된 번호: ${cleanNumber}`);

        if (cleanNumber.startsWith('+8210') && cleanNumber.length === 13) {
            // 이미 올바른 E.164 형식
            formattedTo = cleanNumber;
            console.log('  ✅ 이미 E.164 형식');
        } else if (cleanNumber.startsWith('010') && cleanNumber.length === 11) {
            // 한국 휴대폰 번호를 E.164로 변환
            const remaining = cleanNumber.slice(3); // 010 제거
            formattedTo = `+8210${remaining}`;
            console.log('  🔄 한국 번호 → E.164 변환');
        } else if (cleanNumber.startsWith('+82') && cleanNumber.includes('10')) {
            // 공백이 포함된 +82 형식 정리
            formattedTo = cleanNumber.replace(/\s/g, '');
            console.log('  🧹 +82 형식 정리');
        } else {
            formattedTo = cleanNumber;
            console.log('  ⚠️ 변환 없이 사용');
        }

        console.log('📱 [TWILIO] 최종 번호 정보:');
        console.log(`  📱 최종 번호: ${formattedTo}`);
        console.log(`  📏 길이: ${formattedTo.length}`);
        console.log(`  ✅ E.164 표준: ${formattedTo.match(/^\+[1-9]\d{1,14}$/) ? '준수' : '위반'}`);

        // Twilio 설정 확인
        console.log('🔧 [TWILIO] 설정 확인:');
        console.log(`  📞 발신번호: ${process.env.TWILIO_PHONE_NUMBER}`);
        console.log(`  🔑 Account SID: ${process.env.TWILIO_ACCOUNT_SID ? '설정됨' : '미설정'}`);
        console.log(`  🔐 Auth Token: ${process.env.TWILIO_AUTH_TOKEN ? '설정됨' : '미설정'}`);

        const result = await twilioClient.messages.create({
            body: message,
            from: process.env.TWILIO_PHONE_NUMBER,
            to: formattedTo
        });

        console.log('✅ [TWILIO] SMS 발송 성공');
        console.log(`  📋 메시지 ID: ${result.sid}`);
        console.log(`  📱 수신번호: ${formattedTo}`);
        console.log(`  📞 발신번호: ${process.env.TWILIO_PHONE_NUMBER}`);
        console.log(`  📄 메시지: ${message}`);

        return { success: true, messageId: result.sid };
    } catch (error) {
        console.error('❌ [TWILIO] SMS 발송 실패');
        console.error(`  📝 에러 메시지: ${error.message}`);
        console.error(`  🔍 에러 코드: ${error.code || 'N/A'}`);
        console.error(`  📱 수신번호: ${to}`);
        console.error(`  📞 발신번호: ${process.env.TWILIO_PHONE_NUMBER}`);

        return { success: false, error: error.message };
    }
};



const sendSMS = async (phone, message) => {
    // Twilio 사용 (네이버 SMS 대신)
    return await sendTwilioSMS(phone, message);
};

const sendVerificationSMS = async (phone, code) => {
    const message = `[K디지털] 인증번호는 ${code}입니다. 3분 내에 입력해주세요.`;

    // Twilio 사용
    return await sendTwilioSMS(phone, message);
};

module.exports = {
    sendSMS,
    sendVerificationSMS,
    sendTwilioSMS
}; 