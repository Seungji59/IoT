const { SoundEvent, SoundAlert, Notification, User, Camera, sequelize } = require('../models');
const { Op } = require('sequelize');

class SoundDetectionService {
    /**
     * 소리 이벤트를 생성하고 알림을 발송합니다.
     * @param {Object} soundData - 소리 감지 데이터
     * @param {number} soundData.user_id - 사용자 ID
     * @param {string} soundData.robot_id - 로봇 ID
     * @param {string} soundData.sound_type - 소리 타입
     * @param {number} soundData.decibel_level - 소리 강도
     * @param {number} soundData.duration - 소리 지속 시간
     * @param {number} soundData.confidence - AI 신뢰도
     * @param {string} soundData.audio_file_url - 오디오 파일 URL
     * @param {string} soundData.spectrogram_url - 스펙트로그램 URL
     * @param {string} soundData.location - 소리 발생 위치
     */
    async createSoundEvent(soundData) {
        try {
            // 소리 이벤트 생성
            const soundEvent = await SoundEvent.create({
                user_id: soundData.user_id,
                robot_id: soundData.robot_id,
                sound_type: soundData.sound_type,
                decibel_level: soundData.decibel_level,
                duration: soundData.duration,
                confidence: soundData.confidence,
                audio_file_url: soundData.audio_file_url,
                spectrogram_url: soundData.spectrogram_url,
                location: soundData.location,
                detected_at: new Date(),
                is_processed: false
            });

            // 사용자 정보 조회
            const user = await User.findByPk(soundData.user_id);

            if (!user) {
                throw new Error('사용자 정보를 찾을 수 없습니다.');
            }

            // 알림 생성 및 발송
            await this.createSoundAlerts(soundEvent, user);

            // 소리 이벤트를 처리 완료로 표시
            await soundEvent.update({ is_processed: true });

            return {
                success: true,
                soundEvent,
                message: '소리 이벤트가 성공적으로 처리되었습니다.'
            };

        } catch (error) {
            console.error('소리 이벤트 생성 중 오류:', error);
            throw error;
        }
    }

    /**
     * 소리 이벤트에 대한 알림을 생성합니다.
     * @param {Object} soundEvent - 소리 이벤트 객체
     * @param {Object} user - 사용자 객체
     */
    async createSoundAlerts(soundEvent, user) {
        try {
            const soundTypeMessages = {
                'glass_break': '유리 깨짐 소리가 감지되었습니다.',
                'door_bell': '초인종 소리가 감지되었습니다.',
                'alarm': '알람 소리가 감지되었습니다.',
                'voice': '인간의 목소리가 감지되었습니다.',
                'unknown': '알 수 없는 소리가 감지되었습니다.'
            };

            const priorityMap = {
                'glass_break': 'high',
                'alarm': 'high',
                'voice': 'medium',
                'door_bell': 'low',
                'unknown': 'medium'
            };

            const message = soundTypeMessages[soundEvent.sound_type] || '소리가 감지되었습니다.';
            const priority = priorityMap[soundEvent.sound_type] || 'medium';

            // 앱 내 알림 생성
            const inAppAlert = await SoundAlert.create({
                sound_event_id: soundEvent.id,
                user_id: user.id,
                alert_type: 'in_app',
                title: '소리 감지 알림',
                message: `${message} (${soundEvent.location})`,
                priority: priority,
                is_sent: true,
                sent_at: new Date()
            });

            // 일반 알림 테이블에도 추가
            await Notification.create({
                user_id: user.id,
                type: 'sound',
                message: `${message} (${soundEvent.location})`,
                is_read: false,
                sound_event_id: soundEvent.id,
                priority: priority
            });

            // 푸시 알림 발송 (실제 구현 시 사용)
            if (user.push_token) {
                await this.sendPushNotification(user.push_token, '소리 감지 알림', message);
            }

            // 이메일 알림 발송 (필요시)
            if (user.email && user.email_notifications) {
                await this.sendEmailNotification(user.email, '소리 감지 알림', message);
            }

            return {
                success: true,
                alerts: [inAppAlert],
                message: '알림이 성공적으로 생성되었습니다.'
            };

        } catch (error) {
            console.error('알림 생성 중 오류:', error);
            throw error;
        }
    }

    /**
     * 푸시 알림을 발송합니다.
     * @param {string} token - 푸시 토큰
     * @param {string} title - 알림 제목
     * @param {string} message - 알림 메시지
     */
    async sendPushNotification(token, title, message) {
        try {
            // 푸시 서비스 구현
            console.log(`푸시 알림 발송: ${title} - ${message} to ${token}`);
            // 실제 구현 시 푸시 서비스 사용
        } catch (error) {
            console.error('푸시 알림 발송 실패:', error);
        }
    }

    /**
     * 이메일 알림을 발송합니다.
     * @param {string} email - 이메일 주소
     * @param {string} subject - 이메일 제목
     * @param {string} message - 이메일 내용
     */
    async sendEmailNotification(email, subject, message) {
        try {
            // 이메일 서비스 구현
            console.log(`이메일 알림 발송: ${subject} - ${message} to ${email}`);
            // 실제 구현 시 이메일 서비스 사용
        } catch (error) {
            console.error('이메일 알림 발송 실패:', error);
        }
    }

    /**
     * 사용자의 소리 알림 목록을 조회합니다.
     * @param {number} userId - 사용자 ID
     * @param {Object} options - 조회 옵션
     */
    async getUserSoundAlerts(userId, options = {}) {
        try {
            const {
                page = 1,
                limit = 20,
                isRead = null,
                soundType = null,
                startDate = null,
                endDate = null
            } = options;

            const whereClause = { user_id: userId };

            if (isRead !== null) {
                whereClause.is_read = isRead;
            }

            if (startDate && endDate) {
                whereClause.created_at = {
                    [Op.between]: [startDate, endDate]
                };
            }

            const includeClause = [{
                model: SoundEvent,
                as: 'soundEvent',
                where: soundType ? { sound_type: soundType } : {},
                required: true
            }];

            const alerts = await SoundAlert.findAndCountAll({
                where: whereClause,
                include: includeClause,
                order: [['created_at', 'DESC']],
                limit: parseInt(limit),
                offset: (parseInt(page) - 1) * parseInt(limit)
            });

            return {
                success: true,
                alerts: alerts.rows,
                total: alerts.count,
                page: parseInt(page),
                totalPages: Math.ceil(alerts.count / parseInt(limit))
            };

        } catch (error) {
            console.error('소리 알림 조회 중 오류:', error);
            throw error;
        }
    }

    /**
     * 알림을 읽음 상태로 표시합니다.
     * @param {number} alertId - 알림 ID
     * @param {number} userId - 사용자 ID
     */
    async markAlertAsRead(alertId, userId) {
        try {
            const alert = await SoundAlert.findOne({
                where: { id: alertId, user_id: userId }
            });

            if (!alert) {
                throw new Error('알림을 찾을 수 없습니다.');
            }

            await alert.update({
                is_read: true,
                read_at: new Date()
            });

            return {
                success: true,
                alert,
                message: '알림이 읽음 상태로 표시되었습니다.'
            };

        } catch (error) {
            console.error('알림 읽음 처리 중 오류:', error);
            throw error;
        }
    }

    /**
     * 소리 이벤트 통계를 조회합니다.
     * @param {number} userId - 사용자 ID
     * @param {Object} options - 조회 옵션
     */
    async getSoundEventStats(userId, options = {}) {
        try {
            const { startDate, endDate } = options;

            const whereClause = { user_id: userId };
            if (startDate && endDate) {
                whereClause.detected_at = {
                    [Op.between]: [startDate, endDate]
                };
            }

            // 소리 타입별 통계
            const eventsByType = await SoundEvent.findAll({
                where: whereClause,
                attributes: [
                    'sound_type',
                    [sequelize.fn('COUNT', sequelize.col('id')), 'count']
                ],
                group: ['sound_type']
            });

            // 로봇별 통계
            const eventsByRobot = await SoundEvent.findAll({
                where: whereClause,
                attributes: [
                    'robot_id',
                    [sequelize.fn('COUNT', sequelize.col('id')), 'count']
                ],
                group: ['robot_id']
            });

            // 전체 통계
            const totalEvents = await SoundEvent.count({ where: whereClause });
            const averageConfidence = await SoundEvent.findOne({
                where: whereClause,
                attributes: [
                    [sequelize.fn('AVG', sequelize.col('confidence')), 'avg_confidence']
                ]
            });

            return {
                success: true,
                stats: {
                    totalEvents,
                    eventsByType: eventsByType.reduce((acc, item) => {
                        acc[item.sound_type] = parseInt(item.dataValues.count);
                        return acc;
                    }, {}),
                    eventsByRobot: eventsByRobot.reduce((acc, item) => {
                        acc[item.robot_id] = parseInt(item.dataValues.count);
                        return acc;
                    }, {}),
                    averageConfidence: parseFloat(averageConfidence?.dataValues.avg_confidence || 0)
                }
            };

        } catch (error) {
            console.error('소리 이벤트 통계 조회 중 오류:', error);
            throw error;
        }
    }
}

module.exports = new SoundDetectionService();
