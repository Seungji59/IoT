// services/NotificationService.js
// 이 서비스는 웹소켓을 통해 클라이언트에게 실시간 알림을 전송하는 역할을 합니다.

const WebSocket = require('ws');

class NotificationService {
    constructor() {
        this.connectedClients = new Map(); // Map<userId, Set<WebSocket>>
    }

    addClient(userId, socket) {
        if (!this.connectedClients.has(userId)) {
            this.connectedClients.set(userId, new Set());
        }
        this.connectedClients.get(userId).add(socket);
        socket.on('close', () => this.removeClient(userId, socket));
        socket.on('error', () => this.removeClient(userId, socket));
    }

    removeClient(userId, socket) {
        if (this.connectedClients.has(userId)) {
            const set = this.connectedClients.get(userId);
            set.delete(socket);
            if (set.size === 0) {
                this.connectedClients.delete(userId);
            }
        }
    }

    isUserConnected(userId) {
        return this.connectedClients.has(userId) && this.connectedClients.get(userId).size > 0;
    }

    getConnectedClientsCount() {
        let total = 0;
        this.connectedClients.forEach(set => (total += set.size));
        return total;
    }

    sendToWebSocket(userId, payload) {
        if (!this.connectedClients.has(userId)) return;
        const set = this.connectedClients.get(userId);
        set.forEach((socket) => {
            try {
                if (socket.readyState === WebSocket.OPEN) {
                    socket.send(JSON.stringify(payload));
                }
            } catch (_) {
                this.removeClient(userId, socket);
            }
        });
    }

    async sendRealTimeNotification(userId, notification) {
        this.sendToWebSocket(userId, notification);
        return true;
    }

         sendEventAlert(userId, { type, title, message, data = {}, severity = 'high' }) {
        const payload = { type, title, message, severity, data, ts: new Date().toISOString() };
        return this.sendRealTimeNotification(userId, payload);
    }
    
    // ---- Event helper methods (kept for compatibility) ----
    sendCaptureCompletedAlert(userId, captureData) {
        const notification = {
            type: 'capture_completed',
            title: '캡처 완료',
            message: '사진이 성공적으로 촬영되었습니다.',
            data: captureData
        };
        return this.sendRealTimeNotification(userId, notification);
    }

    sendRecordingStatus(userId, recordingData) {
        const notification = {
            type: 'recording_status',
            title: '녹화 상태',
            message: `녹화가 ${recordingData.status === 'recording' ? '시작' : '중지'}되었습니다.`,
            data: recordingData
        };
        return this.sendRealTimeNotification(userId, notification);
    }

    sendPtzStatus(userId, ptzData) {
        const notification = {
            type: 'ptz_status',
            title: 'PTZ 상태',
            message: '로봇의 PTZ(팬-틸트-줌) 상태가 업데이트되었습니다.',
            data: ptzData
        };
        return this.sendRealTimeNotification(userId, notification);
    }

    sendObstacleAlert(userId, obstacleData) {
        const notification = {
            type: 'obstacle_detected',
            title: '장애물 감지',
            message: `로봇이 ${obstacleData.distance}cm 거리에서 장애물을 감지하여 정지했습니다.`,
            data: {
                robot_id: obstacleData.robot_id,
                distance: obstacleData.distance,
                timestamp: obstacleData.timestamp
            }
        };
        return this.sendRealTimeNotification(userId, notification);
    }

    sendCommandCompletedAlert(userId, commandData) {
        const notification = {
            type: 'command_completed',
            title: '명령 완료',
            message: `${commandData.command} 명령이 성공적으로 완료되었습니다.`,
            data: {
                robot_id: commandData.robot_id,
                command: commandData.command,
                timestamp: commandData.timestamp
            }
        };
        return this.sendRealTimeNotification(userId, notification);
    }
}

// singleton instance
const notificationService = new NotificationService();

module.exports = {
    NotificationService,
    notificationService
};
