// service/EventService.js
const Joi = require('joi');
const { notificationService } = require('./NotificationService');

let Models = {};
try {
  Models = require('../models');
} catch (_) {}

const baseSchema = {
  eventId: Joi.alternatives(Joi.string(), Joi.number()).required(),
  userId: Joi.string().required(),
  cameraId: Joi.string().required(),
  ts: Joi.date().iso().required(),
  severity: Joi.string().valid('high','medium','low').default('high'),
  confidence: Joi.number().min(0).max(1).default(1),
  media: Joi.object({
    imageUrl: Joi.string().uri().allow('', null),
    clipUrl: Joi.string().uri().allow('', null),
    audioUrl: Joi.string().uri().allow('', null),
    spectrogramUrl: Joi.string().uri().allow('', null),
  }).default({}),
  meta: Joi.object().unknown(true).default({})
};

const dangerSchema = Joi.object({
  ...baseSchema,
  kind: Joi.string().valid('danger').required(),
  type: Joi.string().required() // knife | fire | smoke ...
});

const soundSchema = Joi.object({
  ...baseSchema,
  kind: Joi.string().valid('sound').required(),
  sound_type: Joi.string().required(),
  decibel_level: Joi.number().allow(null)
});

async function saveIfModelExists(modelName, values, uniqueWhere) {
  if (!Models[modelName]) return null;
  const exists = await Models[modelName].findOne({ where: uniqueWhere });
  if (exists) return exists;
  return Models[modelName].create(values);
}

async function handleDangerEvent(input) {
  const { value, error } = dangerSchema.validate(input);
  if (error) throw error;

  // DB 저장
  await saveIfModelExists('Event', {
    eventId: String(value.eventId),
    userId: value.userId,
    cameraId: value.cameraId,
    kind: 'danger',
    type: value.type,
    severity: value.severity,
    confidence: value.confidence,
    occurredAt: value.ts,
    imageUrl: value.media?.imageUrl || null,
    clipUrl: value.media?.clipUrl || null,
    meta: value.meta
  }, { eventId: String(value.eventId) });

  // 웹소켓 실시간 알림
  await notificationService.sendRealTimeNotification(value.userId, {
    type: 'danger_detected',
    title: '⚠️ 위험물 감지',
    message: `카메라 ${value.cameraId}에서 ${value.type} 감지 (${Math.round(value.confidence*100)}%)`,
    severity: value.severity,
    data: {
      eventId: value.eventId,
      cameraId: value.cameraId,
      type: value.type,
      imageUrl: value.media?.imageUrl || '',
      clipUrl: value.media?.clipUrl || ''
    },
    ts: value.ts
  });

  return true;
}

async function handleSoundEvent(input) {
  const { value, error } = soundSchema.validate(input);
  if (error) throw error;

  // DB 저장
  await saveIfModelExists('SoundEvent', {
    eventId: String(value.eventId),
    userId: value.userId,
    cameraId: value.cameraId,
    soundType: value.sound_type,
    decibelLevel: value.decibel_level,
    confidence: value.confidence,
    timestamp: value.ts,
    audioFileUrl: value.media?.audioUrl || null,
    spectrogramUrl: value.media?.spectrogramUrl || null,
    location: value.meta?.location || null
  }, { eventId: String(value.eventId) });

  // 웹소켓 실시간 알림
  await notificationService.sendRealTimeNotification(value.userId, {
    type: 'sound_detected',
    title: '🔊 소리 감지',
    message: `카메라 ${value.cameraId}에서 ${value.sound_type} 감지`,
    severity: value.severity,
    data: {
      eventId: value.eventId,
      cameraId: value.cameraId,
      sound_type: value.sound_type,
      decibel_level: String(value.decibel_level ?? ''),
    },
    ts: value.ts
  });

  return true;
}


module.exports = { handleDangerEvent, handleSoundEvent };
