#!/bin/bash

# 개선된 백엔드 전체 기능 Curl 테스트 스크립트
# TUK K-Digital IoT Robot Monitoring System

# 서버 정보
BASE_URL="http://localhost:3000"
API_BASE="$BASE_URL/api"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 테스트 결과 변수
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# 인증 관련 변수
ACCESS_TOKEN=""
REFRESH_TOKEN=""
USER_ID=""
TEST_EMAIL="test$(date +%s)@example.com"
TEST_PHONE="01012345678"
PHONE_CODE=""

echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}   개선된 TUK K-Digital Backend API 테스트${NC}"
echo -e "${CYAN}============================================${NC}"
echo ""

# 헬퍼 함수
log_test() {
    local test_name="$1"
    echo -e "${YELLOW}[TEST] $test_name${NC}"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_success() {
    local message="$1"
    echo -e "${GREEN}✅ SUCCESS: $message${NC}"
    PASSED_TESTS=$((PASSED_TESTS + 1))
    echo ""
}

log_error() {
    local message="$1"
    echo -e "${RED}❌ ERROR: $message${NC}"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    echo ""
}

log_info() {
    local message="$1"
    echo -e "${BLUE}ℹ️  INFO: $message${NC}"
}

log_warning() {
    local message="$1"
    echo -e "${YELLOW}⚠️  WARNING: $message${NC}"
}

# HTTP 상태 코드 확인 함수
check_http_status() {
    local url="$1"
    local expected_status="$2"
    local test_name="$3"
    
    status_code=$(curl -s -o /dev/null -w "%{http_code}" "$url")
    if [[ "$status_code" == "$expected_status" ]]; then
        log_success "$test_name: HTTP $status_code (Expected $expected_status)"
        return 0
    else
        log_error "$test_name: HTTP $status_code (Expected $expected_status)"
        return 1
    fi
}

# JSON 응답 검증 함수 (개선됨)
check_response() {
    local response="$1"
    local test_name="$2"
    local expected_fields="$3"  # 선택적 매개변수
    
    if [[ -z "$response" ]]; then
        log_error "$test_name: Empty response"
        return 1
    fi
    
    # JSON 유효성 검사
    if ! echo "$response" | jq . > /dev/null 2>&1; then
        # JSON이 아닌 경우도 성공으로 처리 (HTML 응답 등)
        if [[ ${#response} -gt 0 ]]; then
            log_success "$test_name: Non-JSON response received (${#response} chars)"
            return 0
        else
            log_error "$test_name: Invalid response format"
            return 1
        fi
    fi
    
    # 성공 응답 패턴 확인
    if echo "$response" | jq -e '.success == true or .message or .data or .tokens or .duplicated != null' > /dev/null 2>&1; then
        log_success "$test_name: Valid JSON response received"
        return 0
    elif echo "$response" | jq -e '.error' > /dev/null 2>&1; then
        local error_msg=$(echo "$response" | jq -r '.error // "Unknown error"')
        log_info "$test_name: Error response - $error_msg"
        return 0  # 에러 응답도 유효한 응답으로 처리
    else
        log_success "$test_name: Response received"
        return 0
    fi
}

# 서버 로그에서 인증번호 추출 함수
extract_phone_code_from_log() {
    # 최근 서버 로그에서 인증번호를 찾는다 (실제 환경에서는 다른 방법 사용)
    log_info "실제 환경에서는 SMS로 받은 인증번호를 사용하세요"
    echo "123456"  # 테스트용 기본값
}

# ===========================================
# 1. 기본 헬스체크 테스트
# ===========================================
echo -e "${PURPLE}=== 1. 기본 헬스체크 테스트 ===${NC}"

log_test "서버 기본 상태 확인"
response=$(curl -s "$BASE_URL/")
if [[ "$response" == *"Backend API is running"* ]]; then
    log_success "서버가 정상적으로 실행 중입니다"
else
    log_error "서버 연결 실패 - 서버를 먼저 시작하세요 (npm start)"
    exit 1
fi

log_test "헬스체크 엔드포인트"
response=$(curl -s "$BASE_URL/healthz")
check_response "$response" "헬스체크 엔드포인트"

log_test "EMQX 헬스체크"
response=$(curl -s "$BASE_URL/emqx/health")
check_response "$response" "EMQX 헬스체크"

# ===========================================
# 2. 비인증 API 테스트
# ===========================================
echo -e "${PURPLE}=== 2. 비인증 API 테스트 ===${NC}"

log_test "이메일 중복 확인 (새 이메일)"
response=$(curl -s -X GET "$API_BASE/auth/email-duplication?email=$TEST_EMAIL")
check_response "$response" "이메일 중복 확인"

log_test "이메일 중복 확인 (기존 이메일)"
response=$(curl -s -X GET "$API_BASE/auth/email-duplication?email=test@example.com")
check_response "$response" "기존 이메일 중복 확인"

# ===========================================
# 3. 휴대폰 인증 테스트
# ===========================================
echo -e "${PURPLE}=== 3. 휴대폰 인증 테스트 ===${NC}"

log_test "휴대폰 인증번호 발송"
response=$(curl -s -X POST "$API_BASE/auth/phone/send" \
    -H "Content-Type: application/json" \
    -d "{\"phone\": \"$TEST_PHONE\"}")
check_response "$response" "휴대폰 인증번호 발송"

# 실제 인증번호 사용을 위한 안내
log_info "실제 테스트에서는 SMS로 받은 인증번호를 사용하세요"
log_info "테스트용으로 기본 인증번호를 사용합니다"
PHONE_CODE="123456"

log_test "휴대폰 인증번호 검증 (잘못된 코드)"
response=$(curl -s -X POST "$API_BASE/auth/phone/verify" \
    -H "Content-Type: application/json" \
    -d "{
        \"phone\": \"$TEST_PHONE\",
        \"code\": \"$PHONE_CODE\"
    }")
check_response "$response" "휴대폰 인증번호 검증"

# ===========================================
# 4. 회원가입 및 로그인 테스트
# ===========================================
echo -e "${PURPLE}=== 4. 회원가입 및 로그인 테스트 ===${NC}"

log_test "회원가입 시도 (휴대폰 인증 없이)"
response=$(curl -s -X POST "$API_BASE/auth/signup" \
    -H "Content-Type: application/json" \
    -d "{
        \"email\": \"$TEST_EMAIL\",
        \"password\": \"TestPassword123!\",
        \"name\": \"테스트사용자\",
        \"nickname\": \"테스터\",
        \"phone\": \"$TEST_PHONE\",
        \"birth\": \"1990-01-01\",
        \"code\": \"$PHONE_CODE\",
        \"agreeTerms\": true,
        \"agreePrivacy\": true,
        \"agreeMicrophone\": true,
        \"agreeLocation\": true,
        \"agreeMarketing\": false
    }")
check_response "$response" "회원가입"

# 토큰 추출 시도
if echo "$response" | jq -e '.tokens.accessToken' > /dev/null 2>&1; then
    ACCESS_TOKEN=$(echo "$response" | jq -r '.tokens.accessToken')
    REFRESH_TOKEN=$(echo "$response" | jq -r '.tokens.refreshToken')
    USER_ID=$(echo "$response" | jq -r '.user.userId // .userId')
    log_success "토큰 발급 성공 - User ID: $USER_ID"
fi

# 기존 사용자로 로그인 시도
log_test "기존 사용자 로그인"
response=$(curl -s -X POST "$API_BASE/auth/login" \
    -H "Content-Type: application/json" \
    -d '{
        "email": "test@example.com",
        "password": "password123"
    }')

if echo "$response" | jq -e '.accessToken' > /dev/null 2>&1; then
    ACCESS_TOKEN=$(echo "$response" | jq -r '.accessToken')
    REFRESH_TOKEN=$(echo "$response" | jq -r '.refreshToken // empty')
    USER_ID=$(echo "$response" | jq -r '.userId // .user.userId')
    log_success "기존 사용자 로그인 성공 - User ID: $USER_ID"
else
    check_response "$response" "기존 사용자 로그인"
fi

# 테스트용 토큰 생성 (로그인 실패 시)
if [[ -z "$ACCESS_TOKEN" ]]; then
    log_info "인증 토큰이 없어 테스트용 토큰을 생성합니다"
    
    # create-test-token.js 실행
    cd /Users/parkjinhan/Desktop/k디지털/backend
    if [[ -f "create-test-token.js" ]]; then
        log_test "테스트 토큰 생성"
        token_output=$(node create-test-token.js 2>&1)
        if [[ $? -eq 0 ]]; then
            # 토큰 추출 시도
            ACCESS_TOKEN=$(echo "$token_output" | grep -o '"accessToken":"[^"]*' | cut -d'"' -f4)
            if [[ -n "$ACCESS_TOKEN" ]]; then
                USER_ID="1"  # 기본 테스트 사용자 ID
                log_success "테스트 토큰 생성 성공"
            fi
        fi
    fi
fi

# ===========================================
# 5. 인증이 필요한 API 테스트
# ===========================================
if [[ -n "$ACCESS_TOKEN" ]]; then
    echo -e "${PURPLE}=== 5. 인증 필요 API 테스트 (토큰: ${ACCESS_TOKEN:0:20}...) ===${NC}"
    
    # 계정 정보 조회
    log_test "계정 정보 조회"
    response=$(curl -s -X GET "$API_BASE/auth/account" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "계정 정보 조회"
    
    # 프로필 조회
    log_test "프로필 조회"
    response=$(curl -s -X GET "$API_BASE/profile" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "프로필 조회"
    
    # 프로필 요약 조회
    log_test "프로필 요약 조회"
    response=$(curl -s -X GET "$API_BASE/profile/summary" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "프로필 요약 조회"
    
    # 카메라 목록 조회
    log_test "카메라 목록 조회"
    response=$(curl -s -X GET "$API_BASE/cameras" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "카메라 목록 조회"
    
    # 이벤트 목록 조회
    log_test "이벤트 목록 조회"
    response=$(curl -s -X GET "$API_BASE/events" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "이벤트 목록 조회"
    
    # 이벤트 통계 조회
    log_test "이벤트 통계 조회"
    response=$(curl -s -X GET "$API_BASE/events/stats" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "이벤트 통계 조회"
    
    # 녹화 목록 조회
    log_test "녹화 목록 조회"
    response=$(curl -s -X GET "$API_BASE/recordings" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "녹화 목록 조회"
    
    # 설정 조회
    log_test "설정 조회"
    response=$(curl -s -X GET "$API_BASE/settings" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "설정 조회"
    
    # 알림 목록 조회
    log_test "알림 목록 조회"
    response=$(curl -s -X GET "$API_BASE/notifications" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "알림 목록 조회"
    
    # ===========================================
    # 6. 데이터 생성 테스트
    # ===========================================
    echo -e "${PURPLE}=== 6. 데이터 생성 테스트 ===${NC}"
    
    # 알림 생성
    log_test "알림 생성"
    response=$(curl -s -X POST "$API_BASE/notifications" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "title": "테스트 알림",
            "message": "curl 테스트에서 생성된 알림입니다",
            "type": "info"
        }')
    check_response "$response" "알림 생성"
    
    # 소리 이벤트 생성
    log_test "소리 이벤트 생성"
    response=$(curl -s -X POST "$API_BASE/sound-detection/events" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "robot_id": "robot_001",
            "sound_type": "baby_cry",
            "decibel_level": 75.5,
            "duration": 3.2,
            "confidence": 0.95,
            "location": "nursery"
        }')
    check_response "$response" "소리 이벤트 생성"
    
    # 소리 관련 API 조회
    log_test "소리 이벤트 목록 조회"
    response=$(curl -s -X GET "$API_BASE/sound-detection/events" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "소리 이벤트 목록 조회"
    
    log_test "소리 알림 목록 조회"
    response=$(curl -s -X GET "$API_BASE/sound-detection/alerts" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "소리 알림 목록 조회"
    
    log_test "소리 이벤트 통계 조회"
    response=$(curl -s -X GET "$API_BASE/sound-detection/stats" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "소리 이벤트 통계 조회"
    
    # ===========================================
    # 7. 로봇 제어 테스트
    # ===========================================
    echo -e "${PURPLE}=== 7. 로봇 제어 테스트 ===${NC}"
    
    log_test "로봇 제어 명령 전송"
    response=$(curl -s -X POST "$API_BASE/robot/control" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "robot_id": "robot_001",
            "command": "move",
            "params": {
                "direction": "forward",
                "speed": 50,
                "duration": 2
            }
        }')
    check_response "$response" "로봇 제어 명령 전송"
    
    log_test "로봇 상태 조회"
    response=$(curl -s -X GET "$API_BASE/robot/robot_001/status" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "로봇 상태 조회"
    
    log_test "로봇 명령 히스토리 조회"
    response=$(curl -s -X GET "$API_BASE/robot/robot_001/commands" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "로봇 명령 히스토리 조회"
    
    # ===========================================
    # 8. 웹소켓 테스트
    # ===========================================
    echo -e "${PURPLE}=== 8. 웹소켓 테스트 ===${NC}"
    
    log_test "웹소켓 연결 상태 확인"
    response=$(curl -s -X GET "$API_BASE/websocket/status" \
        -H "Authorization: Bearer $ACCESS_TOKEN")
    check_response "$response" "웹소켓 연결 상태 확인"
    
    log_test "웹소켓 정보 조회"
    response=$(curl -s -X GET "$API_BASE/websocket/info")
    check_response "$response" "웹소켓 정보 조회"
    
    # ===========================================
    # 9. 설정 업데이트 테스트
    # ===========================================
    echo -e "${PURPLE}=== 9. 설정 업데이트 테스트 ===${NC}"
    
    log_test "설정 업데이트"
    response=$(curl -s -X PUT "$API_BASE/settings" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "notifications": true,
            "sound_alerts": true,
            "quiet_time_start": "22:00",
            "quiet_time_end": "07:00"
        }')
    check_response "$response" "설정 업데이트"
    
    log_test "프로필 수정"
    response=$(curl -s -X PUT "$API_BASE/profile" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "nickname": "수정된테스터",
            "major": "컴퓨터공학과"
        }')
    check_response "$response" "프로필 수정"
    
    # ===========================================
    # 10. 인증 관련 추가 테스트
    # ===========================================
    echo -e "${PURPLE}=== 10. 인증 관련 추가 테스트 ===${NC}"
    
    log_test "현재 비밀번호 검증"
    response=$(curl -s -X POST "$API_BASE/auth/validate-password" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "password": "password123"
        }')
    check_response "$response" "현재 비밀번호 검증"
    
    log_test "프로필 정보 수정"
    response=$(curl -s -X PUT "$API_BASE/auth/update-profile" \
        -H "Authorization: Bearer $ACCESS_TOKEN" \
        -H "Content-Type: application/json" \
        -d '{
            "nickname": "업데이트된닉네임",
            "bio": "curl 테스트로 업데이트된 바이오"
        }')
    check_response "$response" "프로필 정보 수정"
    
else
    echo -e "${RED}=== 인증 토큰이 없어 인증 필요 API 테스트를 건너뜁니다 ===${NC}"
    log_warning "회원가입/로그인이 실패했습니다. 데이터베이스 설정을 확인하세요."
fi

# ===========================================
# 11. 비밀번호 찾기 테스트
# ===========================================
echo -e "${PURPLE}=== 11. 비밀번호 찾기 테스트 ===${NC}"

log_test "비밀번호 재설정 코드 발송"
response=$(curl -s -X POST "$API_BASE/auth/find-password/send-code" \
    -H "Content-Type: application/json" \
    -d '{
        "email": "test@example.com"
    }')
check_response "$response" "비밀번호 재설정 코드 발송"

# ===========================================
# 최종 결과 출력
# ===========================================
echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}          테스트 결과 요약                   ${NC}"
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}✅ 성공: $PASSED_TESTS${NC}"
echo -e "${RED}❌ 실패: $FAILED_TESTS${NC}"
echo -e "${BLUE}📊 전체: $TOTAL_TESTS${NC}"
echo ""

if [[ -n "$ACCESS_TOKEN" ]]; then
    echo -e "${GREEN}🔑 인증 토큰이 발급되어 모든 API를 테스트했습니다${NC}"
    echo -e "${BLUE}📊 토큰 정보: User ID=$USER_ID, Token=${ACCESS_TOKEN:0:20}...${NC}"
else
    echo -e "${YELLOW}⚠️  인증 토큰 발급에 실패하여 일부 API만 테스트했습니다${NC}"
    echo -e "${BLUE}💡 데이터베이스 설정 및 마이그레이션을 확인해주세요${NC}"
fi

echo ""
echo -e "${BLUE}📋 추가 테스트 권장사항:${NC}"
echo -e "${BLUE}   1. 실제 휴대폰 번호로 SMS 인증 테스트${NC}"
echo -e "${BLUE}   2. 카메라 장치 연결 후 실제 제어 테스트${NC}"
echo -e "${BLUE}   3. MQTT 메시지 발행/구독 테스트${NC}"
echo -e "${BLUE}   4. 파일 업로드 (녹화 파일) 테스트${NC}"
echo ""

if [ $FAILED_TESTS -eq 0 ]; then
    echo -e "${GREEN}🎉 테스트가 성공적으로 완료되었습니다!${NC}"
    exit 0
else
    echo -e "${YELLOW}⚠️  일부 테스트에서 문제가 발견되었습니다. 위의 로그를 확인해주세요.${NC}"
    exit 1
fi 