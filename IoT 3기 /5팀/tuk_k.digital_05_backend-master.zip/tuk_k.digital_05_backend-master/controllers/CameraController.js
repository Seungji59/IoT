// CameraController.js
const { Camera, Capture, Recording } = require('../models');
const { emqxClient } = require('../emqx-client');

//카메라 목록 조회
exports.getCameras = async (req, res) => {
    try {
        const cameras = await Camera.findAll({
            where: { user_id: req.user.userId },
            order: [['created_at', 'DESC']]
        });
        res.json({ cameras });
    } catch (error) {
        console.error('Error fetching cameras:', error);
        res.status(500).json({ error: 'Failed to fetch cameras' });
    }
};

//특정 카메라 조회
exports.getCameraById = async (req, res) => {
    try {
        const { id } = req.params;
        const camera = await Camera.findOne({
            where: { id, user_id: req.user.userId }
        });
        if (!camera) {
            return res.status(404).json({ error: 'Camera not found' });
        }
        res.json({ camera });
    } catch (error) {
        console.error('Error fetching camera:', error);
        res.status(500).json({ error: 'Failed to fetch camera' });
    }
};

//카메라 설정 업데이트
exports.updateCameraSettings = async (req, res) => {
    try {
        const { id } = req.params;
        const settings = req.body;
        const camera = await Camera.findOne({ where: { id, user_id: req.user.userId } });
        if (!camera) {
            return res.status(404).json({ error: 'Camera not found' });
        }
        await camera.update(settings);
        res.json({ message: 'Camera settings updated successfully', camera });
    } catch (error) {
        console.error('Error updating camera settings:', error);
        res.status(500).json({ error: 'Failed to update camera settings' });
    }
};

//라이브 스트림 정보 조회
exports.getLiveStream = async (req, res) => {
    try {
        const { id } = req.params;
        const camera = await Camera.findOne({ where: { id, user_id: req.user.userId } });
        if (!camera) {
            return res.status(404).json({ error: 'Camera not found' });
        }
        // 실제 스트림 URL 생성 로직
        const HLS_BASE = (process.env.HLS_BASE_URL || 'http://localhost:8000').replace(/\/$/, '');
        const APP_NAME = process.env.NMS_APP_NAME || 'live';
        const stream = {
            cameraId: id,
            url: `${HLS_BASE}/${APP_NAME}/${id}/index.m3u8`,
            protocol: 'hls',
            quality: 'high',
            isActive: camera.status === 'online',
            viewers: 1,
            bitrate: 2048,
            frameRate: 30,
            resolution: '1080p'
        };
        res.json({ stream });
    } catch (error) {
        console.error('Error fetching live stream:', error);
        res.status(500).json({ error: 'Failed to get live stream' });
    }
};

/**
 * 캡처 명령 전송
 */
exports.sendCaptureCommand = async (req, res) => {
    try {
        const { id } = req.params;
        const camera = await Camera.findOne({ where: { id, user_id: req.user.userId } });

        if (!camera) {
            return res.status(404).json({ error: 'Camera not found' });
        }

        // MQTT로 캡처 명령 전송
        const mqttMessage = {
            action: 'capture',
            user_id: camera.user_id,
            camera_id: Number(id),
            timestamp: new Date().toISOString()
        };

        const success = await emqxClient.publishAsync(`tibo/camera/${id}/capture/command`, mqttMessage);

        if (success) {
            res.json({
                message: 'Capture command sent successfully',
                camera_id: id,
                timestamp: mqttMessage.timestamp
            });
        } else {
            res.status(500).json({ error: 'Failed to send capture command' });
        }

    } catch (error) {
        console.error('Error sending capture command:', error);
        res.status(500).json({ error: 'Failed to send capture command' });
    }
};

/**
 * PTZ 명령 전송
 */
exports.sendPtzCommand = async (req, res) => {
    try {
        const { id } = req.params;
        const { command, value } = req.body;

        const camera = await Camera.findOne({ where: { id, user_id: req.user.userId } });

        if (!camera) {
            return res.status(404).json({ error: 'Camera not found' });
        }

        // MQTT로 PTZ 명령 전송
        const mqttMessage = {
            command,
            value,
            user_id: camera.user_id,
            camera_id: Number(id),
            timestamp: new Date().toISOString()
        };

        const success = await emqxClient.publishAsync(`tibo/camera/${id}/ptz/command`, mqttMessage);

        if (success) {
            res.json({
                message: 'PTZ command sent successfully',
                camera_id: id,
                command,
                value,
                timestamp: mqttMessage.timestamp
            });
        } else {
            res.status(500).json({ error: 'Failed to send PTZ command' });
        }

    } catch (error) {
        console.error('Error sending PTZ command:', error);
        res.status(500).json({ error: 'Failed to send PTZ command' });
    }
};

/**
 * 녹화 제어 명령 전송
 */
exports.sendRecordingCommand = async (req, res) => {
    try {
        const { id } = req.params;
        const { action } = req.body; // 'start' 또는 'stop'

        const camera = await Camera.findOne({ where: { id, user_id: req.user.userId } });

        if (!camera) {
            return res.status(404).json({ error: 'Camera not found' });
        }

        // MQTT로 녹화 명령 전송
        const mqttMessage = {
            action,
            user_id: camera.user_id,
            camera_id: Number(id),
            timestamp: new Date().toISOString()
        };

        const success = await emqxClient.publishAsync(`tibo/camera/${id}/recording/command`, mqttMessage);

        if (success) {
            res.json({
                message: `Recording ${action} command sent successfully`,
                camera_id: id,
                action,
                timestamp: mqttMessage.timestamp
            });
        } else {
            res.status(500).json({ error: 'Failed to send recording command' });
        }

    } catch (error) {
        console.error('Error sending recording command:', error);
        res.status(500).json({ error: 'Failed to send recording command' });
    }
};

/**
 * 캡처 결과 처리 (팀원들이 구현한 후)
 */
exports.handleCaptureResult = async (data) => {
    try {
        const { camera_id, file_path, file_size, timestamp } = data;

        console.log(`📸 캡처 완료: ${camera_id}, 파일: ${file_path}`);

        // camera_id -> user_id 매핑
        const cam = await Camera.findByPk(camera_id);
        const user_id = cam?.user_id || 1;

        // 데이터베이스에 캡처 결과 저장
        await Capture.create({
            user_id,
            camera_id,
            file_path,
            file_name: file_path?.split('/')?.pop() || 'capture.jpg',
            file_url: file_path,
            size_bytes: file_size || null,
            captured_at: new Date(timestamp),
        });

        // 실시간 알림 전송
        const { notificationService } = require('../service/NotificationService');
        await notificationService.sendRealTimeNotification(user_id, {
            type: 'capture_completed',
            title: '캡처 완료',
            message: `사진이 성공적으로 촬영되었습니다.`,
            data: { camera_id, file_path, file_size }
        });

    } catch (error) {
        console.error('Error handling capture result:', error);
    }
};

/**
 * 녹화 상태 처리 (팀원들이 구현한 후)
 */
exports.handleRecordingStatus = async (data) => {
    try {
        const { camera_id, status, file_path, duration, timestamp } = data;

        console.log(`📹 녹화 상태: ${camera_id}, 상태: ${status}`);

        const camera = await Camera.findByPk(camera_id);
        if (!camera) {
            console.error(`Error: Camera with ID ${camera_id} not found.`);
            return;
        }

        const user_id = camera.user_id;

        if (status === 'started') {
            await Recording.create({
                user_id,
                camera_id,
                status: 'recording',
                started_at: new Date(timestamp)
            });
        } else if (status === 'stopped' && file_path && duration) {
            const recording = await Recording.findOne({
                where: { camera_id, status: 'recording' },
                order: [['started_at', 'DESC']]
            });

            if (recording) {
                await recording.update({
                    status: 'completed',
                    file_url: file_path,
                    file_name: file_path?.split('/')?.pop() || 'index.m3u8',
                    duration,
                    ended_at: new Date(timestamp)
                });
            }
        }
        const { notificationService } = require('../service/NotificationService');
        await notificationService.sendRealTimeNotification(user_id, {
            type: 'recording_status',
            title: '녹화 상태',
            message: `녹화가 ${status === 'recording' ? '시작' : '중지'}되었습니다.`,
            data: { camera_id, status, file_path, duration }
        });

    } catch (error) {
        console.error('Error handling recording status:', error);
    }
};

/**
 * PTZ 상태 처리 (팀원들이 구현한 후)
 */
exports.handlePtzStatus = async (data) => {
    try {
        const { camera_id, position } = data;

        console.log(`🎮 PTZ 상태: ${camera_id}, 위치: ${JSON.stringify(position)}`);
        // DB 확장 시 저장 가능

    } catch (error) {
        console.error('Error handling PTZ status:', error);
    }
};
