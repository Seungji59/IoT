const { Command, RobotStatus, User } = require('../models');
const { emqxClient } = require('../emqx-client');
const { notificationService } = require('../service/NotificationService');

/**
 * 로봇 제어 명령 전송
 */
exports.sendCommand = async (req, res) => {
    try {
        const { robot_id, command, parameters } = req.body;
        const user_id = req.user.userId;

        // 명령 유효성 검사
        const validCommands = ['MOVE_FORWARD', 'MOVE_BACKWARD', 'TURN_LEFT', 'TURN_RIGHT', 'STOP', 'HOME'];
        if (!validCommands.includes(command)) {
            return res.status(400).json({ error: 'Invalid command' });
        }

        // 명령을 데이터베이스에 저장
        const commandRecord = await Command.create({
            user_id,
            robot_id,
            command,
            parameters: parameters || {},
            status: 'pending'
        });

        // MQTT로 라즈베리파이에 명령 전송
        const mqttMessage = {
            cmd_id: command,
            cmd: command,
            user_id,
            robot_id,
            ts: Date.now()
        };

        const success = await emqxClient.publishAsync(`robot/${robot_id}/control`, mqttMessage);
        if (success) {
            await commandRecord.update({ status: 'executing' });

            res.json({
                message: 'Command sent successfully',
                command_id: commandRecord.id,
                status: 'executing'
            });
        } else {
            await commandRecord.update({ status: 'failed' });
            res.status(500).json({ error: 'Failed to send command via MQTT' });
        }

    } catch (error) {
        console.error('Error sending robot command:', error);
        res.status(500).json({ error: 'Failed to send command' });
    }
};

/**
 * 로봇 상태 조회
 */
exports.getRobotStatus = async (req, res) => {
    try {
        const { robot_id } = req.params;
        const user_id = req.user.userId;

        // 최신 로봇 상태 조회
        const robotStatus = await RobotStatus.findOne({
            where: { robot_id },
            order: [['updated_at', 'DESC']]
        });

        if (!robotStatus) {
            return res.status(404).json({ error: 'Robot status not found' });
        }

        // 최근 명령들 조회
        const recentCommands = await Command.findAll({
            where: { robot_id, user_id },
            order: [['created_at', 'DESC']],
            limit: 10
        });

        res.json({
            robot_status: robotStatus,
            recent_commands: recentCommands
        });

    } catch (error) {
        console.error('Error fetching robot status:', error);
        res.status(500).json({ error: 'Failed to fetch robot status' });
    }
};

/**
 * 로봇 명령 히스토리 조회
 */
exports.getCommandHistory = async (req, res) => {
    try {
        const { robot_id } = req.params;
        const user_id = req.user.userId;
        const { page = 1, limit = 20 } = req.query;

        const offset = (page - 1) * limit;

        const commands = await Command.findAndCountAll({
            where: { robot_id, user_id },
            order: [['created_at', 'DESC']],
            limit: parseInt(limit),
            offset: parseInt(offset)
        });

        res.json({
            commands: commands.rows,
            total: commands.count,
            page: parseInt(page),
            total_pages: Math.ceil(commands.count / limit)
        });

    } catch (error) {
        console.error('Error fetching command history:', error);
        res.status(500).json({ error: 'Failed to fetch command history' });
    }
};

/**
 * 위험 감지 알림 처리 (MQTT에서 호출)
 */
exports.handleObstacleDetection = async (robot_id, obstacleData) => {
    try {
        // 마지막 명령의 사용자 찾기
        let user_id = 1;
        try {
            const lastCmd = await Command.findOne({ where: { robot_id }, order: [['created_at', 'DESC']] });
            if (lastCmd) user_id = lastCmd.user_id;
        } catch (_) { }

        // 로봇 상태 업데이트
        await RobotStatus.create({
            user_id,
            robot_id,
            status: 'stopped',
            obstacle_detected: true,
            obstacle_distance: obstacleData.distance,
            error_message: `Obstacle detected at ${obstacleData.distance}cm`,
            updated_at: new Date()
        });

        // 실시간 알림 전송
        await notificationService.sendObstacleAlert(user_id, obstacleData);

        console.log(`🚨 장애물 감지: 로봇 ${robot_id}, 거리: ${obstacleData.distance}cm`);

    } catch (error) {
        console.error('Error handling obstacle detection:', error);
    }
};

/**
 * 명령 실행 완료 처리 (MQTT에서 호출)
 */
exports.handleCommandCompleted = async (command_id, result) => {
    try {
        const command = await Command.findByPk(command_id);
        if (command) {
            await command.update({
                status: result.success ? 'completed' : 'failed',
                executed_at: new Date()
            });

            // 명령 완료 알림 전송
            if (result.success) {
                await notificationService.sendCommandCompletedAlert(command.user_id, {
                    robot_id: command.robot_id,
                    command: command.command,
                    timestamp: new Date().toISOString()
                });
            }
        }

        console.log(`✅ 명령 완료: ${command_id}, 결과: ${result.success ? '성공' : '실패'}`);

    } catch (error) {
        console.error('Error handling command completion:', error);
    }
}; 