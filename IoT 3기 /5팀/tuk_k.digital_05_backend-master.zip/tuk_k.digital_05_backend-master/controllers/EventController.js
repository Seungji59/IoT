// EventController.js
const { Event } = require('../models');
const { Op } = require('sequelize');

exports.getEvents = async (req, res) => {
    try {
        const { robotId, eventType, startDate, endDate, page = 1, limit = 20 } = req.query;
        const whereClause = { user_id: req.user.userId };
        
        if (robotId) whereClause.robot_id = robotId;
        if (eventType) whereClause.event_type = eventType;
        if (startDate && endDate) {
            whereClause.created_at = {
                [Op.between]: [new Date(startDate), new Date(endDate)]
            };
        }
        
        const offset = (page - 1) * limit;
        
        const events = await Event.findAndCountAll({
            where: whereClause,
            order: [['created_at', 'DESC']],
            limit: parseInt(limit),
            offset: offset
        });
        
        res.json({
            data: events.rows,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: events.count,
                totalPages: Math.ceil(events.count / limit)
            }
        });
    } catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
};

exports.getEventById = async (req, res) => {
    try {
        const { id } = req.params;
        const event = await Event.findOne({
            where: { 
                id: id,
                user_id: req.user.userId 
            }
        });
        
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        res.json({ data: event });
    } catch (error) {
        console.error('Error fetching event:', error);
        res.status(500).json({ error: 'Failed to fetch event' });
    }
};

exports.getEventStats = async (req, res) => {
    try {
        const { robotId, startDate, endDate } = req.query;
        const whereClause = { user_id: req.user.userId };
        
        if (robotId) whereClause.robot_id = robotId;
        if (startDate && endDate) {
            whereClause.created_at = {
                [Op.between]: [new Date(startDate), new Date(endDate)]
            };
        }
        
        const events = await Event.findAll({ where: whereClause });
        
        const stats = {
            total: events.length,
            byType: {},
            byRobot: {},
            recent: events.filter(e => {
                const eventDate = new Date(e.created_at);
                const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
                return eventDate > oneDayAgo;
            }).length
        };
        
        events.forEach(event => {
            stats.byType[event.event_type] = (stats.byType[event.event_type] || 0) + 1;
            stats.byRobot[event.robot_id] = (stats.byRobot[event.robot_id] || 0) + 1;
        });
        
        res.json({ stats });
    } catch (error) {
        console.error('Error fetching event stats:', error);
        res.status(500).json({ error: 'Failed to fetch event stats' });
    }
};
