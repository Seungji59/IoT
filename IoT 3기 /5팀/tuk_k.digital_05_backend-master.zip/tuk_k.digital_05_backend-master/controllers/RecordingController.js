// RecordingController.js
const multer = require('multer');
const path = require('path');
const Recording = require('../models/Recording');

// multer 미들웨어 설정
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/recordings/'),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const uploadMiddleware = multer({ storage }).single('recordingFile');

// [1] 파일 업로드 및 DB 저장
const uploadRecording = async(req, res) => {
    try {
      const { user_id, camera_id, duration } = req.body;
      if (!user_id || !camera_id) {
        console.log('[Upload Fail] user_id or camera_id missing');
        return res.status(400).json({ error: 'user_id, camera_id는 필수입니다.' });
      }
      if (!req.file) {
        console.log('[Upload Fail] recordingFile not attached');
        return res.status(400).json({ error: 'recordingFile이 첨부되지 않았습니다.' });
      }

      const file_url = req.file.path.replace(/\\/g, '/');
      const now = new Date();

      const recording = await Recording.create({
        user_id,
        camera_id,
        file_name: req.file.filename,
        file_url,
        started_at: now,
        ended_at: now,
        duration: duration || null,
      });

      // 업로드 성공 시 콘솔 출력
      console.log('[Upload Success]', {
        id: recording.id,
        user_id,
        camera_id,
        file_name: req.file.filename,
        file_url,            
        duration,
        });
        res.status(201).json({message: '녹화본 업로드 성공', recording});
    } catch (error) {
      console.error('[Upload Error]', error);
      res.status(500).json({ error: '녹화본 업로드 실패' });
    }
};  

// [2] 전체 리스트 조회
const getRecordings = async (req, res) => {
  try {
    const recordings = await Recording.findAll({
      order: [['created_at', 'DESC']]
    });
    console.log(`[Get Recordings] 총 ${recordings.length}건 조회됨`);
    res.json({ recordings });
  } catch (error) {
    console.error('[Get Recordings Error]', error);
    res.status(500).json({ error: '녹화본 조회 실패' });
  }
};

// [3] 개별 녹화본 조회
const getRecordingById = async (req, res) => {
  try {
    const { id } = req.params;
    const recording = await Recording.findOne({ where: { id } });
    if (!recording) {
      console.log(`[Get Recording Fail] id=${id} (존재하지 않음)`);
      return res.status(404).json({ error: '녹화본을 찾을 수 없습니다.' });
    }
    console.log('[Get Recording Success]', { id, file_name: recording.file_name });
    res.json({ recording });
  } catch (error) {
    console.error('[Get Recording Error]', error);
    res.status(500).json({ error: '녹화본 조회 실패' });
  }
};

const handleRecordingStatus = async (data) => {
  try {
    const { camera_id, status, file_path, duration } = data;

    if (status === 'stopped') {
      // 녹화 중지되었을 때, 새 레코드 생성 후 파일 정보를 저장
      const recording = await Recording.create({
        user_id: 1, // TODO: 실제 사용자 ID로 변경
        camera_id,
        file_name: path.basename(file_path),
        file_url: file_path, // TODO: S3 URL 등으로 변경
        duration,
      });
      console.log(`✅ 녹화 완료: 카메라 ${camera_id}, 녹화본 ID ${recording.id}`);
    } else if (status === 'recording') {
      // 녹화가 시작되었을 때의 로직 (필요시 추가)
      console.log(`📹 녹화 시작: 카메라 ${camera_id}`);
    }

  } catch (error) {
    console.error('녹화 상태 처리 중 오류 발생:', error);
  }
};

module.exports = {
    uploadMiddleware,
    uploadRecording,
    getRecordings,
    getRecordingById,
    handleRecordingStatus,

  };

//console.log('[DEBUG-controller] about to export getRecordings =', typeof getRecordings);
