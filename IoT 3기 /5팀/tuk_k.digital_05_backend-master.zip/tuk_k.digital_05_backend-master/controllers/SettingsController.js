// SettingsController.js
const { Settings } = require('../models');
const { Op } = require('sequelize');

exports.getSettings = async (req, res) => {
    try {
        const settings = await Settings.findAll({
            where: { user_id: req.user.userId }
        });
        res.json({ settings });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch settings' });
    }
};

exports.updateSettings = async (req, res) => {
    try {
        const { key, value } = req.body;
        let setting = await Settings.findOne({
            where: { user_id: req.user.userId, key }
        });
        if (setting) {
            await setting.update({ value });
        } else {
            setting = await Settings.create({
                user_id: req.user.userId,
                key,
                value
            });
        }
        res.json({ setting });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update setting' });
    }
};

// 앱락 설정 초기화
exports.resetAppLockSettings = async (req, res) => {
    try {
        const userId = req.user.userId;

        // 앱락 관련 설정들을 모두 삭제
        await Settings.destroy({
            where: {
                user_id: userId,
                key: {
                    [Op.in]: [
                        'appLockEnabled',
                        'biometricEnabled',
                        'pinEnabled',
                        'currentPin',
                        'pinSetupCompleted',
                        'isPinRegistered'
                    ]
                }
            }
        });

        console.log(`✅ [SETTINGS] 사용자 ${userId} 앱락 설정 초기화 완료`);

        res.json({
            success: true,
            message: '앱락 설정이 초기화되었습니다.'
        });
    } catch (error) {
        console.error('❌ [SETTINGS] 앱락 설정 초기화 실패:', error);
        res.status(500).json({ error: '앱락 설정 초기화에 실패했습니다.' });
    }
};
