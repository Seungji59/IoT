// NotificationController.js
const { Notification } = require('../models');

exports.getNotifications = async (req, res) => {
    try {
        const { page = 1, limit = 20, is_read } = req.query;
        const where = { user_id: req.user.userId };
        if (typeof is_read !== 'undefined') where.is_read = is_read === 'true';

        const result = await Notification.findAndCountAll({
            where,
            order: [['created_at', 'DESC']],
            limit: parseInt(limit),
            offset: (parseInt(page) - 1) * parseInt(limit)
        });
        res.json({
            notifications: result.rows,
            total: result.count,
            page: parseInt(page),
            totalPages: Math.ceil(result.count / parseInt(limit))
        });
    } catch (error) {
        console.error('알림 목록 조회 실패:', error);
        res.status(500).json({ error: 'Failed to fetch notifications' });
    }
};

exports.createNotification = async (req, res) => {
    try {
        const { type, message, sound_event_id, priority } = req.body;
        const payload = {
            user_id: req.user.userId,
            type,
            message,
            is_read: false,
            sound_event_id: sound_event_id || null,
            priority: priority || 'medium'
        };
        const created = await Notification.create(payload);
        res.status(201).json({ notification: created });
    } catch (error) {
        console.error('알림 생성 실패:', error);
        res.status(400).json({ error: error.message });
    }
};
