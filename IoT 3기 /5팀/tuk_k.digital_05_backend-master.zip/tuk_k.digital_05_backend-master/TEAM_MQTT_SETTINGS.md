# 🍓 팀원 MQTT 설정 가이드

## 📡 **백엔드 MQTT 브로커 정보**

### **브로커 설정**
- **호스트**: `192.168.0.8` (백엔드 서버 IP)
- **포트**: `1883`
- **사용자명**: `tibo`
- **비밀번호**: `1q2w3e4r`

---

## 🔧 **팀원 코드 수정 사항**

### **1. MQTT 브로커 연결 설정**

#### **기존 팀원 코드**:
```python
BROKER, PORT = "192.168.0.7", 1883
USERNAME = "tukorea"; PASSWORD = "tukorea"
```

#### **수정된 코드**:
```python
BROKER, PORT = "192.168.0.8", 1883
USERNAME = "tibo"; PASSWORD = "1q2w3e4r"
```

### **2. MQTT 클라이언트 설정**

```python
import paho.mqtt.client as mqtt

# MQTT 클라이언트 설정 (백엔드 브로커에 맞춤)
client = mqtt.Client()
client.username_pw_set("tibo", "1q2w3e4r")  # 백엔드 계정 정보
client.connect("192.168.0.8", 1883, 60)     # 백엔드 서버 IP
```

---

## 📤 **발행해야 할 토픽들**

### **1. Baby Tracking 데이터**
```python
# 토픽: tibo/camera/{camera_id}/baby-tracking
data = {
    "camera_id": 1,
    "track_id": baby_id,  # 팀원 코드의 baby_id
    "bbox": [x1, y1, x2-x1, y2-y1],  # 바운딩 박스 [x, y, width, height]
    "command": desired_cmd,  # LEFT, RIGHT, CENTER, BACKWARD, STOP
    "distance_mm": dist_mm,  # VL53L0X 거리 센서 값
    "baby_lost": not baby_seen,  # 아기를 놓쳤는지 여부
    "image_url": "http://192.168.0.8:8000/tracking/baby.jpg",
    "confidence": 0.95,
    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
}

client.publish("tibo/camera/1/baby-tracking", json.dumps(data))
```

### **2. 객체 감지 데이터**
```python
# 토픽: tibo/camera/{camera_id}/object-detection
for tr in tracks:
    data = {
        "camera_id": 1,
        "object_type": "person",
        "confidence": 0.95,
        "bbox": [x1, y1, x2-x1, y2-y1],  # [x, y, width, height]
        "track_id": tr['track_id'],
        "image_url": "http://192.168.0.8:8000/detection/person.jpg",
        "object_count": len(tracks),
        "location": "거실",
        "is_baby": tr['track_id'] == baby_id,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
    }
    
    client.publish("tibo/camera/1/object-detection", json.dumps(data))
```

---

## 📥 **구독해야 할 토픽**

### **로봇 제어 명령 수신**
```python
# 토픽: robot/control
def on_message(client, userdata, msg):
    command = msg.payload.decode()
    print(f"로봇 명령 수신: {command}")
    
    # 명령에 따른 로봇 제어 로직
    if command == "LEFT":
        # 왼쪽으로 이동
        pass
    elif command == "RIGHT":
        # 오른쪽으로 이동
        pass
    elif command == "STOP":
        # 정지
        pass

client.subscribe("robot/control")
client.on_message = on_message
```

---

## 🔄 **팀원 코드 수정 예시**

### **기존 코드에서 수정할 부분**:

```python
# ============ 설정 ============
BROKER, PORT = "192.168.0.8", 1883  # 백엔드 서버 IP로 변경
USERNAME = "tibo"; PASSWORD = "1q2w3e4r"  # 백엔드 계정으로 변경

# ============ MQTT ============
def on_connect(c,u,f,rc): print("[MQTT] Connected" if rc==0 else f"[MQTT] Failed rc={rc}")
def on_disconnect(c,u,rc): print(f"[MQTT] Disconnected rc={rc}")
def send_command(cmd): print(f"[CONTROL] {cmd}"); client.publish("robot/control", cmd)

client = mqtt.Client()
client.username_pw_set(USERNAME, PASSWORD)  # 백엔드 계정 사용
client.on_connect = on_connect; client.on_disconnect = on_disconnect
client.connect(BROKER, PORT, 60); client.loop_start()

# ============ Baby Tracking 데이터 발행 ============
def publish_baby_tracking():
    if baby_id is not None:
        data = {
            "camera_id": 1,
            "track_id": baby_id,
            "bbox": [x1, y1, x2-x1, y2-y1],
            "command": desired_cmd or "STOP",
            "distance_mm": dist_mm,
            "baby_lost": not baby_seen,
            "image_url": "http://192.168.0.8:8000/tracking/baby.jpg",
            "confidence": 0.95,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
        }
        client.publish("tibo/camera/1/baby-tracking", json.dumps(data))
```

---

## 🚨 **주의사항**

1. **IP 주소**: `192.168.0.8` (백엔드 서버)로 변경
2. **계정 정보**: `tibo` / `1q2w3e4r` 사용
3. **토픽 형식**: 백엔드에서 정의한 토픽 구조 준수
4. **데이터 형식**: JSON 형식으로 발행
5. **이미지 URL**: 백엔드 서버의 HTTP URL 사용

---

## ✅ **테스트 방법**

1. **연결 테스트**:
```python
client.publish("test/topic", "Hello Backend!")
```

2. **Baby Tracking 테스트**:
```python
# 간단한 테스트 데이터 발행
test_data = {
    "camera_id": 1,
    "track_id": 1,
    "bbox": [100, 100, 50, 100],
    "command": "CENTER",
    "distance_mm": 300,
    "baby_lost": False,
    "confidence": 0.95,
    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
}
client.publish("tibo/camera/1/baby-tracking", json.dumps(test_data))
```

3. **백엔드 로그 확인**: 백엔드에서 메시지 수신 확인 