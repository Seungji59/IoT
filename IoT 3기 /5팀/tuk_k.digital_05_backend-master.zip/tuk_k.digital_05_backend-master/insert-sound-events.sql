-- 새로운 SoundEvent 테이블 구조에 맞는 더미 데이터 삽입
USE kdt05__db;

-- 소리 이벤트 더미 데이터 (MQTT 문서와 일치)
INSERT INTO SoundEvent (camera_id, sound_type, decibel_level, duration, confidence, audio_file_url, spectrogram_url, location, is_processed, detected_at) VALUES
(1, 'glass_break', 85.5, 2.3, 0.92, 'http://192.168.0.8:8000/audio/glass_break_001.wav', 'http://192.168.0.8:8000/spectrogram/glass_break_001.png', '거실', false, NOW()),
(1, 'voice', 75.2, 5.1, 0.88, 'http://192.168.0.8:8000/audio/voice_001.wav', 'http://192.168.0.8:8000/spectrogram/voice_001.png', '거실', false, NOW()),
(2, 'alarm', 90.1, 1.8, 0.95, 'http://192.168.0.8:8000/audio/alarm_001.wav', 'http://192.168.0.8:8000/spectrogram/alarm_001.png', '침실', true, NOW()),
(1, 'door_bell', 65.3, 0.8, 0.78, 'http://192.168.0.8:8000/audio/door_bell_001.wav', 'http://192.168.0.8:8000/spectrogram/door_bell_001.png', '현관', false, NOW()),
(2, 'unknown', 70.0, 3.2, 0.45, 'http://192.168.0.8:8000/audio/unknown_001.wav', 'http://192.168.0.8:8000/spectrogram/unknown_001.png', '침실', false, NOW());

SELECT 'SoundEvent 더미 데이터 삽입 완료!' as result; 