const { Sequelize } = require('sequelize');
const config = require('./config');

const env = process.env.NODE_ENV || 'development';
const dbConfig = config[env];

const sequelize = new Sequelize(
    dbConfig.database,
    dbConfig.username,
    dbConfig.password,
    {
        host: dbConfig.host,
        dialect: dbConfig.dialect,
        logging: false,
        define: {
            freezeTableName: true,
            timestamps: false,
        },
    }
);

module.exports = sequelize;
console.log('[DB-CONNECT]', {
  host: dbConfig.host,
  username: dbConfig.username,
  database: dbConfig.database
});