#!/usr/bin/env python3
"""
MQTT 메시지 구독 테스트 스크립트
팀원이 로봇 제어 명령을 실시간으로 확인할 수 있습니다.
"""

import paho.mqtt.client as mqtt
import json
import time
from datetime import datetime

# EMQX 브로커 설정
EMQX_HOST = "192.168.0.7"  # 또는 "localhost" (도커 환경)
EMQX_PORT = 1883
EMQX_USER = "tukorea"
EMQX_PASS = "tukorea"

# 구독할 토픽들
TOPICS = [
    "robot/+/control",      # 로봇 제어 명령
    "robot/+/status",       # 로봇 상태
    "robot/+/obstacle",     # 장애물 감지
    "homecam/status",       # 홈캠 상태
    "ai/danger",           # AI 위험 감지
    "ai/capture",          # AI 캡처
    "app/response"         # 앱 응답
]

def on_connect(client, userdata, flags, rc):
    """MQTT 연결 콜백"""
    if rc == 0:
        print(f"✅ MQTT 브로커 연결 성공: {EMQX_HOST}:{EMQX_PORT}")
        # 모든 토픽 구독
        for topic in TOPICS:
            client.subscribe(topic, qos=1)
            print(f"📡 구독 시작: {topic}")
    else:
        print(f"❌ MQTT 연결 실패: {rc}")

def on_message(client, userdata, msg):
    """메시지 수신 콜백"""
    try:
        timestamp = datetime.now().strftime("%H:%M:%S")
        topic = msg.topic
        payload = msg.payload.decode('utf-8')
        
        print(f"\n🕐 [{timestamp}] 📨 {topic}")
        print("=" * 50)
        
        # JSON 파싱 시도
        try:
            data = json.loads(payload)
            print(json.dumps(data, indent=2, ensure_ascii=False))
        except json.JSONDecodeError:
            print(f"📝 Raw payload: {payload}")
        
        print("=" * 50)
        
    except Exception as e:
        print(f"❌ 메시지 처리 오류: {e}")

def on_disconnect(client, userdata, rc):
    """연결 해제 콜백"""
    print(f"🔌 MQTT 연결 해제: {rc}")

def main():
    """메인 함수"""
    print("🤖 로봇 MQTT 메시지 모니터링 시작")
    print(f"📍 브로커: {EMQX_HOST}:{EMQX_PORT}")
    print(f"👤 사용자: {EMQX_USER}")
    print("=" * 60)
    
    # MQTT 클라이언트 생성
    client = mqtt.Client(client_id=f"test-subscriber-{int(time.time())}")
    client.username_pw_set(EMQX_USER, EMQX_PASS)
    
    # 콜백 설정
    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect
    
    try:
        # 연결 및 루프 시작
        client.connect(EMQX_HOST, EMQX_PORT, 60)
        client.loop_forever()
        
    except KeyboardInterrupt:
        print("\n🛑 모니터링 중단")
        client.disconnect()
    except Exception as e:
        print(f"❌ 연결 오류: {e}")

if __name__ == "__main__":
    main() 