// recordingRouter.js
const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');

const {
  uploadMiddleware,
  uploadRecording,
  getRecordings,
  getRecordingById
} = require('../controllers/RecordingController');

router.use(authMiddleware);

// 파일 업로드(POST): 미들웨어 + 실제 저장 함수
router.post('/upload', uploadMiddleware, uploadRecording);
// 전체 리스트 조회(GET): 핸들러 함수
router.get('/', getRecordings);
// 단일 녹화본 조회(GET): 핸들러 함수
router.get('/:id', getRecordingById);

module.exports = router;
