const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const SoundDetectionService = require('../service/SoundDetectionService');
const { SoundEvent, SoundAlert, User, sequelize } = require('../models');
const { Op } = require('sequelize');

/**
 * @route POST /api/sound-detection/events
 * @desc 소리 이벤트를 생성합니다.
 * @access Private
 */
router.post('/events', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.userId;
        const {
            robot_id,
            sound_type,
            decibel_level,
            duration,
            confidence,
            audio_file_url,
            spectrogram_url,
            location
        } = req.body;

        // 필수 필드 검증
        if (!robot_id || !sound_type) {
            return res.status(400).json({
                success: false,
                message: '로봇 ID와 소리 타입은 필수입니다.'
            });
        }

        const soundData = {
            user_id: userId,
            robot_id,
            sound_type,
            decibel_level,
            duration,
            confidence,
            audio_file_url,
            spectrogram_url,
            location
        };

        const result = await SoundDetectionService.createSoundEvent(soundData);

        res.status(201).json(result);

    } catch (error) {
        console.error('소리 이벤트 생성 중 오류:', error);
        res.status(500).json({
            success: false,
            message: '소리 이벤트 생성 중 오류가 발생했습니다.',
            error: error.message
        });
    }
});

/**
 * @route GET /api/sound-detection/alerts
 * @desc 사용자의 소리 알림 목록을 조회합니다.
 * @access Private
 */
router.get('/alerts', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.userId;
        const {
            page = 1,
            limit = 20,
            isRead,
            soundType,
            startDate,
            endDate
        } = req.query;

        const options = {
            page: parseInt(page),
            limit: parseInt(limit),
            isRead: isRead !== undefined ? isRead === 'true' : null,
            soundType: soundType || null,
            startDate: startDate ? new Date(startDate) : null,
            endDate: endDate ? new Date(endDate) : null
        };

        const result = await SoundDetectionService.getUserSoundAlerts(userId, options);

        res.json(result);

    } catch (error) {
        console.error('소리 알림 조회 중 오류:', error);
        res.status(500).json({
            success: false,
            message: '소리 알림 조회 중 오류가 발생했습니다.',
            error: error.message
        });
    }
});

/**
 * @route PATCH /api/sound-detection/alerts/:alertId/read
 * @desc 알림을 읽음 상태로 표시합니다.
 * @access Private
 */
router.patch('/alerts/:alertId/read', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.userId;
        const alertId = parseInt(req.params.alertId);

        if (!alertId) {
            return res.status(400).json({
                success: false,
                message: '알림 ID가 필요합니다.'
            });
        }

        const result = await SoundDetectionService.markAlertAsRead(alertId, userId);

        res.json(result);

    } catch (error) {
        console.error('알림 읽음 처리 중 오류:', error);
        res.status(500).json({
            success: false,
            message: '알림 읽음 처리 중 오류가 발생했습니다.',
            error: error.message
        });
    }
});

/**
 * @route GET /api/sound-detection/stats
 * @desc 소리 이벤트 통계를 조회합니다.
 * @access Private
 */
router.get('/stats', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { startDate, endDate } = req.query;

        const options = {
            startDate: startDate ? new Date(startDate) : null,
            endDate: endDate ? new Date(endDate) : null
        };

        const result = await SoundDetectionService.getSoundEventStats(userId, options);

        res.json(result);

    } catch (error) {
        console.error('소리 이벤트 통계 조회 중 오류:', error);
        res.status(500).json({
            success: false,
            message: '소리 이벤트 통계 조회 중 오류가 발생했습니다.',
            error: error.message
        });
    }
});

/**
 * @route GET /api/sound-detection/events
 * @desc 소리 이벤트 목록을 조회합니다.
 * @access Private
 */
router.get('/events', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.userId;
        const {
            page = 1,
            limit = 20,
            soundType,
            startDate,
            endDate,
            robotId
        } = req.query;

        const whereClause = { user_id: userId };

        if (soundType) {
            whereClause.sound_type = soundType;
        }

        if (robotId) {
            whereClause.robot_id = robotId;
        }

        if (startDate && endDate) {
            whereClause.detected_at = {
                [Op.between]: [new Date(startDate), new Date(endDate)]
            };
        }

        const events = await SoundEvent.findAndCountAll({
            where: whereClause,
            order: [['detected_at', 'DESC']],
            limit: parseInt(limit),
            offset: (parseInt(page) - 1) * parseInt(limit)
        });

        res.json({
            success: true,
            events: events.rows,
            total: events.count,
            page: parseInt(page),
            totalPages: Math.ceil(events.count / parseInt(limit))
        });

    } catch (error) {
        console.error('소리 이벤트 조회 중 오류:', error);
        res.status(500).json({
            success: false,
            message: '소리 이벤트 조회 중 오류가 발생했습니다.',
            error: error.message
        });
    }
});

module.exports = router;
