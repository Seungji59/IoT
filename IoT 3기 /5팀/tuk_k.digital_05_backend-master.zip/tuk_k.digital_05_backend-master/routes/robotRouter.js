const express = require('express');
const router = express.Router();
const RobotController = require('../controllers/RobotController');
const authMiddleware = require('../middlewares/authMiddleware');

// 인증 미들웨어 적용
router.use(authMiddleware);

// 로봇 제어 명령 전송
router.post('/control', RobotController.sendCommand);

// 로봇 상태 조회
router.get('/:robot_id/status', RobotController.getRobotStatus);

// 로봇 명령 히스토리 조회
router.get('/:robot_id/commands', RobotController.getCommandHistory);

module.exports = router; 