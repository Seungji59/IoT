const router = require('../controllers/Auth');
module.exports = router; 