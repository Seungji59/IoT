const express = require('express');
const router = express.Router();
const NotificationController = require('../controllers/NotificationController');
const authMiddleware = require('../middlewares/authMiddleware');

router.use(authMiddleware);

router.get('/', NotificationController.getNotifications);
router.post('/', NotificationController.createNotification);

module.exports = router;
