//cameraRouter.js
const express = require('express');
const router = express.Router();
const CameraController = require('../controllers/CameraController');
const authMiddleware = require('../middlewares/authMiddleware');
const {Camera} = require('../models');
const { startRelay, stopRelay, isRunning } = require('../media/ffmpegRelay');

// 모든 라우트에 인증 미들웨어 적용
router.use(authMiddleware);

// 카메라 조회/설정/스트림 정보
router.get('/', CameraController.getCameras);
router.get('/:id', CameraController.getCameraById);
router.patch('/:id/settings', CameraController.updateCameraSettings);
router.get('/:id/stream', CameraController.getLiveStream);

// 카메라 제어 명령 엔드포인트들
router.post('/:id/capture', CameraController.sendCaptureCommand);
router.post('/:id/ptz', CameraController.sendPtzCommand);
router.post('/:id/recording', CameraController.sendRecordingCommand);

// == RTSP->RTMP 릴레이 제어 ==
// 릴레이 시작: 서버가 RTSP를 당겨 RTMP로 푸시 → NMS가 HLS로 제공
router.post('/:id/relay/start', async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;

    // 카메라 소유권 검증 + RTSP URL 조회
    const cam = await Camera.findOne({ where: { id, user_id: userId } });
    if (!cam) return res.status(404).json({ error: 'Camera not found' });

    const rtspUrl = cam.rtsp_url || cam.rtsp_Url;
    if (!rtspUrl) return res.status(400).json({ error: 'RTSP URL not configured' });

    const {
      videoCodec = 'copy',     // 'copy' | 'h264'
      audioCodec = 'aac',      // 'aac' | 'copy' | 'none'
      gop = 60,
      audioBitrateK = 128,
      audioSampleRate = 48000,
    } = req.body || {};

    const result = startRelay({
      cameraId: id,
      rtspUrl,
      videoCodec,
      audioCodec,
      gop,
      audioBitrateK,
      audioSampleRate,
    });

    // 클라이언트 재생 URL도 같이 반환
    const HLS_BASE = process.env.HLS_BASE_URL || `http://localhost:8000`;
    return res.json({ ...result, hls: `${HLS_BASE}/live/${id}/index.m3u8` });
  } catch (error) {
    console.error('[relay/start] error:', error);
    return res.status(500).json({ error: 'failed to start relay' });
  }
});


// 릴레이 중지
router.post('/:id/relay/stop', async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;
    
    // 카메라 소유권 검증
    const cam = await Camera.findOne({ where: { id, user_id: userId } });
    if (!cam) return res.status(404).json({ error: 'Camera not found or not owned by user' });

    stopRelay(id);
    return res.json({ message: `Relay for camera ${id} stopped.` });
  } catch (error) {
    console.error('[relay/stop] error:', error);
    return res.status(500).json({ error: 'failed to stop relay' });
  }
});


// 릴레이 상태
router.get('/:id/relay/status', (req, res) => {
  try {
    return res.json({ running: isRunning(req.params.id) });
  } catch (error) {
    console.error('[relay/status] error:', error);
    return res.status(500).json({ error: 'failed to get status' });
  }
});

module.exports = router;
