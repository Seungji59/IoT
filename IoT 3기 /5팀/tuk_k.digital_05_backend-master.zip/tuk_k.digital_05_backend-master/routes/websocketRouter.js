const express = require('express');
const router = express.Router();
const { notificationService } = require('../service/NotificationService');
const authMiddleware = require('../middlewares/authMiddleware');

// WebSocket 연결 상태 확인
router.get('/status', authMiddleware, (req, res) => {
    const userId = req.user.userId;
    const isConnected = notificationService.isUserConnected(userId);
    const totalClients = notificationService.getConnectedClientsCount();

    res.json({
        user_connected: isConnected,
        total_connected_clients: totalClients,
        user_id: userId
    });
});

// WebSocket 연결 정보
router.get('/info', (req, res) => {
    res.json({
        websocket_url: `ws://${req.get('host')}/ws`,
        supported_events: [
            'notification',
            'robot_status',
            'obstacle_detected',
            'command_completed'
        ]
    });
});

module.exports = router; 