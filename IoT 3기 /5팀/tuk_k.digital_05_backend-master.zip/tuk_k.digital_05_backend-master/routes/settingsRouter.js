const express = require('express');
const router = express.Router();
const SettingsController = require('../controllers/SettingsController');
const authMiddleware = require('../middlewares/authMiddleware');

router.use(authMiddleware);

router.get('/', SettingsController.getSettings);
router.put('/', SettingsController.updateSettings);
router.delete('/app-lock', SettingsController.resetAppLockSettings);

module.exports = router;
