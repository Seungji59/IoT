# 🚀 팀원 개발 환경 설정 가이드

## 📋 **설정 순서**

### 1. 프로젝트 클론 및 의존성 설치
```bash
git clone [repository-url]
cd k디지털/backend
npm install
```

### 2. 환경 변수 파일 생성
```bash
# .env.example을 복사해서 .env 파일 생성
cp .env.example .env
```

### 3. .env 파일 수정
각 팀원의 환경에 맞게 다음 값들을 수정하세요:

```bash
# EMQX 브로커 설정 (중요!)
EMQX_HOST=localhost          # 또는 EMQX가 실행되는 서버 IP
EMQX_PORT=1883
EMQX_USERNAME=tibo
EMQX_PASSWORD=tibo123        # 실제 EMQX 비밀번호

# MySQL 설정
MYSQL_HOST=localhost
MYSQL_DATABASE=KDT05__db
MYSQL_USER=root
MYSQL_PASSWORD=your_password

# 기타 설정들...
```

### 4. EMQX 브로커 실행
```bash
# 방법 1: Homebrew로 설치된 EMQX 실행
emqx start

# 방법 2: Docker로 실행 (권장)
docker run -d --name emqx \
  -p 1883:1883 \
  -p 18083:18083 \
  emqx/emqx:latest

# 방법 3: 팀장의 EMQX 서버 사용
# EMQX_HOST를 팀장의 IP로 설정
```

### 5. 서버 실행
```bash
npm start
```

## �� **EMQX 설정 방법**

### Docker로 EMQX 실행 (권장)
```bash
# EMQX 컨테이너 실행
docker run -d --name emqx \
  -p 1883:1883 \
  -p 18083:18083 \
  emqx/emqx:latest

# 상태 확인
docker ps | grep emqx

# 웹 대시보드 접속
# http://localhost:18083
# 사용자명: admin, 비밀번호: public
```

### EMQX 사용자 생성
1. 웹 대시보드 접속: http://localhost:18083
2. Authentication → Password-Based → Add
3. 사용자 정보 입력:
   - Username: `tibo`
   - Password: `tibo123`
   - Is Superuser: 체크

## 🚨 **문제 해결**

### EMQX 연결 실패 시
1. **포트 확인**: `netstat -an | grep 1883`
2. **Docker 상태 확인**: `docker ps | grep emqx`
3. **로그 확인**: `docker logs emqx`

### 팀장의 EMQX 서버 사용 시
```bash
# .env 파일에서
EMQX_HOST=192.168.0.9  # 팀장의 실제 IP
EMQX_PORT=1883
EMQX_USERNAME=tibo
EMQX_PASSWORD=tibo123
```

## 📞 **지원**

문제가 발생하면 팀장에게 문의하세요!
