const { User, Camera, Event, Recording, Settings, Notification, SoundEvent, SoundAlert } = require('./models');

async function createDummyData() {
    try {
        console.log('🧪 더미 데이터 생성 시작...');

        // 1. 테스트 사용자 확인/생성
        let user = await User.findOne({ where: { email: 'test@example.com' } });
        if (!user) {
            user = await User.create({
                email: 'test@example.com',
                password_hash: 'dummy_hash',
                name: 'Test User',
                nickname: '테스터',
                phone: '010-1234-5678',
                phoneVerified: true,
                emailVerified: true,
                provider: 'local'
            });
            console.log('✅ 테스트 사용자 생성 완료');
        } else {
            console.log('✅ 기존 테스트 사용자 사용');
        }

        // 2. 카메라 더미 데이터
        const cameras = await Camera.bulkCreate([
            {
                user_id: user.id,
                name: '거실 카메라',
                ip_address: '192.168.1.100',
                port: 554,
                username: 'admin',
                password: 'password123',
                rtsp_url: 'rtsp://192.168.1.100:554/stream1',
                status: 'online'
            },
            {
                user_id: user.id,
                name: '침실 카메라',
                ip_address: '192.168.1.101',
                port: 554,
                username: 'admin',
                password: 'password123',
                rtsp_url: 'rtsp://192.168.1.101:554/stream1',
                status: 'online'
            }
        ]);
        console.log('✅ 카메라 더미 데이터 생성 완료');

        // 3. 이벤트 더미 데이터
        const events = await Event.bulkCreate([
            {
                camera_id: cameras[0].id,
                user_id: user.id,
                event_type: 'motion',
                confidence: 0.85,
                description: '거실에서 움직임 감지됨',
                image_url: 'https://example.com/motion1.jpg'
            },
            {
                camera_id: cameras[0].id,
                user_id: user.id,
                event_type: 'sound',
                confidence: 0.92,
                description: '거실에서 소리 감지됨',
                image_url: 'https://example.com/sound1.jpg'
            },
            {
                camera_id: cameras[1].id,
                user_id: user.id,
                event_type: 'object_detection',
                confidence: 0.78,
                description: '침실에서 물체 감지됨',
                image_url: 'https://example.com/object1.jpg'
            }
        ]);
        console.log('✅ 이벤트 더미 데이터 생성 완료');

        // 4. 녹화 더미 데이터
        const recordings = await Recording.bulkCreate([
            {
                user_id: user.id,
                camera_id: cameras[0].id,
                file_name: 'recording_001.mp4',
                file_path: '/recordings/recording_001.mp4',
                file_url: 'http://localhost:8000/recordings/recording_001.mp4',
                duration: 120,
                size_bytes: 1024000
            },
            {
                user_id: user.id,
                camera_id: cameras[1].id,
                file_name: 'recording_002.mp4',
                file_path: '/recordings/recording_002.mp4',
                file_url: 'http://localhost:8000/recordings/recording_002.mp4',
                duration: 180,
                size_bytes: 1536000
            }
        ]);
        console.log('✅ 녹화 더미 데이터 생성 완료');

        // 5. 설정 더미 데이터
        const settings = await Settings.create({
            user_id: user.id,
            notification_enabled: true,
            email_notification: true,
            sms_notification: false,
            push_notification: true,
            quiet_time_start: '22:00:00',
            quiet_time_end: '08:00:00'
        });
        console.log('✅ 설정 더미 데이터 생성 완료');

        // 6. 알림 더미 데이터
        const notifications = await Notification.bulkCreate([
            {
                user_id: user.id,
                title: '움직임 감지',
                message: '거실에서 움직임이 감지되었습니다.',
                type: 'motion',
                is_read: false
            },
            {
                user_id: user.id,
                title: '소리 감지',
                message: '침실에서 소리가 감지되었습니다.',
                type: 'sound',
                is_read: true
            }
        ]);
        console.log('✅ 알림 더미 데이터 생성 완료');

        // 7. 소리 이벤트 더미 데이터
        const soundEvents = await SoundEvent.bulkCreate([
            {
                camera_id: cameras[0].id,
                event_type: 'crying',
                confidence: 0.88,
                duration: 30,
                audio_url: 'https://example.com/audio1.wav'
            },
            {
                camera_id: cameras[1].id,
                event_type: 'laughing',
                confidence: 0.75,
                duration: 45,
                audio_url: 'https://example.com/audio2.wav'
            }
        ]);
        console.log('✅ 소리 이벤트 더미 데이터 생성 완료');

        // 8. 소리 알림 더미 데이터
        const soundAlerts = await SoundAlert.bulkCreate([
            {
                sound_event_id: soundEvents[0].id,
                user_id: user.id,
                alert_type: 'crying',
                severity: 'high',
                is_acknowledged: false
            },
            {
                sound_event_id: soundEvents[1].id,
                user_id: user.id,
                alert_type: 'unusual_sound',
                severity: 'medium',
                is_acknowledged: true
            }
        ]);
        console.log('✅ 소리 알림 더미 데이터 생성 완료');

        console.log('🎉 모든 더미 데이터 생성 완료!');
        console.log('');
        console.log('📊 생성된 데이터 요약:');
        console.log(`  👤 사용자: 1명`);
        console.log(`  📹 카메라: ${cameras.length}개`);
        console.log(`  📊 이벤트: ${events.length}개`);
        console.log(`  🎥 녹화: ${recordings.length}개`);
        console.log(`  ⚙️ 설정: 1개`);
        console.log(`  🔔 알림: ${notifications.length}개`);
        console.log(`  🔊 소리 이벤트: ${soundEvents.length}개`);
        console.log(`  🚨 소리 알림: ${soundAlerts.length}개`);

    } catch (error) {
        console.error('❌ 더미 데이터 생성 실패:', error);
    } finally {
        process.exit(0);
    }
}

createDummyData(); 