const { User } = require('./models');

async function createTestUser() {
    try {
        console.log('🧪 테스트용 사용자 생성 중...');

        // 기존 테스트 사용자 확인
        let testUser = await User.findOne({ where: { id: 1 } });

        if (!testUser) {
            // 테스트 사용자 생성
            testUser = await User.create({
                id: 1,
                email: 'test@example.com',
                password: 'test123',
                name: 'Test User',
                phone: '010-1234-5678',
                phoneVerified: true,
                emailVerified: true,
                created_at: new Date(),
                updated_at: new Date()
            });
            console.log('✅ 테스트 사용자 생성 완료:', testUser.id);
        } else {
            console.log('✅ 테스트 사용자 이미 존재:', testUser.id);
        }

        console.log('🎉 테스트 준비 완료!');

    } catch (error) {
        console.error('❌ 테스트 사용자 생성 실패:', error);
    } finally {
        process.exit(0);
    }
}

createTestUser(); 