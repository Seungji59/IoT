#!/bin/bash

# 인증 토큰을 사용한 완전한 API 테스트 스크립트
# TUK K-Digital IoT Robot Monitoring System

# 서버 정보
BASE_URL="http://localhost:3000"
API_BASE="$BASE_URL/api"

# 테스트 토큰 (실제 환경에서는 로그인으로 획득)
TEST_TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsImVtYWlsIjoidGVzdEBleGFtcGxlLmNvbSIsIm5hbWUiOiJUZXN0IFVzZXIiLCJpYXQiOjE3NTcxNDE3MDAsImV4cCI6MTc1NzIyODEwMH0.Fmq8OxRf0qK4vq3B9waNi_STCcWzF2b49ien6RPI38U"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 테스트 결과 변수
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}   🔑 인증 토큰 기반 API 완전 테스트       ${NC}"
echo -e "${CYAN}============================================${NC}"
echo -e "${BLUE}🔑 사용 토큰: ${TEST_TOKEN:0:30}...${NC}"
echo ""

# 헬퍼 함수
log_test() {
    local test_name="$1"
    echo -e "${YELLOW}[TEST] $test_name${NC}"
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
}

log_success() {
    local message="$1"
    echo -e "${GREEN}✅ SUCCESS: $message${NC}"
    PASSED_TESTS=$((PASSED_TESTS + 1))
    echo ""
}

log_error() {
    local message="$1"
    echo -e "${RED}❌ ERROR: $message${NC}"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    echo ""
}

log_info() {
    local message="$1"
    echo -e "${BLUE}ℹ️  INFO: $message${NC}"
}

# API 응답 체크 함수
check_api_response() {
    local response="$1"
    local test_name="$2"
    local status_code="$3"
    
    if [[ -z "$response" ]]; then
        log_error "$test_name: 응답 없음"
        return 1
    fi
    
    # HTTP 상태 코드 확인
    if [[ -n "$status_code" && "$status_code" -ge 400 ]]; then
        log_error "$test_name: HTTP $status_code"
        echo "Response: $response"
        return 1
    fi
    
    # JSON 응답 검증
    if echo "$response" | jq . > /dev/null 2>&1; then
        # JSON 형태인 경우
        if echo "$response" | jq -e '.error' > /dev/null 2>&1; then
            local error_msg=$(echo "$response" | jq -r '.error')
            log_info "$test_name: API Error - $error_msg"
            return 0
        else
            log_success "$test_name: Valid JSON response"
            return 0
        fi
    else
        # 텍스트 응답인 경우
        if [[ ${#response} -gt 0 ]]; then
            log_success "$test_name: Text response (${#response} chars)"
            return 0
        else
            log_error "$test_name: Empty response"
            return 1
        fi
    fi
}

# API 호출 함수
call_api() {
    local method="$1"
    local endpoint="$2"
    local data="$3"
    local test_name="$4"
    
    log_test "$test_name"
    
    if [[ "$method" == "GET" ]]; then
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" \
            -X GET "$API_BASE$endpoint" \
            -H "Authorization: Bearer $TEST_TOKEN" \
            -H "Content-Type: application/json")
    else
        response=$(curl -s -w "HTTPSTATUS:%{http_code}" \
            -X "$method" "$API_BASE$endpoint" \
            -H "Authorization: Bearer $TEST_TOKEN" \
            -H "Content-Type: application/json" \
            -d "$data")
    fi
    
    # HTTP 상태코드와 본문 분리
    http_code=$(echo "$response" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2)
    body=$(echo "$response" | sed 's/HTTPSTATUS:[0-9]*$//')
    
    check_api_response "$body" "$test_name" "$http_code"
}

# ===========================================
# 1. 기본 헬스체크 테스트
# ===========================================
echo -e "${PURPLE}=== 1. 기본 헬스체크 테스트 ===${NC}"

log_test "서버 상태 확인"
response=$(curl -s "$BASE_URL/")
if [[ "$response" == *"Backend API is running"* ]]; then
    log_success "서버가 정상적으로 실행 중입니다"
else
    log_error "서버 연결 실패"
    exit 1
fi

# ===========================================
# 2. 인증 관련 API 테스트
# ===========================================
echo -e "${PURPLE}=== 2. 인증 관련 API 테스트 ===${NC}"

call_api "GET" "/auth/account" "" "계정 정보 조회"

call_api "POST" "/auth/validate-password" '{
    "password": "password123"
}' "현재 비밀번호 검증"

call_api "PUT" "/auth/update-profile" '{
    "nickname": "API테스터",
    "bio": "curl 테스트로 수정된 프로필"
}' "프로필 정보 수정"

# ===========================================
# 3. 프로필 API 테스트
# ===========================================
echo -e "${PURPLE}=== 3. 프로필 API 테스트 ===${NC}"

call_api "GET" "/profile" "" "프로필 조회"

call_api "GET" "/profile/summary" "" "프로필 요약 조회"

call_api "PUT" "/profile" '{
    "nickname": "수정된닉네임",
    "major": "IoT공학과"
}' "프로필 수정"

# ===========================================
# 4. 카메라 API 테스트
# ===========================================
echo -e "${PURPLE}=== 4. 카메라 API 테스트 ===${NC}"

call_api "GET" "/cameras" "" "카메라 목록 조회"

# 첫 번째 카메라가 있다고 가정하고 테스트
CAMERA_ID="1"

call_api "GET" "/cameras/$CAMERA_ID" "" "특정 카메라 조회"

call_api "PATCH" "/cameras/$CAMERA_ID/settings" '{
    "resolution": "1920x1080",
    "fps": 30,
    "quality": "high"
}' "카메라 설정 업데이트"

call_api "POST" "/cameras/$CAMERA_ID/capture" '{}' "카메라 캡처 명령"

call_api "POST" "/cameras/$CAMERA_ID/ptz" '{
    "action": "move",
    "direction": "up",
    "speed": 50
}' "카메라 PTZ 제어"

call_api "GET" "/cameras/$CAMERA_ID/relay/status" "" "카메라 릴레이 상태"

call_api "POST" "/cameras/$CAMERA_ID/relay/start" '{
    "videoCodec": "h264",
    "audioCodec": "aac"
}' "카메라 릴레이 시작"

# ===========================================
# 5. 이벤트 API 테스트
# ===========================================
echo -e "${PURPLE}=== 5. 이벤트 API 테스트 ===${NC}"

call_api "GET" "/events" "" "이벤트 목록 조회"

call_api "GET" "/events/stats" "" "이벤트 통계 조회"

# 특정 이벤트 조회 (ID 1 가정)
call_api "GET" "/events/1" "" "특정 이벤트 조회"

# ===========================================
# 6. 녹화 API 테스트
# ===========================================
echo -e "${PURPLE}=== 6. 녹화 API 테스트 ===${NC}"

call_api "GET" "/recordings" "" "녹화 목록 조회"

# 특정 녹화 조회 (ID 1 가정)
call_api "GET" "/recordings/1" "" "특정 녹화 조회"

# ===========================================
# 7. 설정 API 테스트
# ===========================================
echo -e "${PURPLE}=== 7. 설정 API 테스트 ===${NC}"

call_api "GET" "/settings" "" "설정 조회"

call_api "PUT" "/settings" '{
    "notifications": true,
    "sound_alerts": true,
    "quiet_time_start": "22:00",
    "quiet_time_end": "07:00",
    "auto_recording": false,
    "motion_sensitivity": 75
}' "설정 업데이트"

call_api "DELETE" "/settings/app-lock" "" "앱 잠금 설정 초기화"

# ===========================================
# 8. 알림 API 테스트
# ===========================================
echo -e "${PURPLE}=== 8. 알림 API 테스트 ===${NC}"

call_api "GET" "/notifications" "" "알림 목록 조회"

call_api "POST" "/notifications" '{
    "title": "🔔 테스트 알림",
    "message": "curl API 테스트에서 생성된 알림입니다.",
    "type": "info",
    "priority": "normal"
}' "알림 생성"

# ===========================================
# 9. 소리 감지 API 테스트
# ===========================================
echo -e "${PURPLE}=== 9. 소리 감지 API 테스트 ===${NC}"

call_api "POST" "/sound-detection/events" '{
    "robot_id": "robot_001",
    "sound_type": "baby_cry",
    "decibel_level": 78.5,
    "duration": 4.2,
    "confidence": 0.94,
    "audio_file_url": "https://example.com/audio/test.wav",
    "spectrogram_url": "https://example.com/spectro/test.png",
    "location": "baby_room"
}' "소리 이벤트 생성"

call_api "GET" "/sound-detection/events" "" "소리 이벤트 목록 조회"

call_api "GET" "/sound-detection/events?page=1&limit=10&soundType=baby_cry" "" "소리 이벤트 필터 조회"

call_api "GET" "/sound-detection/alerts" "" "소리 알림 목록 조회"

call_api "GET" "/sound-detection/stats" "" "소리 이벤트 통계"

call_api "GET" "/sound-detection/stats?startDate=2025-01-01&endDate=2025-12-31" "" "기간별 소리 통계"

# 특정 알림을 읽음으로 표시 (ID 1 가정)
call_api "PATCH" "/sound-detection/alerts/1/read" "" "알림 읽음 처리"

# ===========================================
# 10. 로봇 제어 API 테스트
# ===========================================
echo -e "${PURPLE}=== 10. 로봇 제어 API 테스트 ===${NC}"

call_api "POST" "/robot/control" '{
    "robot_id": "robot_001",
    "command": "move",
    "params": {
        "direction": "forward",
        "speed": 60,
        "duration": 3
    }
}' "로봇 이동 명령"

call_api "POST" "/robot/control" '{
    "robot_id": "robot_001",
    "command": "rotate",
    "params": {
        "direction": "left",
        "angle": 90
    }
}' "로봇 회전 명령"

call_api "POST" "/robot/control" '{
    "robot_id": "robot_001",
    "command": "stop"
}' "로봇 정지 명령"

call_api "GET" "/robot/robot_001/status" "" "로봇 상태 조회"

call_api "GET" "/robot/robot_001/commands" "" "로봇 명령 히스토리"

call_api "GET" "/robot/robot_001/commands?page=1&limit=5" "" "로봇 명령 히스토리 (페이징)"

# ===========================================
# 11. 웹소켓 API 테스트
# ===========================================
echo -e "${PURPLE}=== 11. 웹소켓 API 테스트 ===${NC}"

call_api "GET" "/websocket/status" "" "웹소켓 연결 상태"

# 웹소켓 정보는 인증 없이도 조회 가능
log_test "웹소켓 정보 조회"
response=$(curl -s "$API_BASE/websocket/info")
check_api_response "$response" "웹소켓 정보 조회"

# ===========================================
# 12. 파일 업로드 테스트 (시뮬레이션)
# ===========================================
echo -e "${PURPLE}=== 12. 파일 업로드 테스트 ===${NC}"

# 임시 테스트 파일 생성
echo "테스트 녹화 파일 내용" > /tmp/test_recording.txt

log_test "녹화 파일 업로드 시뮬레이션"
response=$(curl -s -w "HTTPSTATUS:%{http_code}" \
    -X POST "$API_BASE/recordings/upload" \
    -H "Authorization: Bearer $TEST_TOKEN" \
    -F "file=@/tmp/test_recording.txt" \
    -F "camera_id=1" \
    -F "duration=60" \
    -F "recorded_at=2025-09-06T15:30:00Z")

http_code=$(echo "$response" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2)
body=$(echo "$response" | sed 's/HTTPSTATUS:[0-9]*$//')
check_api_response "$body" "녹화 파일 업로드" "$http_code"

# 임시 파일 정리
rm -f /tmp/test_recording.txt

# ===========================================
# 13. 페이지네이션 테스트
# ===========================================
echo -e "${PURPLE}=== 13. 페이지네이션 테스트 ===${NC}"

call_api "GET" "/events?page=1&limit=5" "" "이벤트 페이지네이션 (1페이지)"

call_api "GET" "/events?page=2&limit=5" "" "이벤트 페이지네이션 (2페이지)"

call_api "GET" "/recordings?page=1&limit=10" "" "녹화 페이지네이션"

call_api "GET" "/notifications?page=1&limit=20" "" "알림 페이지네이션"

# ===========================================
# 14. 날짜 필터 테스트
# ===========================================
echo -e "${PURPLE}=== 14. 날짜 필터 테스트 ===${NC}"

call_api "GET" "/events?startDate=2025-01-01&endDate=2025-12-31" "" "이벤트 날짜 필터"

call_api "GET" "/sound-detection/events?startDate=2025-09-01&endDate=2025-09-30" "" "소리 이벤트 월별 필터"

call_api "GET" "/sound-detection/alerts?startDate=2025-09-06&isRead=false" "" "읽지 않은 알림 필터"

# ===========================================
# 15. 에러 처리 테스트
# ===========================================
echo -e "${PURPLE}=== 15. 에러 처리 테스트 ===${NC}"

call_api "GET" "/cameras/99999" "" "존재하지 않는 카메라 조회"

call_api "GET" "/events/99999" "" "존재하지 않는 이벤트 조회"

call_api "POST" "/robot/control" '{
    "robot_id": "",
    "command": "invalid_command"
}' "잘못된 로봇 명령"

call_api "PATCH" "/cameras/1/settings" '{
    "invalid_field": "value"
}' "잘못된 설정 필드"

# ===========================================
# 최종 결과 출력
# ===========================================
echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}          🏁 최종 테스트 결과 요약          ${NC}"
echo -e "${CYAN}============================================${NC}"
echo -e "${GREEN}✅ 성공한 테스트: $PASSED_TESTS${NC}"
echo -e "${RED}❌ 실패한 테스트: $FAILED_TESTS${NC}"
echo -e "${BLUE}📊 전체 테스트: $TOTAL_TESTS${NC}"
echo ""

# 성공률 계산
if [ $TOTAL_TESTS -gt 0 ]; then
    success_rate=$(( (PASSED_TESTS * 100) / TOTAL_TESTS ))
    echo -e "${BLUE}📈 성공률: $success_rate%${NC}"
else
    echo -e "${YELLOW}⚠️  테스트가 실행되지 않았습니다${NC}"
fi

echo ""
echo -e "${CYAN}🎯 테스트 완료된 API 기능:${NC}"
echo -e "${BLUE}   ✓ 인증 및 계정 관리${NC}"
echo -e "${BLUE}   ✓ 프로필 정보 관리${NC}"
echo -e "${BLUE}   ✓ 카메라 제어 및 설정${NC}"
echo -e "${BLUE}   ✓ 이벤트 조회 및 통계${NC}"
echo -e "${BLUE}   ✓ 녹화 파일 관리${NC}"
echo -e "${BLUE}   ✓ 시스템 설정${NC}"
echo -e "${BLUE}   ✓ 알림 관리${NC}"
echo -e "${BLUE}   ✓ 소리 감지 및 분석${NC}"
echo -e "${BLUE}   ✓ 로봇 제어 및 모니터링${NC}"
echo -e "${BLUE}   ✓ 웹소켓 통신${NC}"
echo -e "${BLUE}   ✓ 파일 업로드${NC}"
echo -e "${BLUE}   ✓ 페이지네이션 및 필터링${NC}"
echo -e "${BLUE}   ✓ 에러 처리${NC}"

echo ""
if [ $FAILED_TESTS -eq 0 ]; then
    echo -e "${GREEN}🎉 모든 API 테스트가 성공적으로 완료되었습니다!${NC}"
    echo -e "${GREEN}🚀 백엔드 시스템이 정상적으로 작동하고 있습니다.${NC}"
    exit 0
else
    echo -e "${YELLOW}⚠️  일부 테스트에서 문제가 발견되었습니다.${NC}"
    echo -e "${BLUE}💡 실패한 테스트들을 확인하여 문제를 해결해주세요.${NC}"
    exit 1
fi 