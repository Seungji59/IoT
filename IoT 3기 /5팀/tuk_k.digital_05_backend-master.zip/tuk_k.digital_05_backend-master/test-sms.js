require('dotenv').config();
const smsService = require('./service/smsService');

async function testSMS() {
    console.log('🧪 SMS 발송 테스트 시작');
    console.log('==============================');

    // 환경변수 확인
    console.log('🔧 환경변수 확인:');
    console.log(`  ENABLE_SMS: ${process.env.ENABLE_SMS}`);
    console.log(`  TWILIO_ACCOUNT_SID: ${process.env.TWILIO_ACCOUNT_SID ? '설정됨' : '미설정'}`);
    console.log(`  TWILIO_AUTH_TOKEN: ${process.env.TWILIO_AUTH_TOKEN ? '설정됨' : '미설정'}`);
    console.log(`  TWILIO_PHONE_NUMBER: ${process.env.TWILIO_PHONE_NUMBER}`);
    console.log('==============================');

    const testPhone = '010-3283-9307';
    const testCode = '123456';

    console.log('📱 SMS 발송 테스트:');
    console.log(`  📞 수신번호: ${testPhone}`);
    console.log(`  🔢 인증번호: ${testCode}`);
    console.log('==============================');

    try {
        const result = await smsService.sendVerificationSMS(testPhone, testCode);

        if (result.success) {
            console.log('✅ SMS 발송 성공!');
            console.log(`  📋 메시지 ID: ${result.messageId}`);
        } else {
            console.log('❌ SMS 발송 실패');
            console.log(`  📝 에러: ${result.error}`);
        }
    } catch (error) {
        console.log('❌ SMS 발송 중 예외 발생');
        console.log(`  📝 에러: ${error.message}`);
        console.log(`  🔍 상세: ${error}`);
    }

    console.log('==============================');
    console.log('🧪 SMS 발송 테스트 완료');
}

testSMS(); 