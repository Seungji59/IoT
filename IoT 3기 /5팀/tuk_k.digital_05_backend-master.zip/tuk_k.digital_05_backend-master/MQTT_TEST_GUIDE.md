# 🤖 MQTT 메시지 테스트 가이드 (업데이트됨)

## 📋 개요
이 가이드는 팀원이 로봇 제어 MQTT 메시지를 실시간으로 확인할 수 있도록 도와줍니다.

## 🚀 빠른 시작

### 1. 의존성 설치
```bash
pip install paho-mqtt
```

### 2. 간단한 모니터링 (추천 - 하드웨어 불필요)
```bash
python simple-mqtt-monitor.py
```

### 3. 전체 시스템 테스트 (하드웨어 필요)
```bash
python homecam_edge_allinone_modified.py
```

## 🔄 메시지 흐름

### 백엔드 → 엣지 → 로봇
```
1. curl → Backend API → robot/tibo-001/control
2. 엣지가 수신 → robot/control로 변환 → 로봇
3. 로봇 → homecam/status (ACK) → 엣지 → 앱
```

### 엣지 → 로봇 (자동)
```
1. AI 탐지 → robot/control → 로봇
2. 로봇 → homecam/status (ACK) → 엣지 → 앱
```

## 📡 구독 토픽

| 토픽 | 설명 | 발신자 | 예시 |
|------|------|--------|------|
| `robot/+/control` | 백엔드 로봇 제어 | Backend API | `{"robot_id": "tibo-001", "command": "MOVE_FORWARD"}` |
| `robot/control` | 엣지 로봇 제어 | Edge AI | `{"cmd_id": "MOVE_FORWARD", "cmd": "MOVE_FORWARD", "ts": 1234567890}` |
| `homecam/status` | 로봇 ACK | Arduino UNO | `{"cmd_id": "MOVE_FORWARD", "ok": true, "reason": "success"}` |
| `app/response` | 앱 응답 | Edge | `{"cmd_id": "MOVE_FORWARD", "ok": true, "msg": "이동 성공"}` |
| `ai/danger` | AI 위험 감지 | Edge AI | `{"type": "knife", "conf": 0.95, "bbox": [100, 100, 50, 50]}` |
| `ai/capture` | AI 캡처 이미지 | Edge AI | `{"image_base64": "...", "labels": ["person"]}` |
| `homecam/telemetry` | 텔레메트리 | Edge/UNO | `{"battery": 75, "temp": 36.5, "fault": null}` |

## 🔧 설정 변경

### 브로커 주소 변경
- **로컬 테스트**: `EMQX_HOST = "localhost"`
- **네트워크**: `EMQX_HOST = "192.168.0.7"`

### 인증 정보
```python
EMQX_USER = "tukorea"
EMQX_PASS = "tukorea"
```

## 📝 메시지 형식 비교

### 백엔드 형식 (curl로 전송)
```json
{
  "robot_id": "tibo-001",
  "command": "MOVE_FORWARD"
}
```

### 엣지 형식 (AI 자동 생성)
```json
{
  "cmd_id": "MOVE_FORWARD",
  "cmd": "MOVE_FORWARD", 
  "ts": 1755067200000
}
```

### 로봇 ACK 형식
```json
{
  "cmd_id": "MOVE_FORWARD",
  "ok": true,
  "reason": "success",
  "battery": 75,
  "ts": 1755067200000
}
```

## 🧪 테스트 시나리오

### 1. 백엔드 명령 테스트
```bash
# 터미널 1: 모니터링 시작
python simple-mqtt-monitor.py

# 터미널 2: 백엔드 명령 전송
curl -X POST http://localhost:3000/api/robot/control \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer test-token" \
  -d '{"robot_id": "tibo-001", "command": "MOVE_FORWARD"}'
```

### 2. 예상 출력
```
🕐 [15:30:45.123] 📨 robot/tibo-001/control
============================================================
{
  "robot_id": "tibo-001",
  "command": "MOVE_FORWARD"
}
============================================================

🕐 [15:30:45.125] 📨 robot/control
============================================================
{
  "cmd_id": "MOVE_FORWARD",
  "cmd": "MOVE_FORWARD",
  "ts": 1755067200000
}
============================================================
```

## 🛠️ 문제 해결

### 연결 실패
1. 브로커 주소 확인 (`192.168.0.7` 또는 `localhost`)
2. 네트워크 연결 확인
3. 방화벽 설정 확인

### 메시지 수신 안됨
1. 토픽 구독 확인 (`robot/+/control`)
2. QoS 레벨 확인 (qos=1)
3. 브로커 로그 확인

### 하드웨어 오류
- `simple-mqtt-monitor.py` 사용 (하드웨어 불필요)
- 카메라/센서 없이도 MQTT 메시지 확인 가능

## 📞 지원
문제가 발생하면 팀 채널에 로그를 공유해주세요! 