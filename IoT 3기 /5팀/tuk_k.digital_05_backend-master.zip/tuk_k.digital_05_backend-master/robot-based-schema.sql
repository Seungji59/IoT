-- 로봇 기반 단일 카메라 구조로 데이터베이스 재설계
USE kdt05__db;

-- 외래키 체크 비활성화
SET FOREIGN_KEY_CHECKS = 0;

-- 기존 테이블들 삭제 (순서 중요)
DROP TABLE IF EXISTS SoundAlert;
DROP TABLE IF EXISTS SoundEvent;
DROP TABLE IF EXISTS Notification;
DROP TABLE IF EXISTS Event;
DROP TABLE IF EXISTS Recording;
DROP TABLE IF EXISTS Capture;
DROP TABLE IF EXISTS Command;
DROP TABLE IF EXISTS RobotStatus;
DROP TABLE IF EXISTS Settings;
DROP TABLE IF EXISTS TermsAgreement;
DROP TABLE IF EXISTS PhoneVerification;
DROP TABLE IF EXISTS RefreshToken;
DROP TABLE IF EXISTS Camera;
DROP TABLE IF EXISTS User;

-- 외래키 체크 다시 활성화
SET FOREIGN_KEY_CHECKS = 1;

-- 1. 사용자 테이블 (기본)
CREATE TABLE User (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    name VARCHAR(50) NOT NULL,
    nickname VARCHAR(50) COMMENT '사용자 닉네임',
    bio TEXT COMMENT '사용자 소개글',
    phone VARCHAR(20) UNIQUE,
    birth DATETIME COMMENT '생년월일 (YYYY-MM-DD)',
    phoneVerified TINYINT(1) NOT NULL DEFAULT false COMMENT '휴대폰 인증 완료 여부',
    emailVerified TINYINT(1) NOT NULL DEFAULT false,
    googleId VARCHAR(100) UNIQUE COMMENT 'Google 사용자 ID',
    picture TEXT COMMENT '프로필 사진 URL',
    provider VARCHAR(20) NOT NULL DEFAULT 'local' COMMENT '로그인 제공자 (local, google, kakao)',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. 로봇 테이블 (단일 로봇)
CREATE TABLE Robot (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL UNIQUE COMMENT '로봇 고유 ID (예: tibo-001)',
    name VARCHAR(100) NOT NULL DEFAULT 'TIBO 로봇',
    status ENUM('online', 'offline', 'error', 'maintenance') DEFAULT 'offline',
    battery_level INTEGER DEFAULT 0 COMMENT '배터리 레벨 (0-100)',
    wifi_strength INTEGER DEFAULT 0 COMMENT 'WiFi 신호 강도 (0-100)',
    last_seen DATETIME,
    danger_level ENUM('none', 'low', 'medium', 'high', 'critical') DEFAULT 'none',
    danger_description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- 3. 이벤트 테이블 (로봇 기반)
CREATE TABLE Event (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL,
    event_type ENUM('motion', 'sound', 'object_detection', 'baby_tracking') NOT NULL,
    confidence DECIMAL(5,2),
    description TEXT,
    image_url TEXT,
    location VARCHAR(100) COMMENT '이벤트 발생 위치',
    metadata JSON COMMENT '추가 메타데이터 (bbox, distance_mm 등)',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_event_type (event_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- 4. 소리 이벤트 테이블 (로봇 기반)
CREATE TABLE SoundEvent (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL,
    sound_type ENUM('glass_break', 'door_bell', 'alarm', 'voice', 'unknown') NOT NULL,
    decibel_level FLOAT COMMENT '소리 강도 (dB)',
    duration FLOAT COMMENT '소리 지속 시간 (초)',
    confidence FLOAT COMMENT 'AI 모델의 신뢰도 (0-1)',
    audio_file_url VARCHAR(255) COMMENT '녹음된 오디오 파일 URL',
    spectrogram_url VARCHAR(255) COMMENT '스펙트로그램 이미지 URL',
    location VARCHAR(100) COMMENT '소리 발생 위치',
    is_processed BOOLEAN DEFAULT false COMMENT '알림 처리 여부',
    detected_at DATETIME NOT NULL COMMENT '소리 감지 시간',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_sound_type (sound_type),
    INDEX idx_detected_at (detected_at),
    INDEX idx_is_processed (is_processed)
) ENGINE=InnoDB;

-- 5. 녹화 테이블 (로봇 기반)
CREATE TABLE Recording (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path TEXT NOT NULL,
    file_url TEXT NOT NULL,
    duration INTEGER DEFAULT 0 COMMENT '녹화 시간 (초)',
    size_bytes BIGINT,
    recording_type ENUM('manual', 'motion', 'sound', 'scheduled') DEFAULT 'manual',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_recording_type (recording_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- 6. 캡처 테이블 (로봇 기반)
CREATE TABLE Capture (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_url VARCHAR(1000) NOT NULL,
    size_bytes BIGINT UNSIGNED,
    capture_type ENUM('manual', 'motion', 'sound', 'scheduled') NOT NULL,
    captured_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_capture_type (capture_type),
    INDEX idx_captured_at (captured_at)
) ENGINE=InnoDB;

-- 7. 로봇 제어 명령 테이블
CREATE TABLE Command (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL,
    command_type ENUM('MOVE_FORWARD', 'MOVE_BACKWARD', 'TURN_LEFT', 'TURN_RIGHT', 'STOP', 'CAPTURE', 'RECORD_START', 'RECORD_STOP') NOT NULL,
    parameters JSON COMMENT '명령 파라미터 (speed, angle 등)',
    status ENUM('pending', 'executing', 'completed', 'failed') DEFAULT 'pending',
    executed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_command_type (command_type),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- 8. 알림 테이블 (통합)
CREATE TABLE Notification (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    robot_id VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('motion', 'sound', 'object_detection', 'baby_tracking', 'system', 'robot_status') NOT NULL,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    is_read TINYINT(1) DEFAULT false,
    metadata JSON COMMENT '추가 데이터 (이벤트 ID, 이미지 URL 등)',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_robot_id (robot_id),
    INDEX idx_type (type),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- 9. 설정 테이블
CREATE TABLE Settings (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER UNSIGNED NOT NULL,
    notification_enabled TINYINT(1) DEFAULT true,
    email_notification TINYINT(1) DEFAULT true,
    sms_notification TINYINT(1) DEFAULT false,
    push_notification TINYINT(1) DEFAULT true,
    quiet_time_start TIME DEFAULT '22:00:00',
    quiet_time_end TIME DEFAULT '08:00:00',
    robot_auto_follow TINYINT(1) DEFAULT true COMMENT '로봇 자동 추적 모드',
    motion_sensitivity INTEGER DEFAULT 50 COMMENT '모션 감지 민감도 (0-100)',
    sound_sensitivity INTEGER DEFAULT 50 COMMENT '소리 감지 민감도 (0-100)',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES User(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_settings (user_id)
) ENGINE=InnoDB;

-- 10. 인증 관련 테이블들
CREATE TABLE RefreshToken (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    userId INTEGER UNSIGNED NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_userId (userId),
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE PhoneVerification (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    userId INTEGER UNSIGNED NOT NULL,
    phone VARCHAR(20) NOT NULL,
    code VARCHAR(6) NOT NULL,
    isVerified TINYINT(1) DEFAULT false,
    verifiedAt DATETIME,
    expiresAt DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_userId (userId),
    INDEX idx_phone (phone)
) ENGINE=InnoDB;

CREATE TABLE TermsAgreement (
    id INTEGER UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    userId INTEGER UNSIGNED NOT NULL,
    termsVersion VARCHAR(10) NOT NULL,
    agreedAt DATETIME NOT NULL,
    ipAddress VARCHAR(45),
    userAgent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES User(id) ON DELETE CASCADE,
    INDEX idx_userId (userId)
) ENGINE=InnoDB;

SELECT '로봇 기반 단일 카메라 데이터베이스 구조 생성 완료!' as result; 