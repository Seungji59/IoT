const { sequelize } = require('./models');
const fs = require('fs');
const path = require('path');

async function runMigrations() {
    try {
        console.log('🔄 데이터베이스 마이그레이션을 시작합니다...');

        // 데이터베이스 연결
        await sequelize.authenticate();
        console.log('✅ 데이터베이스 연결 성공');

        // 기존 데이터 정리
        console.log('🧹 기존 데이터 정리 중...');
        await sequelize.query('SET FOREIGN_KEY_CHECKS = 0');

        // 기존 테이블 삭제 (순서 중요)
        const tablesToDrop = [
            'SoundAlert',
            'SoundEvent',
            'Notification',
            'Event',
            'Recording',
            'Camera',
            'Settings',
            'TermsAgreement',
            'PhoneVerification',
            'RefreshToken',
            'User',
            'Command',
            'RobotStatus'
        ];

        for (const table of tablesToDrop) {
            try {
                await sequelize.query(`DROP TABLE IF EXISTS ${table}`);
            } catch (error) {
                // 테이블이 없으면 무시
            }
        }

        await sequelize.query('SET FOREIGN_KEY_CHECKS = 1');
        console.log('✅ 기존 데이터 정리 완료');

        // 스키마 동기화
        await sequelize.sync({ force: true });
        console.log('✅ 데이터베이스 스키마 업데이트 완료');

        console.log('🎉 모든 마이그레이션이 성공적으로 완료되었습니다!');
        console.log('');
        console.log('📋 업데이트된 내용:');
        console.log('  - User 테이블: birth, phoneVerified 필드 추가');
        console.log('  - TermsAgreement 테이블: 약관 동의 내역 저장 테이블 생성');
        console.log('  - PhoneVerification 테이블: userId, isVerified, verifiedAt 필드 추가');
        console.log('  - Command 테이블: 로봇 제어 명령 저장 테이블 생성');
        console.log('  - RobotStatus 테이블: 로봇 상태 및 위험 감지 정보 저장 테이블 생성');
        console.log('  - 테이블 간 관계 설정 완료');

    } catch (error) {
        console.error('❌ 마이그레이션 실패:', error);
        process.exit(1);
    } finally {
        await sequelize.close();
        console.log('🔌 데이터베이스 연결 종료');
    }
}

runMigrations(); 