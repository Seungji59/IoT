// app.js

require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const http = require('http');
const WebSocket = require('ws');
const os = require('os');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const logger = require('./utils/logger');
const app = express();
const server = http.createServer(app);
const { emqxClient } = require('./emqx-client');  // EMQX MQTT 클라이언트 
const { syncDatabase } = require('./models'); // DB 동기화
require('./service/googleStrategy'); // 구글 OAuth 전략
const { nms, getMediaroot,listStreams,runNMS } = require('./media/mediaServer');
const { handleDangerEvent, handleSoundEvent } = require('./service/EventService'); // 

/* ---------------------------------------
 * CORS (동적 허용)
 * - 현재 머신의 로컬 IP 수집 + .env 확장
 * - Expo/localhost/내부망 패턴 허용
 * ------------------------------------- */
function getLocalIPs() {
  const nets = os.networkInterfaces();
  const ips = new Set(['localhost', '127.0.0.1']);
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if ((net.family === 'IPv4' || net.family === 4) && !net.internal) {
        ips.add(net.address);
      }
    }
  }
  if (process.env.CORS_EXTRA_HOSTS) {
    process.env.CORS_EXTRA_HOSTS.split(',')
      .map(s => s.trim()).filter(Boolean)
      .forEach(h => ips.add(h));
  }
  return Array.from(ips);
}

const FRONTEND_PORTS = (process.env.CORS_PORTS || '8081')
  .split(',').map(s => s.trim()).filter(Boolean);

const HOSTS = getLocalIPs();

const STATIC_ORIGINS = [];
for (const h of HOSTS) {
  for (const p of FRONTEND_PORTS) {
    STATIC_ORIGINS.push(`http://${h}:${p}`);
    STATIC_ORIGINS.push(`https://${h}:${p}`);
    STATIC_ORIGINS.push(`exp://${h}:${p}`); // Expo
  }
}

// 내부망/Expo/localhost 패턴 추가 허용
const REGEX_ORIGINS = [
  /^https?:\/\/localhost:\d+$/i,
  /^https?:\/\/127\.0\.0\.1:\d+$/i,
  /^https?:\/\/192\.168\.\d{1,3}\.\d{1,3}:\d+$/i,
  /^https?:\/\/10\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$/i,
  /^exp:\/\/(localhost|127\.0\.0\.1|192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}):\d+$/i,
];

const corsOptions = {
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  origin(origin, cb) {
    // origin 없는 요청(모바일 앱/서버-서버/포스트맨 등)은 허용
    if (!origin) return cb(null, true);

    const extraOrigins = (process.env.CORS_EXTRA_ORIGINS || '')
      .split(',').map(s => s.trim()).filter(Boolean);

    const ok =
      STATIC_ORIGINS.includes(origin) ||
      extraOrigins.includes(origin) ||
      REGEX_ORIGINS.some(rx => rx.test(origin));

    return ok ? cb(null, true) : cb(new Error(`Not allowed by CORS: ${origin}`));
  },
};

app.use(cors(corsOptions));
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan('combined', { stream: logger.stream }));
app.disable('x-powered-by');

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false
});
app.use('/api/', apiLimiter);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// NMS가 생성하는 HLS 파일을 Express 정적 파일 서버로 제공
app.use(express.static(getMediaroot()));

app.get('/api/streams', (_req, res) => {
  const items = listStreams().filter(s => s.app && s.stream);
  res.json({
    [process.env.NMS_APP_NAME || 'live']:
      Object.fromEntries(items.map(s => [s.stream, { path: s.path }]))
  });
});

// 라우터 연결
app.use('/api/auth', require('./routes/authRouter'));
app.use('/api/profile', require('./routes/profileRouter'));
app.use('/api/cameras', require('./routes/cameraRouter'));
app.use('/api/events', require('./routes/eventRouter'));
app.use('/api/recordings', require('./routes/recordingRouter'));
app.use('/api/settings', require('./routes/settingsRouter'));
app.use('/api/notifications', require('./routes/notificationRouter'));
app.use('/api/sound-detection', require('./routes/soundDetectionRouter'));
app.use('/api/robot', require('./routes/robotRouter'));
app.use('/api/websocket', require('./routes/websocketRouter'));

// 기본 라우트/헬스체크
app.get('/', (_req, res) => { res.send('Backend API is running'); });
app.get('/healthz', (_req, res) => { res.json({ ok: true, time: new Date().toISOString() }); });
// EMQX 헬스체크
app.get('/emqx/health', (_req, res) => {
  const healthInfo = emqxClient.getHealthInfo();
  res.json(healthInfo);
});


// --websocket--
const wss = new WebSocket.Server({ server, path: '/ws' });

// WebSocket 연결 처리 
wss.on('connection', (ws, req) => {
  try {
    // 간단한 토큰 인증: 쿼리 ?token= 또는 헤더 Authorization: Bearer
    const url = new URL(req.url, `http://${req.headers.host}`);
    const tokenParam = url.searchParams.get('token');
    const authHeader = req.headers['authorization'] || '';

    let userId = 1;
    const raw = tokenParam || (authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null);
    if (raw && raw.includes('test')) {
      userId = 1;
    }
    // TODO: 운영에서는 jwt.verify(raw)로 검증 후 userId 추출

    const { notificationService } = require('./service/NotificationService');
    notificationService.addClient(userId, ws);

    ws.on('close', () => notificationService.removeClient(userId, ws));
    ws.on('error', (error) => {
      console.error('❌ WebSocket 에러:', error);
      notificationService.removeClient(userId, ws);
    });
  } catch (e) {
    console.error('❌ WebSocket 연결 처리 실패:', e?.message || e);
    try { ws.close(1008, 'Unauthorized'); } catch (_) { }
  }
});

/* -----------------------------
 * EMQX 구독 로직
 * --------------------------- */
function handleRobotStatus(data) {
  const RobotController = require('./controllers/RobotController');
  // 상태 업데이트 로직 (팀 구현 유지)
}
function handleObstacleDetection(data) {
  const RobotController = require('./controllers/RobotController');
  RobotController.handleObstacleDetection(data.robot_id, data);
}
function handleCaptureResult(data) {
  const CameraController = require('./controllers/CameraController');
  CameraController.handleCaptureResult(data);
}
function handleRecordingStatus(data) {
  const CameraController = require('./controllers/CameraController');
  CameraController.handleRecordingStatus(data);
}
function handlePtzStatus(data) {
  const CameraController = require('./controllers/CameraController');
  CameraController.handlePtzStatus(data);
}
function handleCommandCompleted(data) {
  const RobotController = require('./controllers/RobotController');
  // data에 command_id, success 등의 정보가 포함되어 있다고 가정
  RobotController.handleCommandCompleted(data.command_id, data);
}

function normalizeSoundPayload(raw, topic) {
  const parts = (topic || '').split('/');
  const cameraId = parts[2] || raw.cameraId || 'unknown';
  const userId = raw.userId || 'demoUser'; // TODO: 실제 매핑 적용
  const nowIso = new Date().toISOString();
  return {
    eventId: String(raw.eventId || `${cameraId}-${Date.now()}`),
    kind: 'sound',
    sound_type: raw.sound_type || raw.type || 'unknown',
    decibel_level: raw.decibel_level ?? raw.db ?? null,
    severity: raw.severity || 'high',
    confidence: raw.confidence ?? 1,
    userId,
    cameraId,
    ts: raw.ts || nowIso,
    media: {
      audioUrl: raw.media?.audioUrl || '',
      spectrogramUrl: raw.media?.spectrogramUrl || ''
    },
    meta: raw.meta || {}
  };
}


async function startEMQX() {
  try {
    await emqxClient.connect();
    console.log('✅ EMQX MQTT 클라이언트 연결 성공');

    emqxClient.subscribe('tibo/camera/+/status', (d) => console.log('📊 카메라 상태 업데이트:', d));
    emqxClient.subscribe('tibo/camera/+/motion', (d) => console.log('👤 모션 이벤트:', d));
    emqxClient.subscribe('tibo/camera/+/sound', (d) => console.log('🔊 소리 이벤트:', d));

    emqxClient.subscribe('robot/+/status', (d) => { console.log('🤖 로봇 상태 업데이트:', d); handleRobotStatus(d); });
    emqxClient.subscribe('robot/+/obstacle', (d) => { console.log('⚠️ 장애물 감지:', d); handleObstacleDetection(d); });

    emqxClient.subscribe('tibo/camera/+/capture/result', (d) => { console.log('📸 캡처 결과:', d); handleCaptureResult(d); });
    emqxClient.subscribe('tibo/camera/+/recording/status', (d) => { console.log('📹 녹화 상태:', d); handleRecordingStatus(d); });
    emqxClient.subscribe('tibo/camera/+/ptz/status', (d) => { console.log('🎮 PTZ 상태:', d); handlePtzStatus(d); });

    emqxClient.subscribe('robot/+/command/completed', (d) => { console.log('✅ 명령 완료:', d); handleCommandCompleted(d); });
  } catch (error) {
    console.error('❌ EMQX 연결 실패:', error);
  }
  // 소리 이벤트 구독
      emqxClient.subscribe('tibo/camera/+/sound', async (d, ctx) => { 
      try {
        const payload = typeof d === 'string' ? JSON.parse(d) : d;
        console.log('🔊 소리 이벤트 수신:', ctx?.topic, payload?.eventId || payload);
        await handleSoundEvent(normalizeSoundPayload(payload, ctx?.topic));
      } catch (e) {
        console.error('❌ 소리 이벤트 처리 실패:', e?.message || e);
      }
    });
    // 위험물 이벤트 구독
    emqxClient.subscribe('tibo/+/+/events/danger', async (d, ctx) => { 
      try {
        const payload = typeof d === 'string' ? JSON.parse(d) : d;
        console.log('⚠️ 위험물 이벤트 수신:', ctx?.topic, payload?.eventId || payload);
        await handleDangerEvent(payload);
      } catch (e) {
        console.error('❌ 위험물 이벤트 처리 실패:', e?.message || e);
      }
    });
}


// 에러 핸들러
app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal Server Error' });
});

// 서버 시작 
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', async () => {
  await syncDatabase();

  // 미디어 서버 시작 
  try{
    runNMS();
  } catch (e) {
    console.error('❌ NMS 시작 실패:', e?.message || e);  
  }

  let localIp = '127.0.0.1';
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) { localIp = net.address; break; }
    }
    if (localIp !== '127.0.0.1') break;
  }

  console.log(`Server running on port ${PORT}`);
  console.log(`👉 http://localhost:${PORT}`);
  console.log(`🌐 http://${localIp}:${PORT}`);
  console.log(`📱 SMS 발송: ${process.env.ENABLE_SMS === 'true' ? '활성화' : '비활성화'}`);

  await startEMQX();
});

// Graceful shutdown
function shutdown(signal) {
  console.log(`\n${signal} received. Shutting down gracefully...`);
  try { emqxClient.disconnect(); } catch (_) { }
  try { server.close(() => process.exit(0)); } catch (_) { process.exit(0); }
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

