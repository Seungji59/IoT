#!/usr/bin/env python3
"""
간단한 MQTT 테스트 스크립트
팀원이 빠르게 MQTT 연결과 메시지를 확인할 수 있습니다.
"""

import paho.mqtt.client as mqtt
import json
import time

# 설정
BROKER = "192.168.0.7"  # 또는 "localhost"
PORT = 1883
USERNAME = "tukorea"
PASSWORD = "tukorea"

def on_connect(client, userdata, flags, rc):
    print(f"✅ 연결됨! 코드: {rc}")
    client.subscribe("robot/+/control", qos=1)
    print("📡 robot/+/control 토픽 구독 완료")

def on_message(client, userdata, msg):
    print(f"\n📨 메시지 수신: {msg.topic}")
    try:
        data = json.loads(msg.payload.decode())
        print(f"📝 내용: {json.dumps(data, indent=2, ensure_ascii=False)}")
    except:
        print(f"📝 Raw: {msg.payload.decode()}")

# 클라이언트 생성
client = mqtt.Client()
client.username_pw_set(USERNAME, PASSWORD)
client.on_connect = on_connect
client.on_message = on_message

print(f"🔗 {BROKER}:{PORT}에 연결 중...")
client.connect(BROKER, PORT, 60)

print("🔄 메시지 대기 중... (Ctrl+C로 종료)")
try:
    client.loop_forever()
except KeyboardInterrupt:
    print("\n🛑 종료")
    client.disconnect() 