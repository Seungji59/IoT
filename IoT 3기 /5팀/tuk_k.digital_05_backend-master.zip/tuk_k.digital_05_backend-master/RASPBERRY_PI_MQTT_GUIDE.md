# 🍓 라즈베리파이 MQTT 토픽 가이드

## 📡 **NodeMediaServer 설정 (고정값)**

### **서버 정보**
- **서버 IP**: `192.168.0.8`
- **스트림 이름**: `raspi01`
- **RTMP 포트**: `1935`
- **HTTP 포트**: `8000`

### **스트리밍 URL**
```bash
# RTMP 송출 URL
rtmp://192.168.0.8:1935/live/raspi01

# HLS 재생 URL
http://192.168.0.8:8000/live/raspi01/index.m3u8
```

---

## 🎯 **YOLO 객체 감지 토픽 (팀원 코드에 맞춤)**

### **토픽**: `tibo/camera/{camera_id}/object-detection`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "object_type": "person",
  "confidence": 0.95,
  "bbox": [45, 32, 28, 65],
  "track_id": 1,
  "image_url": "http://192.168.0.8:8000/detection/person_20240115_102530.jpg",
  "object_count": 1,
  "location": "거실",
  "is_baby": false,
  "timestamp": "2024-01-15T10:25:30Z"
}
```

## 👶 **Baby Tracking 토픽 (팀원 코드에 맞춤)**

### **토픽**: `tibo/camera/{camera_id}/baby-tracking`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "track_id": 1,
  "bbox": [45, 32, 28, 65],
  "command": "LEFT",
  "distance_mm": 250,
  "baby_lost": false,
  "image_url": "http://192.168.0.8:8000/tracking/baby_20240115_102530.jpg",
  "confidence": 0.95,
  "timestamp": "2024-01-15T10:25:30Z"
}
```

### **객체 타입별 우선순위**:
- `baby` → **Critical** (아기 감지)
- `dangerous_object` → **Critical** (위험물 감지)
- `person` → **High** (사람 감지)
- `car` → **Medium** (차량 감지)
- `pet` → **Low** (반려동물 감지)
- `unknown` → **Medium** (알 수 없는 객체)

---

## 🏃 **모션 감지 토픽**

### **토픽**: `tibo/camera/{camera_id}/motion`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "event_type": "motion_start|motion_end|continuous_motion",
  "confidence": 0.87,
  "region": {
    "x": 0.12,
    "y": 0.18,
    "width": 0.15,
    "height": 0.22
  },
  "image_url": "http://192.168.0.8:8000/motion/motion_20240115_102015.jpg",
  "duration": 3.2,
  "location": "거실",
  "timestamp": "2024-01-15T10:20:15Z"
}
```

---

## 🔊 **소리 감지 토픽**

### **토픽**: `tibo/camera/{camera_id}/sound`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "sound_type": "glass_break|door_bell|alarm|voice|unknown",
  "decibel_level": 75.5,
  "duration": 2.3,
  "confidence": 0.92,
  "audio_file_url": "http://192.168.0.8:8000/audio/sound_20240115_102530.wav",
  "spectrogram_url": "http://192.168.0.8:8000/spectrogram/sound_20240115_102530.png",
  "location": "거실",
  "timestamp": "2024-01-15T10:25:30Z"
}
```

---

## 🤖 **로봇 제어 토픽 (팀원 코드에 맞춤)**

### **토픽**: `robot/control`

### **명령 형식**:
```
LEFT|RIGHT|CENTER|BACKWARD|STOP|FORWARD
```

### **사용 예시**:
```python
# Python에서 명령 발행
client.publish("robot/control", "LEFT")
client.publish("robot/control", "STOP")
```

---

## ⚠️ **장애물 감지 (팀원 코드)**

### **VL53L0X 거리 센서**
- 팀원 코드에서 자동으로 처리됨
- 500mm 이하에서 자동 STOP 명령 발행
- Baby tracking 데이터에 `distance_mm` 필드로 포함

---

## ✅ **명령 완료 토픽**

### **토픽**: `robot/{robot_id}/command/completed`

### **데이터 형식**:
```json
{
  "robot_id": "tibo-001",
  "command_id": "cmd_12345",
  "command": "MOVE_FORWARD",
  "success": true,
  "result": "Command executed successfully",
  "timestamp": "2024-01-15T10:25:30Z"
}
```

---

## 📸 **캡처 결과 토픽**

### **토픽**: `tibo/camera/{camera_id}/capture/result`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "file_path": "/uploads/captures/capture_20240115_102530.jpg",
  "file_size": 2048576,
  "image_url": "http://192.168.0.8:8000/captures/capture_20240115_102530.jpg",
  "timestamp": "2024-01-15T10:25:30Z"
}
```

---

## 📹 **녹화 상태 토픽**

### **토픽**: `tibo/camera/{camera_id}/recording/status`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "status": "started|stopped|error",
  "file_path": "/uploads/recordings/recording_20240115_102530.mp4",
  "duration": 120.5,
  "file_size": 52428800,
  "timestamp": "2024-01-15T10:25:30Z"
}
```

---

## 🎮 **PTZ 상태 토픽**

### **토픽**: `tibo/camera/{camera_id}/ptz/status`

### **데이터 형식**:
```json
{
  "camera_id": 1,
  "position": {
    "pan": 45.0,
    "tilt": 30.0,
    "zoom": 2.5
  },
  "timestamp": "2024-01-15T10:25:30Z"
}
```

---

## 🔧 **Python MQTT 클라이언트 예시 (팀원 코드 기반)**

```python
import paho.mqtt.client as mqtt
import json
import time

# MQTT 클라이언트 설정 (팀원 코드와 동일)
client = mqtt.Client()
client.username_pw_set("tukorea", "tukorea")
client.connect("192.168.0.7", 1883, 60)

# Baby tracking 데이터 발행 예시
def publish_baby_tracking():
    data = {
        "camera_id": 1,
        "track_id": 1,
        "bbox": [45, 32, 28, 65],
        "command": "LEFT",
        "distance_mm": 250,
        "baby_lost": False,
        "image_url": "http://192.168.0.8:8000/tracking/baby_20240115_102530.jpg",
        "confidence": 0.95,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
    }
    
    client.publish("tibo/camera/1/baby-tracking", json.dumps(data))
    print("👶 Baby tracking 데이터 발행")

# 객체 감지 데이터 발행 예시
def publish_object_detection():
    data = {
        "camera_id": 1,
        "object_type": "person",
        "confidence": 0.95,
        "bbox": [45, 32, 28, 65],
        "track_id": 1,
        "image_url": "http://192.168.0.8:8000/detection/person_20240115_102530.jpg",
        "object_count": 1,
        "location": "거실",
        "is_baby": False,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ")
    }
    
    client.publish("tibo/camera/1/object-detection", json.dumps(data))
    print("🎯 객체 감지 데이터 발행")

# 실행
publish_baby_tracking()
publish_object_detection()
```

---

## 📋 **체크리스트**

### **필수 구현 항목**:
- [ ] YOLO baby 탐지 및 위험물 인식
- [ ] RTMP 비디오 스트리밍 (rtmp://192.168.0.8:1935/live/raspi01)
- [ ] 오디오 스트리밍 (마이크 입력)
- [ ] 영상 녹화 기능
- [ ] PTZ 제어 (줌인/줌아웃)
- [ ] MQTT 토픽 발행

### **테스트 순서**:
1. **비디오 스트리밍** 확인
2. **오디오 스트리밍** 추가
3. **YOLO 객체 감지** 테스트
4. **모션 감지** 테스트
5. **소리 감지** 테스트
6. **로봇 제어** 테스트

---

## 🚨 **주의사항**

1. **고정 IP 사용**: 192.168.0.8 IP 주소 변경 금지
2. **포트 번호**: RTMP 1935, HTTP 8000 고정
3. **스트림 이름**: raspi01 고정
4. **데이터 형식**: JSON 형식 준수
5. **타임스탬프**: ISO 8601 형식 사용
6. **이미지 URL**: HTTP 접근 가능한 URL 제공 